# License not yet assigned

No license has been assigned to the study-authored code in this release candidate.
Before public release on GitHub/Zenodo, the authors should select an appropriate license consistent with institutional policy and any third-party dependencies.

This repository also depends on external software and databases that retain their own licenses.
