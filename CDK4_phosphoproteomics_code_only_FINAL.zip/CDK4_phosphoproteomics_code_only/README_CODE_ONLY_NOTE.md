# Code-only mirror

This compact archive contains scripts and documentation only and is intended for a GitHub-style code mirror.

The complete reproducibility archive additionally contains frozen inputs, the original quantitative workbook, reference FASTA/reference sets, frozen result workbooks and complete cluster-aware output tables. Deposit the complete archive in a data/reproducibility repository (for example Zenodo) and link the two records.
