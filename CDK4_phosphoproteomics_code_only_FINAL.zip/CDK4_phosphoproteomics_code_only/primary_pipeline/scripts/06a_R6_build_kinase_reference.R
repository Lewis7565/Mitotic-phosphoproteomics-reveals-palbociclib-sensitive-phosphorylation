# ============================================================================
# R6_reference_builder_DIRECT_API.R
# Build kinase_substrate_reference_R6.csv without using OmnipathR
# ============================================================================
# Purpose:
#   Bypass the OmnipathR/Ensembl taxonomy error and query the OmniPath REST API
#   directly for human phosphorylation enzyme-substrate relationships.
#
# Output:
#   phosphoproteomics_followup_analysis/
#     R6_kinase_signature/
#       input_reference/
#         kinase_substrate_reference_R6.csv
#         kinase_substrate_reference_R6_primary.csv
#         kinase_substrate_reference_R6_expanded.csv
#         OmniPath_raw_primary.tsv
#         OmniPath_raw_expanded.tsv
#         reference_build_summary.xlsx
#
# After this script finishes successfully:
#   rerun R6_kinase_signature_analysis.R
# ============================================================================

suppressPackageStartupMessages({
  library(dplyr)
  library(stringr)
  library(readr)
  library(tidyr)
  library(purrr)
  library(tibble)
  library(openxlsx)
})

# ----------------------------------------------------------------------------
# 0. Output folders
# ----------------------------------------------------------------------------
if (!exists("analysis_dir")) {
  analysis_dir <- file.path(
    getwd(),
    "phosphoproteomics_followup_analysis"
  )
}

r6_input_dir <- file.path(
  analysis_dir,
  "R6_kinase_signature",
  "input_reference"
)

dir.create(
  r6_input_dir,
  recursive = TRUE,
  showWarnings = FALSE
)

# ----------------------------------------------------------------------------
# 1. Kinases of interest
# ----------------------------------------------------------------------------
target_kinases <- c(
  "CDK4",
  "CDK6",
  "CDK1",
  "AURKA",
  "AURKB",
  "PLK1",
  "TTK"
)

# Primary = curated/literature-oriented sources
primary_resources <- c(
  "PhosphoSite",
  "SIGNOR",
  "HPRD"
)

# Expanded = broader enzyme-substrate resources
expanded_resources <- c(
  "PhosphoSite",
  "SIGNOR",
  "HPRD",
  "KEA",
  "phosphoELM",
  "dbPTM",
  "MIMP",
  "PhosphoNetworks",
  "Reactome_ProtMapper",
  "ProtMapper"
)

# ----------------------------------------------------------------------------
# 2. Direct OmniPath REST downloader
# ----------------------------------------------------------------------------
download_omnipath_enzsub <- function(
    resources,
    output_path,
    label = "query"
) {

  resource_string <- paste(
    resources,
    collapse = ","
  )

  # OmniPath documentation currently exposes enzyme-substrate data through
  # /enz_sub (and historically /ptms). We try both for robustness.
  urls <- c(
    paste0(
      "https://omnipathdb.org/enz_sub",
      "?format=tsv",
      "&genesymbols=1",
      "&organisms=9606",
      "&types=phosphorylation",
      "&fields=sources,references,isoforms",
      "&databases=",
      URLencode(
        resource_string,
        reserved = TRUE
      )
    ),
    paste0(
      "https://omnipathdb.org/ptms",
      "?format=tsv",
      "&genesymbols=1",
      "&organisms=9606",
      "&types=phosphorylation",
      "&fields=sources,references,isoforms",
      "&databases=",
      URLencode(
        resource_string,
        reserved = TRUE
      )
    )
  )

  last_error <- NULL

  for (u in urls) {

    message("\nTrying OmniPath REST API (", label, "):")
    message(u)

    tmp <- tempfile(
      fileext = ".tsv"
    )

    ok <- tryCatch(
      {
        download.file(
          url = u,
          destfile = tmp,
          mode = "wb",
          quiet = FALSE,
          method = "libcurl"
        )
        TRUE
      },
      error = function(e) {
        last_error <<- conditionMessage(e)
        FALSE
      },
      warning = function(w) {
        # warnings from download.file do not necessarily mean failure;
        # continue and validate the downloaded file below
        invokeRestart("muffleWarning")
      }
    )

    if (!ok || !file.exists(tmp)) {
      next
    }

    info <- file.info(tmp)

    if (
      is.na(info$size) ||
      info$size < 20
    ) {
      next
    }

    dat <- tryCatch(
      read_tsv(
        tmp,
        show_col_types = FALSE,
        progress = FALSE,
        na = c("", "NA", "None")
      ),
      error = function(e) {
        last_error <<- conditionMessage(e)
        NULL
      }
    )

    if (
      !is.null(dat) &&
      nrow(dat) > 0 &&
      ncol(dat) > 2
    ) {

      file.copy(
        tmp,
        output_path,
        overwrite = TRUE
      )

      message(
        "Success: ",
        nrow(dat),
        " rows x ",
        ncol(dat),
        " columns."
      )

      return(dat)
    }
  }

  stop(
    paste0(
      "\nDirect OmniPath REST query failed.\n",
      "Last error: ",
      last_error,
      "\n\n",
      "Please open https://omnipathdb.org/ in a browser to confirm network access, ",
      "then rerun this script."
    )
  )
}

# ----------------------------------------------------------------------------
# 3. Download primary and expanded datasets
# ----------------------------------------------------------------------------
primary_raw <- download_omnipath_enzsub(
  resources = primary_resources,
  output_path = file.path(
    r6_input_dir,
    "OmniPath_raw_primary.tsv"
  ),
  label = "PRIMARY"
)

expanded_raw <- download_omnipath_enzsub(
  resources = expanded_resources,
  output_path = file.path(
    r6_input_dir,
    "OmniPath_raw_expanded.tsv"
  ),
  label = "EXPANDED"
)

message("\nPrimary columns:")
print(colnames(primary_raw))

message("\nExpanded columns:")
print(colnames(expanded_raw))

# ----------------------------------------------------------------------------
# 4. Flexible column finder
# ----------------------------------------------------------------------------
pick_col <- function(
    data,
    candidates,
    required = TRUE
) {

  nms <- colnames(data)

  # exact match first
  for (candidate in candidates) {
    hit <- which(
      tolower(nms) ==
        tolower(candidate)
    )

    if (length(hit) > 0) {
      return(nms[hit[1]])
    }
  }

  # normalized match second
  norm <- function(x) {
    str_replace_all(
      tolower(x),
      "[^a-z0-9]",
      ""
    )
  }

  norm_nms <- norm(nms)

  for (candidate in candidates) {
    hit <- which(
      norm_nms ==
        norm(candidate)
    )

    if (length(hit) > 0) {
      return(nms[hit[1]])
    }
  }

  if (required) {
    stop(
      "Could not find required column. Tried: ",
      paste(candidates, collapse = ", "),
      "\nAvailable columns:\n",
      paste(nms, collapse = ", ")
    )
  }

  NA_character_
}

# ----------------------------------------------------------------------------
# 5. Convert OmniPath result to R6 format
# ----------------------------------------------------------------------------
convert_omnipath_reference <- function(
    dat,
    evidence_label
) {

  enzyme_gene_col <- pick_col(
    dat,
    c(
      "enzyme_genesymbol",
      "enzyme_gene_symbol",
      "enzyme_symbol"
    )
  )

  enzyme_acc_col <- pick_col(
    dat,
    c(
      "enzyme",
      "enzyme_uniprot",
      "enzyme_accession"
    ),
    required = FALSE
  )

  substrate_gene_col <- pick_col(
    dat,
    c(
      "substrate_genesymbol",
      "substrate_gene_symbol",
      "substrate_symbol"
    )
  )

  substrate_acc_col <- pick_col(
    dat,
    c(
      "substrate",
      "substrate_uniprot",
      "substrate_accession"
    )
  )

  residue_col <- pick_col(
    dat,
    c(
      "residue_type",
      "residue",
      "aa",
      "amino_acid"
    )
  )

  position_col <- pick_col(
    dat,
    c(
      "residue_offset",
      "position",
      "residue_position",
      "site"
    )
  )

  modification_col <- pick_col(
    dat,
    c(
      "modification",
      "modification_type",
      "type"
    ),
    required = FALSE
  )

  sources_col <- pick_col(
    dat,
    c(
      "sources",
      "source"
    ),
    required = FALSE
  )

  references_col <- pick_col(
    dat,
    c(
      "references",
      "reference",
      "pmids",
      "pubmed"
    ),
    required = FALSE
  )

  # Safe extraction when an optional column does not exist
  pull_optional <- function(data, col_name) {
    if (
      is.na(col_name) ||
      !col_name %in% colnames(data)
    ) {
      rep(
        NA_character_,
        nrow(data)
      )
    } else {
      as.character(
        data[[col_name]]
      )
    }
  }

  out <- tibble(
    kinase =
      as.character(
        dat[[enzyme_gene_col]]
      ),

    enzyme_accession =
      pull_optional(
        dat,
        enzyme_acc_col
      ),

    substrate_gene =
      as.character(
        dat[[substrate_gene_col]]
      ),

    substrate_accession =
      as.character(
        dat[[substrate_acc_col]]
      ),

    residue =
      str_to_upper(
        as.character(
          dat[[residue_col]]
        )
      ),

    position =
      suppressWarnings(
        as.integer(
          dat[[position_col]]
        )
      ),

    modification =
      pull_optional(
        dat,
        modification_col
      ),

    evidence_level =
      evidence_label,

    evidence_type =
      "OmniPath enzyme-substrate phosphosite",

    source_database =
      pull_optional(
        dat,
        sources_col
      ),

    source_reference =
      pull_optional(
        dat,
        references_col
      ),

    notes =
      NA_character_
  ) %>%
    mutate(
      kinase =
        str_to_upper(
          str_trim(
            kinase
          )
        ),

      kinase =
        case_when(
          kinase %in% c(
            "MPS1",
            "TTK",
            "MPS1/TTK",
            "TTK/MPS1"
          ) ~ "TTK",

          kinase %in% c(
            "AURORA A",
            "AURORA-A"
          ) ~ "AURKA",

          kinase %in% c(
            "AURORA B",
            "AURORA-B"
          ) ~ "AURKB",

          TRUE ~ kinase
        ),

      substrate_gene =
        str_trim(
          substrate_gene
        ),

      substrate_accession =
        str_trim(
          substrate_accession
        ),

      # Remove UniProt isoform suffix for matching to the user's
      # protein_accession_clean where appropriate.
      substrate_accession =
        str_replace(
          substrate_accession,
          "-\\d+$",
          ""
        )
    ) %>%
    filter(
      kinase %in%
        target_kinases,

      !is.na(
        substrate_accession
      ),

      substrate_accession != "",

      !is.na(
        position
      ),

      residue %in%
        c(
          "S",
          "T",
          "Y"
        )
    )

  # If modification information exists, keep phosphorylation only.
  if (
    "modification" %in%
      colnames(out) &&
    any(
      !is.na(
        out$modification
      )
    )
  ) {

    mod_lower <- str_to_lower(
      out$modification
    )

    keep <- is.na(mod_lower) |
      mod_lower == "" |
      str_detect(
        mod_lower,
        "phosph"
      )

    out <- out[
      keep,
      ,
      drop = FALSE
    ]
  }

  out %>%
    distinct(
      kinase,
      substrate_accession,
      residue,
      position,
      .keep_all = TRUE
    )
}

primary_reference <- convert_omnipath_reference(
  primary_raw,
  evidence_label =
    "Primary: PhosphoSite/SIGNOR/HPRD"
)

expanded_reference <- convert_omnipath_reference(
  expanded_raw,
  evidence_label =
    "Expanded: broader OmniPath resources"
)

# ----------------------------------------------------------------------------
# 6. Save separate primary and expanded references
# ----------------------------------------------------------------------------
primary_path <- file.path(
  r6_input_dir,
  "kinase_substrate_reference_R6_primary.csv"
)

expanded_path <- file.path(
  r6_input_dir,
  "kinase_substrate_reference_R6_expanded.csv"
)

write_csv(
  primary_reference,
  primary_path
)

write_csv(
  expanded_reference,
  expanded_path
)

# ----------------------------------------------------------------------------
# 7. Build main R6 reference
# ----------------------------------------------------------------------------
# Primary is used as the main analysis set.
# Expanded-only sites are NOT silently mixed into the primary set.
main_reference <- primary_reference %>%
  select(
    kinase,
    substrate_gene,
    substrate_accession,
    residue,
    position,
    evidence_level,
    evidence_type,
    source_database,
    source_reference,
    notes
  )

main_path <- file.path(
  r6_input_dir,
  "kinase_substrate_reference_R6.csv"
)

write_csv(
  main_reference,
  main_path
)

# ----------------------------------------------------------------------------
# 8. Summary tables
# ----------------------------------------------------------------------------
primary_counts <- primary_reference %>%
  count(
    kinase,
    name =
      "n_reference_sites"
  ) %>%
  complete(
    kinase =
      target_kinases,
    fill =
      list(
        n_reference_sites = 0
      )
  ) %>%
  arrange(
    match(
      kinase,
      target_kinases
    )
  )

expanded_counts <- expanded_reference %>%
  count(
    kinase,
    name =
      "n_reference_sites"
  ) %>%
  complete(
    kinase =
      target_kinases,
    fill =
      list(
        n_reference_sites = 0
      )
  ) %>%
  arrange(
    match(
      kinase,
      target_kinases
    )
  )

resource_summary <- full_join(
  primary_counts %>%
    rename(
      primary_sites =
        n_reference_sites
    ),
  expanded_counts %>%
    rename(
      expanded_sites =
        n_reference_sites
    ),
  by = "kinase"
) %>%
  mutate(
    additional_expanded_sites =
      expanded_sites -
      primary_sites
  )

# If site_data exists, immediately estimate matching coverage.
dataset_match_summary <- tibble()

if (
  exists("site_data") &&
  all(
    c(
      "protein_accession_clean",
      "Position",
      "Amino acid",
      "site_id"
    ) %in%
      colnames(
        site_data
      )
  )
) {

  exact_matches_now <- site_data %>%
    inner_join(
      main_reference,
      by = c(
        "protein_accession_clean" =
          "substrate_accession",
        "Position" =
          "position",
        "Amino acid" =
          "residue"
      )
    ) %>%
    distinct(
      kinase,
      site_id,
      .keep_all = TRUE
    )

  dataset_match_summary <- primary_counts %>%
    left_join(
      exact_matches_now %>%
        count(
          kinase,
          name =
            "n_detected_in_dataset"
        ),
      by = "kinase"
    ) %>%
    mutate(
      n_detected_in_dataset =
        replace_na(
          n_detected_in_dataset,
          0L
        ),

      detection_fraction =
        if_else(
          n_reference_sites > 0,
          n_detected_in_dataset /
            n_reference_sites,
          NA_real_
        ),

      enough_for_R6_primary =
        n_detected_in_dataset >=
          3
    )
}

write.xlsx(
  list(
    Primary_counts =
      primary_counts,

    Expanded_counts =
      expanded_counts,

    Primary_vs_expanded =
      resource_summary,

    Dataset_exact_match =
      dataset_match_summary,

    Primary_reference =
      primary_reference,

    Expanded_reference =
      expanded_reference
  ),
  file = file.path(
    r6_input_dir,
    "reference_build_summary.xlsx"
  ),
  overwrite = TRUE
)

# ----------------------------------------------------------------------------
# 9. Console report
# ----------------------------------------------------------------------------
message(
  "\n============================================================"
)

message(
  "\nPRIMARY kinase-site counts:"
)
print(
  primary_counts
)

message(
  "\nEXPANDED kinase-site counts:"
)
print(
  expanded_counts
)

if (
  nrow(
    dataset_match_summary
  ) > 0
) {

  message(
    "\nExact matches to current phosphoproteomics dataset:"
  )

  print(
    dataset_match_summary
  )
}

message(
  "\nMain R6 reference written to:\n",
  main_path
)

message(
  "\nNext step:\n",
  "重新运行 R6_kinase_signature_analysis.R\n",
  "它会自动读取上面的 kinase_substrate_reference_R6.csv。"
)

message(
  "\n不要把 expanded reference 自动混入 primary analysis；",
  "\n建议 primary 作为主结果，expanded 作为 sensitivity/exploratory analysis。"
)

message(
  "\n============================================================\n"
)
