# ============================================================================
# R7.0 — Known CDK4/6 substrate validation + RB1-focused analysis
# ============================================================================
# 建议运行顺序：
#   R1.0 -> R2.0 -> R3.0 -> R4.0 -> R5.0 -> R6.0 -> 本脚本 R7.0
#
# 目的：
# 1) 对 R6 reference 中已知 CDK4/CDK6 phosphosite 做逐位点验证
# 2) 单独提取并重点分析 RB1
# 3) 比较 known CDK4/6 sites 与同一蛋白其他 phosphosites 的变化
# 4) 检查 Pal1 / Pal5 剂量一致性与显著下调比例
# 5) 输出 manuscript / supervisor-ready candidate tables
#
# 重要解释原则：
# - R6 是“kinase substrate-set signature”。
# - R7 是“known substrate / individual site validation”。
# - 如果 CDK4/6 全局 signature 不强，但 RB1 等 canonical sites 明确下降，
#   可以写成 site-specific target engagement，而不能写成全局 CDK4/6 signature。
# ============================================================================

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(stringr)
  library(purrr)
  library(tibble)
  library(ggplot2)
  library(readr)
  library(openxlsx)
  library(forcats)
})

# ----------------------------------------------------------------------------
# 0. 输入检查
# ----------------------------------------------------------------------------
required_objects_r7 <- c("site_data")
missing_objects_r7 <- required_objects_r7[
  !vapply(required_objects_r7, exists, logical(1), inherits = TRUE)
]

if (length(missing_objects_r7) > 0) {
  stop(
    "请先运行前面的数据处理代码。缺少对象：",
    paste(missing_objects_r7, collapse = ", ")
  )
}

required_cols_r7 <- c(
  "Protein accession",
  "protein_accession_clean",
  "Gene name",
  "Position",
  "Amino acid",
  "site_id",
  "motif_sequence_15mer",
  "motif_type",
  "Localization probability",
  "Pal1/Con Ratio",
  "Pal1/Con P value",
  "Pal5/Con Ratio",
  "Pal5/Con P value",
  "Pal1_log2FC",
  "Pal5_log2FC"
)

missing_cols_r7 <- setdiff(
  required_cols_r7,
  colnames(site_data)
)

if (length(missing_cols_r7) > 0) {
  stop(
    "site_data 缺少 R7.0 所需列：",
    paste(missing_cols_r7, collapse = ", ")
  )
}

if (!exists("analysis_dir")) {
  analysis_dir <- file.path(
    getwd(),
    "phosphoproteomics_followup_analysis"
  )
}

r7_dir <- file.path(
  analysis_dir,
  "R7_known_CDK46_substrate_validation"
)

r7_table_dir <- file.path(r7_dir, "tables")
r7_figure_dir <- file.path(r7_dir, "figures")
r7_input_dir <- file.path(r7_dir, "input_reference")

dir.create(r7_table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(r7_figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(r7_input_dir, recursive = TRUE, showWarnings = FALSE)

# ----------------------------------------------------------------------------
# 1. 读取 R6 primary kinase reference
# ----------------------------------------------------------------------------
r6_reference_path <- file.path(
  analysis_dir,
  "R6_kinase_signature",
  "input_reference",
  "kinase_substrate_reference_R6.csv"
)

if (!file.exists(r6_reference_path)) {
  stop(
    "未找到 R6 reference：\n",
    r6_reference_path,
    "\n请先运行 R6 reference builder。"
  )
}

r6_reference <- read_csv(
  r6_reference_path,
  show_col_types = FALSE
) %>%
  mutate(
    kinase = str_to_upper(str_trim(as.character(kinase))),
    substrate_gene = str_to_upper(str_trim(as.character(substrate_gene))),
    substrate_accession = str_trim(as.character(substrate_accession)),
    residue = str_to_upper(str_trim(as.character(residue))),
    position = suppressWarnings(as.integer(position))
  )

cdk46_reference <- r6_reference %>%
  filter(
    kinase %in% c("CDK4", "CDK6"),
    !is.na(substrate_accession),
    substrate_accession != "",
    !is.na(position),
    residue %in% c("S", "T", "Y")
  ) %>%
  distinct(
    kinase,
    substrate_accession,
    residue,
    position,
    .keep_all = TRUE
  )

if (nrow(cdk46_reference) == 0) {
  stop(
    "R6 reference 中没有有效 CDK4/CDK6 substrate phosphosites。"
  )
}

# ----------------------------------------------------------------------------
# 2. 建立可人工补充的 priority annotation 模板
# ----------------------------------------------------------------------------
# 本模板不阻塞分析：如果不填，R7仍会使用数据库 reference 完成。
priority_path <- file.path(
  r7_input_dir,
  "known_CDK46_site_priority_annotations.csv"
)

if (!file.exists(priority_path)) {

  priority_template <- cdk46_reference %>%
    transmute(
      substrate_gene = substrate_gene,
      substrate_accession = substrate_accession,
      residue = residue,
      position = position,
      kinase = kinase,
      canonical_priority = case_when(
        substrate_gene == "RB1" ~ "RB1_focus",
        TRUE ~ "Database_supported"
      ),
      functional_role = NA_character_,
      literature_note = NA_character_,
      manual_include = TRUE
    ) %>%
    distinct()

  write_csv(
    priority_template,
    priority_path
  )

  message(
    "已创建可选人工注释模板：\n",
    priority_path,
    "\n不填写也可继续分析；",
    "若后续核对文献，可在此标注 canonical/high-confidence sites。"
  )
}

priority_annotation <- read_csv(
  priority_path,
  show_col_types = FALSE
) %>%
  mutate(
    substrate_gene = str_to_upper(str_trim(as.character(substrate_gene))),
    substrate_accession = str_trim(as.character(substrate_accession)),
    residue = str_to_upper(str_trim(as.character(residue))),
    position = suppressWarnings(as.integer(position)),
    kinase = str_to_upper(str_trim(as.character(kinase))),
    manual_include = replace_na(as.logical(manual_include), TRUE)
  )

cdk46_reference_annotated <- cdk46_reference %>%
  left_join(
    priority_annotation,
    by = c(
      "substrate_gene",
      "substrate_accession",
      "residue",
      "position",
      "kinase"
    ),
    suffix = c("", "_manual")
  ) %>%
  mutate(
    canonical_priority = coalesce(
      canonical_priority,
      if_else(
        substrate_gene == "RB1",
        "RB1_focus",
        "Database_supported"
      )
    ),
    manual_include = replace_na(manual_include, TRUE)
  ) %>%
  filter(manual_include)

# ----------------------------------------------------------------------------
# 3. Exact phosphosite matching
# ----------------------------------------------------------------------------
known_site_matches <- site_data %>%
  inner_join(
    cdk46_reference_annotated,
    by = c(
      "protein_accession_clean" = "substrate_accession",
      "Position" = "position",
      "Amino acid" = "residue"
    )
  ) %>%
  distinct(
    kinase,
    site_id,
    .keep_all = TRUE
  ) %>%
  mutate(
    known_site = paste0(`Amino acid`, Position),
    Pal1_down = !is.na(`Pal1/Con P value`) &
      `Pal1/Con P value` < 0.05 &
      !is.na(Pal1_log2FC) &
      Pal1_log2FC < 0,
    Pal5_down = !is.na(`Pal5/Con P value`) &
      `Pal5/Con P value` < 0.05 &
      !is.na(Pal5_log2FC) &
      Pal5_log2FC < 0,
    down_both = Pal1_down & Pal5_down,
    dose_delta = Pal5_log2FC - Pal1_log2FC,
    stronger_at_Pal5 = !is.na(dose_delta) & dose_delta < 0
  )

# CDK4/CDK6 union：同一 phosphosite 只保留一次
known_site_matches_union <- known_site_matches %>%
  arrange(
    desc(canonical_priority == "RB1_focus")
  ) %>%
  distinct(
    site_id,
    .keep_all = TRUE
  ) %>%
  mutate(
    kinase_union = "CDK4/6"
  )

# ----------------------------------------------------------------------------
# 4. Reference coverage / detection summary
# ----------------------------------------------------------------------------
reference_union <- cdk46_reference_annotated %>%
  distinct(
    substrate_accession,
    residue,
    position,
    .keep_all = TRUE
  )

coverage_summary <- tibble(
  n_reference_CDK4_rows = nrow(
    cdk46_reference_annotated %>%
      filter(kinase == "CDK4")
  ),
  n_reference_CDK6_rows = nrow(
    cdk46_reference_annotated %>%
      filter(kinase == "CDK6")
  ),
  n_unique_reference_sites = nrow(reference_union),
  n_exact_detected_sites = n_distinct(known_site_matches_union$site_id),
  n_detected_substrate_genes = n_distinct(
    known_site_matches_union$substrate_gene
  ),
  detection_fraction = if_else(
    nrow(reference_union) > 0,
    n_distinct(known_site_matches_union$site_id) / nrow(reference_union),
    NA_real_
  ),
  n_RB1_reference_sites = sum(reference_union$substrate_gene == "RB1"),
  n_RB1_detected_sites = n_distinct(
    known_site_matches_union$site_id[
      known_site_matches_union$substrate_gene == "RB1"
    ]
  )
)

# ----------------------------------------------------------------------------
# 5. Per-site validation table
# ----------------------------------------------------------------------------
site_validation_table <- known_site_matches_union %>%
  transmute(
    priority = canonical_priority,
    substrate_gene,
    protein_accession = protein_accession_clean,
    known_site,
    residue = `Amino acid`,
    position = Position,
    kinase_source = kinase,
    evidence_level,
    evidence_type,
    source_database,
    source_reference,
    functional_role,
    literature_note,
    motif_type,
    motif_sequence_15mer,
    localization_probability = `Localization probability`,
    Pal1_ratio = `Pal1/Con Ratio`,
    Pal1_log2FC,
    Pal1_p = `Pal1/Con P value`,
    Pal1_down,
    Pal5_ratio = `Pal5/Con Ratio`,
    Pal5_log2FC,
    Pal5_p = `Pal5/Con P value`,
    Pal5_down,
    down_both,
    dose_delta,
    stronger_at_Pal5
  ) %>%
  arrange(
    desc(priority == "RB1_focus"),
    substrate_gene,
    position
  )

# ----------------------------------------------------------------------------
# 6. Summary by substrate gene
# ----------------------------------------------------------------------------
substrate_gene_summary <- known_site_matches_union %>%
  group_by(
    substrate_gene
  ) %>%
  summarise(
    n_known_sites_detected = n_distinct(site_id),
    n_CDK4_links = n_distinct(
      site_id[kinase == "CDK4"]
    ),
    n_CDK6_links = n_distinct(
      site_id[kinase == "CDK6"]
    ),
    Pal1_down_sites = sum(Pal1_down, na.rm = TRUE),
    Pal5_down_sites = sum(Pal5_down, na.rm = TRUE),
    down_both_sites = sum(down_both, na.rm = TRUE),
    median_Pal1_log2FC = median(Pal1_log2FC, na.rm = TRUE),
    median_Pal5_log2FC = median(Pal5_log2FC, na.rm = TRUE),
    median_dose_delta = median(dose_delta, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  arrange(
    desc(substrate_gene == "RB1"),
    Pal5_log2FC = median_Pal5_log2FC
  )

# ----------------------------------------------------------------------------
# 7. RB1 focused analysis
# ----------------------------------------------------------------------------
rb1_all_sites <- site_data %>%
  filter(
    str_detect(
      paste0(";", str_to_upper(as.character(`Gene name`)), ";"),
      "(^|;)RB1(;|$)"
    ) |
      str_to_upper(as.character(`Gene name`)) == "RB1"
  ) %>%
  distinct(site_id, .keep_all = TRUE) %>%
  mutate(
    site_label = paste0(`Amino acid`, Position),
    is_known_CDK46_site = site_id %in% known_site_matches_union$site_id,
    Pal1_down = !is.na(`Pal1/Con P value`) &
      `Pal1/Con P value` < 0.05 &
      !is.na(Pal1_log2FC) &
      Pal1_log2FC < 0,
    Pal5_down = !is.na(`Pal5/Con P value`) &
      `Pal5/Con P value` < 0.05 &
      !is.na(Pal5_log2FC) &
      Pal5_log2FC < 0,
    dose_delta = Pal5_log2FC - Pal1_log2FC
  ) %>%
  arrange(Position)

rb1_known_sites <- rb1_all_sites %>%
  filter(is_known_CDK46_site)

rb1_summary <- tibble(
  n_RB1_sites_detected = nrow(rb1_all_sites),
  n_RB1_known_CDK46_sites_detected = nrow(rb1_known_sites),
  Pal1_known_sites_down = sum(rb1_known_sites$Pal1_down, na.rm = TRUE),
  Pal5_known_sites_down = sum(rb1_known_sites$Pal5_down, na.rm = TRUE),
  median_RB1_known_Pal1 = ifelse(
    nrow(rb1_known_sites) > 0,
    median(rb1_known_sites$Pal1_log2FC, na.rm = TRUE),
    NA_real_
  ),
  median_RB1_known_Pal5 = ifelse(
    nrow(rb1_known_sites) > 0,
    median(rb1_known_sites$Pal5_log2FC, na.rm = TRUE),
    NA_real_
  )
)

# ----------------------------------------------------------------------------
# 8. Within-substrate protein comparison:
#    known CDK4/6 site vs other sites on the same proteins
# ----------------------------------------------------------------------------
known_substrate_accessions <- unique(
  known_site_matches_union$protein_accession_clean
)

same_protein_all_sites <- site_data %>%
  filter(
    protein_accession_clean %in% known_substrate_accessions,
    !is.na(site_id)
  ) %>%
  distinct(site_id, .keep_all = TRUE) %>%
  mutate(
    known_CDK46_site = site_id %in% known_site_matches_union$site_id
  )

compare_known_vs_other <- function(
    data,
    fc_col,
    dose
) {

  x <- data %>%
    filter(known_CDK46_site) %>%
    pull(all_of(fc_col))

  y <- data %>%
    filter(!known_CDK46_site) %>%
    pull(all_of(fc_col))

  x <- x[is.finite(x)]
  y <- y[is.finite(y)]

  p <- if (
    length(x) >= 3 &&
      length(y) >= 3
  ) {
    wilcox.test(
      x,
      y,
      alternative = "less",
      exact = FALSE
    )$p.value
  } else {
    NA_real_
  }

  tibble(
    dose = dose,
    n_known_sites = length(x),
    n_other_sites_same_proteins = length(y),
    known_median = median(x, na.rm = TRUE),
    other_median = median(y, na.rm = TRUE),
    median_difference = median(x, na.rm = TRUE) - median(y, na.rm = TRUE),
    wilcox_p_known_more_negative = p
  )
}

known_vs_other_same_protein <- bind_rows(
  compare_known_vs_other(
    same_protein_all_sites,
    "Pal1_log2FC",
    "Pal1"
  ),
  compare_known_vs_other(
    same_protein_all_sites,
    "Pal5_log2FC",
    "Pal5"
  )
) %>%
  mutate(
    p_adjust = p.adjust(
      wilcox_p_known_more_negative,
      method = "BH"
    )
  )

# ----------------------------------------------------------------------------
# 9. Dose behavior among known CDK4/6 sites
# ----------------------------------------------------------------------------
known_dose_pairs <- known_site_matches_union %>%
  filter(
    is.finite(Pal1_log2FC),
    is.finite(Pal5_log2FC)
  ) %>%
  mutate(
    dose_delta = Pal5_log2FC - Pal1_log2FC
  )

known_dose_summary <- tibble(
  n_paired_known_sites = nrow(known_dose_pairs),
  median_Pal1 = median(
    known_dose_pairs$Pal1_log2FC,
    na.rm = TRUE
  ),
  median_Pal5 = median(
    known_dose_pairs$Pal5_log2FC,
    na.rm = TRUE
  ),
  median_delta = median(
    known_dose_pairs$dose_delta,
    na.rm = TRUE
  ),
  fraction_more_negative_at_Pal5 = mean(
    known_dose_pairs$dose_delta < 0,
    na.rm = TRUE
  ),
  paired_wilcox_p = if (
    nrow(known_dose_pairs) >= 3
  ) {
    wilcox.test(
      known_dose_pairs$Pal5_log2FC,
      known_dose_pairs$Pal1_log2FC,
      paired = TRUE,
      exact = FALSE
    )$p.value
  } else {
    NA_real_
  }
)

# ----------------------------------------------------------------------------
# 10. Threshold robustness for known CDK4/6 sites
# ----------------------------------------------------------------------------
thresholds <- c(0, -0.5, -0.6, -1.0)

known_threshold_summary <- map_dfr(
  thresholds,
  function(cutoff) {

    tibble(
      log2fc_cutoff = cutoff,

      Pal1_known_sites_down = sum(
        !is.na(known_site_matches_union$`Pal1/Con P value`) &
          known_site_matches_union$`Pal1/Con P value` < 0.05 &
          !is.na(known_site_matches_union$Pal1_log2FC) &
          known_site_matches_union$Pal1_log2FC < cutoff,
        na.rm = TRUE
      ),

      Pal5_known_sites_down = sum(
        !is.na(known_site_matches_union$`Pal5/Con P value`) &
          known_site_matches_union$`Pal5/Con P value` < 0.05 &
          !is.na(known_site_matches_union$Pal5_log2FC) &
          known_site_matches_union$Pal5_log2FC < cutoff,
        na.rm = TRUE
      ),

      Pal1_fraction_known_sites_down =
        Pal1_known_sites_down /
        max(
          1,
          sum(
            !is.na(
              known_site_matches_union$Pal1_log2FC
            )
          )
        ),

      Pal5_fraction_known_sites_down =
        Pal5_known_sites_down /
        max(
          1,
          sum(
            !is.na(
              known_site_matches_union$Pal5_log2FC
            )
          )
        )
    )
  }
)

# ----------------------------------------------------------------------------
# 11. Candidate prioritization
# ----------------------------------------------------------------------------
candidate_priority <- known_site_matches_union %>%
  mutate(
    priority_score =
      4 * (substrate_gene == "RB1") +
      2 * down_both +
      1 * Pal1_down +
      1 * Pal5_down +
      1 * stronger_at_Pal5 +
      1 * (`Localization probability` >= 0.75),

    evidence_class = case_when(
      substrate_gene == "RB1" &
        down_both ~
        "Highest priority: RB1 known site decreased at both doses",

      down_both ~
        "High priority: known CDK4/6 site decreased at both doses",

      Pal5_down & stronger_at_Pal5 ~
        "Dose-supported candidate",

      Pal1_down | Pal5_down ~
        "Single-dose responsive candidate",

      TRUE ~
        "Detected known site without clear decrease"
    )
  ) %>%
  transmute(
    priority_score,
    evidence_class,
    substrate_gene,
    protein_accession = protein_accession_clean,
    site = paste0(`Amino acid`, Position),
    kinase_source = kinase,
    motif_type,
    localization_probability = `Localization probability`,
    Pal1_log2FC,
    Pal1_p = `Pal1/Con P value`,
    Pal5_log2FC,
    Pal5_p = `Pal5/Con P value`,
    dose_delta,
    source_database,
    source_reference
  ) %>%
  arrange(
    desc(priority_score),
    Pal5_log2FC
  )

# ----------------------------------------------------------------------------
# 12. Figures
# ----------------------------------------------------------------------------
if (nrow(known_site_matches_union) > 0) {

  plot_known <- known_site_matches_union %>%
    select(
      site_id,
      substrate_gene,
      Pal1_log2FC,
      Pal5_log2FC
    ) %>%
    pivot_longer(
      cols = c(
        Pal1_log2FC,
        Pal5_log2FC
      ),
      names_to = "dose",
      values_to = "log2FC"
    ) %>%
    mutate(
      dose = recode(
        dose,
        Pal1_log2FC = "Pal1",
        Pal5_log2FC = "Pal5"
      )
    )

  p_known <- ggplot(
    plot_known,
    aes(
      x = dose,
      y = log2FC,
      group = site_id
    )
  ) +
    geom_line(
      alpha = 0.35
    ) +
    geom_point(
      size = 1.5
    ) +
    geom_hline(
      yintercept = 0,
      linetype = 2
    ) +
    labs(
      title = "Known CDK4/6 substrate phosphosites",
      subtitle = "Paired Pal1-to-Pal5 site-level responses",
      x = NULL,
      y = "log2FC"
    ) +
    theme_bw()

  ggsave(
    file.path(
      r7_figure_dir,
      "01_known_CDK46_substrate_dose_pairs.png"
    ),
    p_known,
    width = 7,
    height = 6,
    dpi = 300
  )
}

if (nrow(rb1_all_sites) > 0) {

  rb1_plot_df <- rb1_all_sites %>%
    select(
      site_label,
      is_known_CDK46_site,
      Pal1_log2FC,
      Pal5_log2FC
    ) %>%
    pivot_longer(
      cols = c(
        Pal1_log2FC,
        Pal5_log2FC
      ),
      names_to = "dose",
      values_to = "log2FC"
    ) %>%
    mutate(
      dose = recode(
        dose,
        Pal1_log2FC = "Pal1",
        Pal5_log2FC = "Pal5"
      )
    )

  p_rb1 <- ggplot(
    rb1_plot_df,
    aes(
      x = site_label,
      y = log2FC,
      shape = is_known_CDK46_site
    )
  ) +
    geom_hline(
      yintercept = 0,
      linetype = 2
    ) +
    geom_point(
      size = 2.5
    ) +
    facet_wrap(
      ~ dose,
      ncol = 1
    ) +
    labs(
      title = "RB1 phosphosite response",
      subtitle = "Known CDK4/6 sites highlighted by point shape",
      x = "RB1 phosphosite",
      y = "log2FC",
      shape = "Known CDK4/6 site"
    ) +
    theme_bw() +
    theme(
      axis.text.x = element_text(
        angle = 45,
        hjust = 1
      )
    )

  ggsave(
    file.path(
      r7_figure_dir,
      "02_RB1_phosphosite_profile.png"
    ),
    p_rb1,
    width = 10,
    height = 8,
    dpi = 300
  )
}

# ----------------------------------------------------------------------------
# 13. Export
# ----------------------------------------------------------------------------
write.xlsx(
  list(
    Coverage_summary = coverage_summary,
    Known_site_validation = site_validation_table,
    Substrate_gene_summary = substrate_gene_summary,
    RB1_summary = rb1_summary,
    RB1_all_detected_sites = rb1_all_sites,
    RB1_known_CDK46_sites = rb1_known_sites,
    Known_vs_other_same_protein = known_vs_other_same_protein,
    Known_site_dose_summary = known_dose_summary,
    Threshold_summary = known_threshold_summary,
    Candidate_priority = candidate_priority,
    Reference_used = cdk46_reference_annotated
  ),
  file = file.path(
    r7_table_dir,
    "01_R7_known_CDK46_substrate_validation.xlsx"
  ),
  overwrite = TRUE
)

write_csv(
  candidate_priority,
  file.path(
    r7_table_dir,
    "02_R7_priority_known_CDK46_sites.csv"
  )
)

write_csv(
  rb1_all_sites,
  file.path(
    r7_table_dir,
    "03_R7_RB1_all_detected_phosphosites.csv"
  )
)

message(
  "\n============================================================\n",
  "R7.0 completed.\n\n",
  "主要输出：\n",
  "1) tables/01_R7_known_CDK46_substrate_validation.xlsx\n",
  "2) tables/02_R7_priority_known_CDK46_sites.csv\n",
  "3) tables/03_R7_RB1_all_detected_phosphosites.csv\n\n",
  "优先查看 sheet：\n",
  "- Coverage_summary\n",
  "- Known_site_validation\n",
  "- RB1_summary\n",
  "- RB1_all_detected_sites\n",
  "- Known_vs_other_same_protein\n",
  "- Known_site_dose_summary\n",
  "- Candidate_priority\n",
  "============================================================\n"
)
