
# =============================================================================
# R10. Quantified phosphosite-count bias control
#
# Supervisor question:
# Proteins with many quantified phosphosites have a greater chance of containing
# an extreme negative site in a minimum-site analysis. Do the mitotic/RZZ/SAC/
# kinetochore signals remain after controlling for the number of quantified
# phosphosites per protein?
#
# Main analyses:
#   A. Protein-level site-count QC
#   B. Site-count-matched permutation of the minimum-site statistic
#   C. Regression: minimum log2FC ~ target membership + log1p(site count)
#   D. Logistic regression across the four foreground thresholds:
#        any significant-down site ~ target membership + log1p(site count)
#
# Required objects already in R:
#   site_data
#   pal1_background
#   pal5_background
#   target_gene_sets
#   analysis_dir
#
# No R8/R9 objects are required.
# =============================================================================

suppressPackageStartupMessages({
  library(tidyverse)
  library(openxlsx)
})

set.seed(20260816)

# -----------------------------------------------------------------------------
# 0. Input checks and output folders
# -----------------------------------------------------------------------------

required_objects <- c(
  "site_data",
  "pal1_background",
  "pal5_background",
  "target_gene_sets",
  "analysis_dir"
)

missing_objects <- required_objects[
  !vapply(required_objects, exists, logical(1), inherits = TRUE)
]

if (length(missing_objects) > 0) {
  stop(
    paste0(
      "R10 requires: ",
      paste(missing_objects, collapse = ", "),
      "\nPlease run/source the earlier preprocessing scripts that create these objects."
    )
  )
}

required_cols <- c(
  "site_id",
  "protein_accession_clean",
  "Gene name",
  "Pal1_log2FC",
  "Pal5_log2FC",
  "Pal1/Con P value",
  "Pal5/Con P value"
)

missing_cols <- setdiff(required_cols, colnames(site_data))

if (length(missing_cols) > 0) {
  stop(
    paste0(
      "site_data is missing required columns: ",
      paste(missing_cols, collapse = ", ")
    )
  )
}

r10_dir <- file.path(analysis_dir, "R10_site_count_bias_control")
r10_table_dir <- file.path(r10_dir, "tables")
r10_figure_dir <- file.path(r10_dir, "figures")

dir.create(r10_table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(r10_figure_dir, recursive = TRUE, showWarnings = FALSE)

# -----------------------------------------------------------------------------
# 1. Helpers
# -----------------------------------------------------------------------------

split_gene_symbols_r10 <- function(data) {
  data %>%
    mutate(gene_symbol_raw = `Gene name`) %>%
    separate_rows(
      gene_symbol_raw,
      sep = "[;,/| ]+"
    ) %>%
    mutate(
      gene_symbol = str_trim(gene_symbol_raw)
    ) %>%
    filter(
      !is.na(gene_symbol),
      gene_symbol != ""
    )
}

# Site-count strata chosen to preserve practical matching while allowing enough
# background proteins in each stratum.
site_count_stratum <- function(n) {
  case_when(
    n == 1 ~ "1",
    n == 2 ~ "2",
    n >= 3  & n <= 4  ~ "3-4",
    n >= 5  & n <= 8  ~ "5-8",
    n >= 9  & n <= 16 ~ "9-16",
    n >= 17 & n <= 32 ~ "17-32",
    n >= 33            ~ "33+",
    TRUE ~ NA_character_
  )
}

log2fc_cutoffs <- c(
  "lt0" = 0,
  "lt_m0.5" = -0.5,
  "lt_m0.6" = -0.6,
  "lt_m1.0" = -1.0
)

# -----------------------------------------------------------------------------
# 2. Build one-row-per-gene protein-level datasets for Pal1 and Pal5
# -----------------------------------------------------------------------------
# Why gene level?
# target_gene_sets are gene-symbol based, and the previous pathway analyses were
# interpreted at protein/gene level. Multiple UniProt accessions mapping to the
# same gene are therefore combined for this sensitivity analysis.
#
# n_quantified_sites = unique phosphosites quantified for that gene in that dose.
# min_log2FC        = most negative quantified phosphosite for that gene.
# median_log2FC     = median across quantified phosphosites for comparison.
# -----------------------------------------------------------------------------

build_protein_level <- function(
    background_data,
    log2fc_col,
    p_col,
    dose
) {

  long <- split_gene_symbols_r10(background_data) %>%
    filter(
      !is.na({{ log2fc_col }}),
      !is.na({{ p_col }})
    ) %>%
    distinct(
      gene_symbol,
      site_id,
      .keep_all = TRUE
    )

  out <- long %>%
    group_by(gene_symbol) %>%
    summarise(
      n_quantified_sites = n_distinct(site_id),
      min_log2FC = min({{ log2fc_col }}, na.rm = TRUE),
      median_log2FC = median({{ log2fc_col }}, na.rm = TRUE),
      mean_log2FC = mean({{ log2fc_col }}, na.rm = TRUE),

      any_down_lt0 =
        any({{ p_col }} < 0.05 & {{ log2fc_col }} < 0, na.rm = TRUE),

      any_down_lt_m0.5 =
        any({{ p_col }} < 0.05 & {{ log2fc_col }} < -0.5, na.rm = TRUE),

      any_down_lt_m0.6 =
        any({{ p_col }} < 0.05 & {{ log2fc_col }} < -0.6, na.rm = TRUE),

      any_down_lt_m1.0 =
        any({{ p_col }} < 0.05 & {{ log2fc_col }} < -1.0, na.rm = TRUE),

      .groups = "drop"
    ) %>%
    mutate(
      dose = dose,
      log_site_count = log1p(n_quantified_sites),
      site_count_stratum = site_count_stratum(n_quantified_sites)
    )

  out
}

protein_pal1 <- build_protein_level(
  pal1_background,
  Pal1_log2FC,
  `Pal1/Con P value`,
  "Pal1"
)

protein_pal5 <- build_protein_level(
  pal5_background,
  Pal5_log2FC,
  `Pal5/Con P value`,
  "Pal5"
)

protein_level_all <- bind_rows(
  protein_pal1,
  protein_pal5
)

# -----------------------------------------------------------------------------
# 3. Add target-set membership
# -----------------------------------------------------------------------------

target_names <- names(target_gene_sets)

if (is.null(target_names) || any(target_names == "")) {
  stop("target_gene_sets must be a named list.")
}

add_target_membership <- function(protein_df) {

  out <- protein_df

  for (nm in target_names) {
    col_nm <- paste0("target__", make.names(nm))
    out[[col_nm]] <- out$gene_symbol %in% target_gene_sets[[nm]]
  }

  out
}

protein_pal1 <- add_target_membership(protein_pal1)
protein_pal5 <- add_target_membership(protein_pal5)
protein_level_all <- bind_rows(protein_pal1, protein_pal5)

# -----------------------------------------------------------------------------
# 4. Basic site-count comparison: are target proteins more heavily quantified?
# -----------------------------------------------------------------------------

site_count_comparison_one <- function(protein_df, target_genes, target_name, dose) {

  dat <- protein_df %>%
    mutate(is_target = gene_symbol %in% target_genes)

  x <- dat$n_quantified_sites[dat$is_target]
  y <- dat$n_quantified_sites[!dat$is_target]

  if (length(x) < 2 || length(y) < 2) {
    return(tibble())
  }

  wt <- wilcox.test(
    x,
    y,
    alternative = "two.sided",
    exact = FALSE
  )

  tibble(
    dose = dose,
    target = target_name,
    n_target_proteins = length(x),
    n_background_proteins = length(y),
    median_sites_target = median(x, na.rm = TRUE),
    median_sites_background = median(y, na.rm = TRUE),
    mean_sites_target = mean(x, na.rm = TRUE),
    mean_sites_background = mean(y, na.rm = TRUE),
    wilcox_p = wt$p.value
  )
}

site_count_comparison <- bind_rows(
  imap_dfr(
    target_gene_sets,
    ~ site_count_comparison_one(
      protein_pal1,
      .x,
      .y,
      "Pal1"
    )
  ),
  imap_dfr(
    target_gene_sets,
    ~ site_count_comparison_one(
      protein_pal5,
      .x,
      .y,
      "Pal5"
    )
  )
) %>%
  group_by(dose) %>%
  mutate(
    wilcox_FDR = p.adjust(
      wilcox_p,
      method = "BH"
    )
  ) %>%
  ungroup()

# -----------------------------------------------------------------------------
# 5. Site-count-matched permutation
# -----------------------------------------------------------------------------
# For each target set:
#   - calculate observed median(min_log2FC) among target proteins
#   - preserve the target proteins' site-count-stratum distribution
#   - repeatedly sample non-target proteins from the same strata
#   - compare matched-null median(min_log2FC) to the observed statistic
#
# Empirical one-sided P:
#   probability matched null is <= observed
#   (smaller/more negative = stronger downward target response)
# -----------------------------------------------------------------------------

N_PERM <- 10000

matched_permutation_one <- function(
    protein_df,
    target_genes,
    target_name,
    dose,
    n_perm = N_PERM
) {

  dat <- protein_df %>%
    filter(
      !is.na(min_log2FC),
      !is.na(site_count_stratum)
    ) %>%
    mutate(
      is_target = gene_symbol %in% target_genes
    )

  target_df <- dat %>%
    filter(is_target)

  control_df <- dat %>%
    filter(!is_target)

  if (nrow(target_df) < 3) {
    return(
      tibble(
        dose = dose,
        target = target_name,
        n_target = nrow(target_df),
        observed_median_min_log2FC = NA_real_,
        matched_null_median = NA_real_,
        matched_null_sd = NA_real_,
        empirical_p_more_negative = NA_real_,
        percentile_in_null = NA_real_,
        z_like = NA_real_,
        n_perm = n_perm,
        sampling_with_replacement_used = NA
      )
    )
  }

  stratum_counts <- target_df %>%
    count(site_count_stratum, name = "n_needed")

  replacement_used <- FALSE

  null_stats <- replicate(
    n_perm,
    {

      sampled <- map2_dfr(
        stratum_counts$site_count_stratum,
        stratum_counts$n_needed,
        function(stratum, n_needed) {

          pool <- control_df %>%
            filter(site_count_stratum == stratum)

          if (nrow(pool) == 0) {
            # Fallback: nearest log-site-count controls if a stratum is empty.
            target_n_values <- target_df %>%
              filter(site_count_stratum == stratum) %>%
              pull(n_quantified_sites)

            target_center <- median(target_n_values)

            pool <- control_df %>%
              mutate(
                count_distance =
                  abs(log1p(n_quantified_sites) - log1p(target_center))
              ) %>%
              arrange(count_distance) %>%
              slice_head(n = max(20, n_needed))
          }

          replace_now <- nrow(pool) < n_needed
          if (replace_now) {
            replacement_used <<- TRUE
          }

          pool %>%
            slice_sample(
              n = n_needed,
              replace = replace_now
            )
        }
      )

      median(sampled$min_log2FC, na.rm = TRUE)
    }
  )

  observed <- median(
    target_df$min_log2FC,
    na.rm = TRUE
  )

  empirical_p <- (
    sum(null_stats <= observed, na.rm = TRUE) + 1
  ) / (
    sum(!is.na(null_stats)) + 1
  )

  null_mean <- mean(null_stats, na.rm = TRUE)
  null_sd <- sd(null_stats, na.rm = TRUE)

  z_like <- if (
    is.finite(null_sd) &&
    null_sd > 0
  ) {
    (observed - null_mean) / null_sd
  } else {
    NA_real_
  }

  tibble(
    dose = dose,
    target = target_name,
    n_target = nrow(target_df),
    observed_median_min_log2FC = observed,
    matched_null_median = median(null_stats, na.rm = TRUE),
    matched_null_mean = null_mean,
    matched_null_sd = null_sd,
    empirical_p_more_negative = empirical_p,
    percentile_in_null = mean(null_stats <= observed, na.rm = TRUE),
    z_like = z_like,
    n_perm = n_perm,
    sampling_with_replacement_used = replacement_used
  )
}

matched_permutation <- bind_rows(
  imap_dfr(
    target_gene_sets,
    ~ matched_permutation_one(
      protein_pal1,
      .x,
      .y,
      "Pal1"
    )
  ),
  imap_dfr(
    target_gene_sets,
    ~ matched_permutation_one(
      protein_pal5,
      .x,
      .y,
      "Pal5"
    )
  )
) %>%
  group_by(dose) %>%
  mutate(
    empirical_FDR = p.adjust(
      empirical_p_more_negative,
      method = "BH"
    )
  ) %>%
  ungroup()

# -----------------------------------------------------------------------------
# 6. Regression on minimum-site log2FC
# -----------------------------------------------------------------------------
# Model:
#   min_log2FC ~ is_target + log1p(n_quantified_sites)
#
# target_beta < 0 means target proteins remain more negative after adjustment.
# -----------------------------------------------------------------------------

extract_lm_target <- function(model) {

  sm <- summary(model)$coefficients

  if (!"is_targetTRUE" %in% rownames(sm)) {
    return(
      tibble(
        target_beta = NA_real_,
        target_SE = NA_real_,
        target_t = NA_real_,
        target_p = NA_real_,
        site_count_beta = NA_real_,
        site_count_p = NA_real_,
        model_R2 = NA_real_
      )
    )
  }

  site_row <- if (
    "log_site_count" %in% rownames(sm)
  ) {
    sm["log_site_count", ]
  } else {
    rep(NA_real_, 4)
  }

  tibble(
    target_beta = sm["is_targetTRUE", "Estimate"],
    target_SE = sm["is_targetTRUE", "Std. Error"],
    target_t = sm["is_targetTRUE", "t value"],
    target_p = sm["is_targetTRUE", "Pr(>|t|)"],
    site_count_beta = site_row["Estimate"],
    site_count_p = site_row["Pr(>|t|)"],
    model_R2 = summary(model)$r.squared
  )
}

minimum_regression_one <- function(
    protein_df,
    target_genes,
    target_name,
    dose
) {

  dat <- protein_df %>%
    filter(
      !is.na(min_log2FC),
      !is.na(log_site_count)
    ) %>%
    mutate(
      is_target = gene_symbol %in% target_genes
    )

  if (
    sum(dat$is_target) < 3 ||
    sum(!dat$is_target) < 10
  ) {
    return(tibble())
  }

  fit <- lm(
    min_log2FC ~ is_target + log_site_count,
    data = dat
  )

  extract_lm_target(fit) %>%
    mutate(
      dose = dose,
      target = target_name,
      n_total = nrow(dat),
      n_target = sum(dat$is_target)
    ) %>%
    relocate(dose, target, n_total, n_target)
}

minimum_regression <- bind_rows(
  imap_dfr(
    target_gene_sets,
    ~ minimum_regression_one(
      protein_pal1,
      .x,
      .y,
      "Pal1"
    )
  ),
  imap_dfr(
    target_gene_sets,
    ~ minimum_regression_one(
      protein_pal5,
      .x,
      .y,
      "Pal5"
    )
  )
) %>%
  group_by(dose) %>%
  mutate(
    target_FDR = p.adjust(
      target_p,
      method = "BH"
    )
  ) %>%
  ungroup()

# -----------------------------------------------------------------------------
# 7. Logistic regression across the four threshold foreground definitions
# -----------------------------------------------------------------------------
# This complements the minimum-site model and directly addresses whether target
# proteins are more likely to contain a significant-down phosphosite after
# accounting for site count.
#
# Model:
#   any_down ~ is_target + log1p(n_quantified_sites)
# -----------------------------------------------------------------------------

safe_logistic_one <- function(
    protein_df,
    target_genes,
    target_name,
    dose,
    response_col,
    cutoff_name
) {

  dat <- protein_df %>%
    mutate(
      is_target = gene_symbol %in% target_genes,
      response = .data[[response_col]]
    ) %>%
    filter(
      !is.na(response),
      !is.na(log_site_count)
    )

  if (
    sum(dat$is_target) < 3 ||
    length(unique(dat$response)) < 2
  ) {
    return(tibble())
  }

  fit <- tryCatch(
    glm(
      response ~ is_target + log_site_count,
      data = dat,
      family = binomial()
    ),
    error = function(e) NULL
  )

  if (is.null(fit)) {
    return(tibble())
  }

  co <- summary(fit)$coefficients

  if (!"is_targetTRUE" %in% rownames(co)) {
    return(tibble())
  }

  beta <- co["is_targetTRUE", "Estimate"]
  se <- co["is_targetTRUE", "Std. Error"]
  p <- co["is_targetTRUE", "Pr(>|z|)"]

  count_beta <- if (
    "log_site_count" %in% rownames(co)
  ) {
    co["log_site_count", "Estimate"]
  } else {
    NA_real_
  }

  count_p <- if (
    "log_site_count" %in% rownames(co)
  ) {
    co["log_site_count", "Pr(>|z|)"]
  } else {
    NA_real_
  }

  tibble(
    dose = dose,
    cutoff = cutoff_name,
    target = target_name,
    n_total = nrow(dat),
    n_target = sum(dat$is_target),
    n_response_positive = sum(dat$response),
    target_beta_log_odds = beta,
    target_adjusted_OR = exp(beta),
    target_OR_conf_low = exp(beta - 1.96 * se),
    target_OR_conf_high = exp(beta + 1.96 * se),
    target_p = p,
    site_count_beta = count_beta,
    site_count_OR_per_log1p_unit = exp(count_beta),
    site_count_p = count_p
  )
}

response_map <- c(
  "lt0" = "any_down_lt0",
  "lt_m0.5" = "any_down_lt_m0.5",
  "lt_m0.6" = "any_down_lt_m0.6",
  "lt_m1.0" = "any_down_lt_m1.0"
)

logistic_results <- bind_rows(
  lapply(
    c("Pal1", "Pal5"),
    function(dose) {

      protein_df <- if (dose == "Pal1") {
        protein_pal1
      } else {
        protein_pal5
      }

      bind_rows(
        lapply(
          names(response_map),
          function(cutoff_name) {

            response_col <- response_map[[cutoff_name]]

            imap_dfr(
              target_gene_sets,
              ~ safe_logistic_one(
                protein_df = protein_df,
                target_genes = .x,
                target_name = .y,
                dose = dose,
                response_col = response_col,
                cutoff_name = cutoff_name
              )
            )
          }
        )
      )
    }
  )
) %>%
  group_by(dose, cutoff) %>%
  mutate(
    target_FDR = p.adjust(
      target_p,
      method = "BH"
    )
  ) %>%
  ungroup()

logistic_stability <- logistic_results %>%
  group_by(
    dose,
    target
  ) %>%
  summarise(
    n_thresholds_tested = n(),
    thresholds_adjusted_OR_gt1 =
      sum(target_adjusted_OR > 1, na.rm = TRUE),
    thresholds_FDR_lt_005 =
      sum(target_FDR < 0.05, na.rm = TRUE),
    thresholds_FDR_lt_020 =
      sum(target_FDR < 0.20, na.rm = TRUE),
    median_adjusted_OR =
      median(target_adjusted_OR, na.rm = TRUE),
    best_FDR =
      min(target_FDR, na.rm = TRUE),
    .groups = "drop"
  )

# -----------------------------------------------------------------------------
# 8. Target-specific protein tables for biological inspection
# -----------------------------------------------------------------------------

target_protein_detail <- bind_rows(
  imap_dfr(
    target_gene_sets,
    function(genes, nm) {
      protein_pal1 %>%
        filter(gene_symbol %in% genes) %>%
        mutate(target = nm)
    }
  ),
  imap_dfr(
    target_gene_sets,
    function(genes, nm) {
      protein_pal5 %>%
        filter(gene_symbol %in% genes) %>%
        mutate(target = nm)
    }
  )
) %>%
  select(
    dose,
    target,
    gene_symbol,
    n_quantified_sites,
    site_count_stratum,
    min_log2FC,
    median_log2FC,
    mean_log2FC,
    starts_with("any_down_")
  ) %>%
  arrange(
    dose,
    target,
    min_log2FC
  )

# -----------------------------------------------------------------------------
# 9. Figures
# -----------------------------------------------------------------------------

# Figure 1: site-count distribution in targets vs all other proteins
plot_site_counts <- bind_rows(
  imap_dfr(
    target_gene_sets,
    function(genes, nm) {
      protein_pal1 %>%
        transmute(
          dose = "Pal1",
          target = nm,
          class = if_else(
            gene_symbol %in% genes,
            "Target",
            "Other"
          ),
          n_quantified_sites
        )
    }
  ),
  imap_dfr(
    target_gene_sets,
    function(genes, nm) {
      protein_pal5 %>%
        transmute(
          dose = "Pal5",
          target = nm,
          class = if_else(
            gene_symbol %in% genes,
            "Target",
            "Other"
          ),
          n_quantified_sites
        )
    }
  )
) %>%
  ggplot(
    aes(
      x = class,
      y = n_quantified_sites
    )
  ) +
  geom_boxplot(
    outlier.shape = NA
  ) +
  geom_jitter(
    width = 0.15,
    alpha = 0.12,
    size = 0.7
  ) +
  scale_y_log10() +
  facet_grid(
    dose ~ target,
    scales = "free_x"
  ) +
  labs(
    title = "Quantified phosphosite counts in target versus background proteins",
    x = NULL,
    y = "Quantified phosphosites per protein/gene (log10 scale)"
  ) +
  theme_bw() +
  theme(
    axis.text.x = element_text(
      angle = 30,
      hjust = 1
    )
  )

ggsave(
  file.path(
    r10_figure_dir,
    "01_target_site_count_distributions.png"
  ),
  plot_site_counts,
  width = 14,
  height = 7,
  dpi = 300
)

# Figure 2: observed minimum-site statistic vs matched null
plot_perm <- matched_permutation %>%
  filter(
    !is.na(observed_median_min_log2FC),
    !is.na(matched_null_median)
  ) %>%
  select(
    dose,
    target,
    observed_median_min_log2FC,
    matched_null_median
  ) %>%
  pivot_longer(
    cols = c(
      observed_median_min_log2FC,
      matched_null_median
    ),
    names_to = "stat_type",
    values_to = "median_min_log2FC"
  ) %>%
  mutate(
    stat_type = recode(
      stat_type,
      observed_median_min_log2FC = "Observed target",
      matched_null_median = "Site-count-matched null"
    )
  ) %>%
  ggplot(
    aes(
      x = target,
      y = median_min_log2FC,
      shape = stat_type,
      group = stat_type
    )
  ) +
  geom_hline(
    yintercept = 0,
    linetype = 2
  ) +
  geom_point(
    size = 2.6,
    position = position_dodge(width = 0.4)
  ) +
  facet_wrap(~ dose) +
  labs(
    title = "Minimum-site response after matching for quantified site count",
    x = NULL,
    y = "Median minimum phosphosite log2FC"
  ) +
  theme_bw() +
  theme(
    axis.text.x = element_text(
      angle = 35,
      hjust = 1
    ),
    legend.position = "bottom"
  )

ggsave(
  file.path(
    r10_figure_dir,
    "02_site_count_matched_permutation_summary.png"
  ),
  plot_perm,
  width = 10,
  height = 6,
  dpi = 300
)

# Figure 3: regression target coefficients
plot_reg <- minimum_regression %>%
  filter(
    !is.na(target_beta),
    !is.na(target_SE)
  ) %>%
  mutate(
    conf_low = target_beta - 1.96 * target_SE,
    conf_high = target_beta + 1.96 * target_SE
  ) %>%
  ggplot(
    aes(
      x = target_beta,
      y = fct_reorder(target, target_beta)
    )
  ) +
  geom_vline(
    xintercept = 0,
    linetype = 2
  ) +
  geom_errorbarh(
    aes(
      xmin = conf_low,
      xmax = conf_high
    ),
    height = 0.2
  ) +
  geom_point(size = 2.5) +
  facet_wrap(~ dose, scales = "free_y") +
  labs(
    title = "Target effect after adjustment for quantified phosphosite count",
    subtitle = "Linear model: minimum log2FC ~ target + log1p(site count)",
    x = "Adjusted target coefficient (negative = stronger downward response)",
    y = NULL
  ) +
  theme_bw()

ggsave(
  file.path(
    r10_figure_dir,
    "03_minimum_site_regression_adjusted_coefficients.png"
  ),
  plot_reg,
  width = 9,
  height = 6,
  dpi = 300
)

# -----------------------------------------------------------------------------
# 10. Compact integrated summary
# -----------------------------------------------------------------------------

integrated_summary <- matched_permutation %>%
  select(
    dose,
    target,
    n_target,
    observed_median_min_log2FC,
    matched_null_median,
    empirical_p_more_negative,
    empirical_FDR
  ) %>%
  left_join(
    minimum_regression %>%
      select(
        dose,
        target,
        target_beta,
        target_p,
        target_FDR,
        site_count_beta,
        site_count_p
      ),
    by = c("dose", "target")
  ) %>%
  left_join(
    logistic_stability %>%
      select(
        dose,
        target,
        thresholds_adjusted_OR_gt1,
        thresholds_FDR_lt_005,
        thresholds_FDR_lt_020,
        median_adjusted_OR,
        best_FDR
      ),
    by = c("dose", "target")
  ) %>%
  mutate(
    matched_perm_support =
      !is.na(empirical_FDR) &
      empirical_FDR < 0.20 &
      observed_median_min_log2FC < matched_null_median,

    min_regression_support =
      !is.na(target_FDR) &
      target_FDR < 0.20 &
      target_beta < 0,

    threshold_regression_support =
      thresholds_adjusted_OR_gt1 >= 3,

    support_layers =
      matched_perm_support +
      min_regression_support +
      threshold_regression_support,

    interpretation = case_when(
      support_layers >= 3 ~
        "Strong site-count-adjusted support",

      support_layers == 2 ~
        "Moderate site-count-adjusted support",

      support_layers == 1 ~
        "Limited/exploratory support",

      TRUE ~
        "No clear site-count-adjusted support"
    )
  )

# -----------------------------------------------------------------------------
# 11. Export workbook
# -----------------------------------------------------------------------------

output_xlsx <- file.path(
  r10_table_dir,
  "01_R10_site_count_bias_control.xlsx"
)

openxlsx::write.xlsx(
  list(
    Protein_level_all =
      protein_level_all,

    Site_count_comparison =
      site_count_comparison,

    Matched_permutation =
      matched_permutation,

    Minimum_regression =
      minimum_regression,

    Logistic_threshold_all =
      logistic_results,

    Logistic_stability =
      logistic_stability,

    Target_protein_detail =
      target_protein_detail,

    Integrated_summary =
      integrated_summary
  ),
  file = output_xlsx,
  overwrite = TRUE
)

readr::write_csv(
  matched_permutation,
  file.path(
    r10_table_dir,
    "02_site_count_matched_permutation.csv"
  )
)

readr::write_csv(
  minimum_regression,
  file.path(
    r10_table_dir,
    "03_minimum_site_regression.csv"
  )
)

readr::write_csv(
  logistic_stability,
  file.path(
    r10_table_dir,
    "04_threshold_logistic_stability.csv"
  )
)

readr::write_csv(
  integrated_summary,
  file.path(
    r10_table_dir,
    "05_R10_integrated_summary.csv"
  )
)

# -----------------------------------------------------------------------------
# 12. Console output / interpretation guide
# -----------------------------------------------------------------------------

cat("\n============================================================\n")
cat("R10 site-count bias-control analysis completed.\n")
cat("============================================================\n\n")

cat("A. Do target proteins have more quantified sites?\n")
print(site_count_comparison)

cat("\nB. Site-count-matched permutation:\n")
print(matched_permutation)

cat("\nC. Minimum-site regression adjusted for site count:\n")
print(minimum_regression)

cat("\nD. Threshold logistic-regression stability:\n")
print(logistic_stability)

cat("\nE. Integrated summary:\n")
print(integrated_summary)

cat("\nMain workbook:\n")
cat(output_xlsx, "\n\n")

cat(
  "Interpretation guide:\n",
  "1. Site_count_comparison tells you whether mitotic target proteins really have more quantified sites.\n",
  "2. In Matched_permutation, observed_median_min_log2FC < matched_null_median and small empirical P/FDR supports a target-specific negative response beyond site-count bias.\n",
  "3. In Minimum_regression, target_beta < 0 means target membership remains associated with a more negative minimum site after adjusting for site count.\n",
  "4. In Logistic_threshold_all, adjusted target OR > 1 means target proteins remain more likely to contain a significant-down site after controlling for site count.\n",
  "5. Site-count effects themselves may be significant; that is expected and does not invalidate the target signal if the adjusted target effect remains.\n",
  sep = ""
)
