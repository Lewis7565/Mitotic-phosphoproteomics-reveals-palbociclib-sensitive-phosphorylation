# ============================================================================
# 磷酸化组后续分析
# 路线：
# 全局 ORA + 排序型 GSEA
# → Pal1/Pal5 一致性比较
# → SAC/动粒/RZZ 目标验证
# → 激酶特征分析
# → 已知 CDK4/6 底物验证
#
# 使用说明：
# 1. 本代码直接接在原脚本末尾运行。
# 2. 默认原脚本已经生成：
#    site_data, pal1_background, pal5_background, pal1_down, pal5_down
# 3. GO/Reactome 分析可直接运行。
# 4. 激酶和已知 CDK4/6 底物分析依赖外部 CSV；若文件不存在，
#    程序会自动创建模板并跳过对应分析，不会中断前面结果。
# ============================================================================


# ============================================================================
# 0. 安装并加载后续分析所需 R 包
# ============================================================================

cran_packages <- c(
  "dplyr",
  "tidyr",
  "stringr",
  "purrr",
  "tibble",
  "ggplot2",
  "readr",
  "openxlsx",
  "forcats"
)

bioc_packages <- c(
  "clusterProfiler",
  "org.Hs.eg.db",
  "GO.db",
  "AnnotationDbi",
  "ReactomePA",
  "enrichplot"
)
# 在加载完所有包之后，强制指定 select 的默认行为
select <- dplyr::select   # 让 dplyr::select 成为默认
install_if_missing <- function(pkgs, bioconductor = FALSE) {
  missing_pkgs <- pkgs[
    !vapply(
      pkgs,
      requireNamespace,
      FUN.VALUE = logical(1),
      quietly = TRUE
    )
  ]

  if (length(missing_pkgs) == 0) {
    return(invisible(NULL))
  }

  if (bioconductor) {
    if (!requireNamespace("BiocManager", quietly = TRUE)) {
      install.packages("BiocManager")
    }

    BiocManager::install(
      missing_pkgs,
      ask = FALSE,
      update = FALSE
    )
  } else {
    install.packages(missing_pkgs)
  }
}

install_if_missing(cran_packages, bioconductor = FALSE)
install_if_missing(bioc_packages, bioconductor = TRUE)

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(stringr)
  library(purrr)
  library(tibble)
  library(ggplot2)
  library(readr)
  library(openxlsx)
  library(forcats)

  library(clusterProfiler)
  library(org.Hs.eg.db)
  library(GO.db)
  library(AnnotationDbi)
  library(ReactomePA)
  library(enrichplot)
})


# ============================================================================
# 1. 参数与结果目录
# ============================================================================

# Portable project path supplied by 00_run_pipeline.R.
if (!exists("project_root", inherits = TRUE)) {
  project_root <- normalizePath(getwd(), winslash = "/", mustWork = TRUE)
}
project_dir <- project_root

analysis_dir <- file.path(
  project_dir,
  "results"
)

table_dir <- file.path(analysis_dir, "tables")
figure_dir <- file.path(analysis_dir, "figures")
template_dir <- file.path(analysis_dir, "input_templates")

dir.create(analysis_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(template_dir, recursive = TRUE, showWarnings = FALSE)

set.seed(20260727)

p_cutoff <- 0.05
q_cutoff <- 0.20
gsea_min_size <- 10
gsea_max_size <- 500
gsea_eps <- 1e-20

# 重点有丝分裂条目关键词。
mitosis_keywords <- c(
  "mitotic",
  "mitosis",
  "kinetochore",
  "centromere",
  "spindle",
  "chromosome segregation",
  "sister chromatid",
  "checkpoint",
  "microtubule attachment",
  "fibrous corona",
  "RZZ",
  "Rod-Zwilch-ZW10"
)

mitosis_keyword_regex <- paste(
  mitosis_keywords,
  collapse = "|"
)


# ============================================================================
# 2. 输入对象检查
# ============================================================================

required_objects <- c(
  "site_data",
  "pal1_background",
  "pal5_background",
  "pal1_down",
  "pal5_down"
)

missing_objects <- required_objects[
  !vapply(
    required_objects,
    exists,
    FUN.VALUE = logical(1),
    inherits = TRUE
  )
]

if (length(missing_objects) > 0) {
  stop(
    paste0(
      "缺少以下原脚本对象：",
      paste(missing_objects, collapse = ", "),
      "\n请先完整运行上一步代码。"
    )
  )
}

required_columns <- c(
  "Gene name",
  "Protein accession",
  "Position",
  "Amino acid",
  "site_id",
  "motif_sequence_15mer",
  "motif_type",
  "Pal1_log2FC",
  "Pal5_log2FC",
  "Pal1_rank_score",
  "Pal5_rank_score",
  "Pal1/Con P value",
  "Pal5/Con P value"
)

missing_columns <- setdiff(
  required_columns,
  colnames(site_data)
)

if (length(missing_columns) > 0) {
  stop(
    paste0(
      "site_data 缺少以下字段：",
      paste(missing_columns, collapse = ", ")
    )
  )
}


# ============================================================================
# 3. 补充 SF motif，并重建背景集和前景集
# ============================================================================

site_data <- site_data %>%
  mutate(
    plus1_aa = substr(
      motif_sequence_15mer,
      9,
      9
    ),

    motif_type = case_when(
      motif_center_aa == "S" &
        plus1_aa == "P" ~ "SP",

      motif_center_aa == "T" &
        plus1_aa == "P" ~ "TP",

      motif_center_aa == "S" &
        plus1_aa == "F" ~ "SF",

      motif_center_aa == "S" ~ "Other_S",

      motif_center_aa == "T" ~ "Other_T",

      motif_center_aa == "Y" ~ "Y",

      TRUE ~ NA_character_
    ),

    proline_directed =
      motif_type %in% c("SP", "TP"),

    sf_positive =
      motif_type == "SF"
  )

pal1_background <- site_data %>%
  filter(
    !is.na(motif_sequence_15mer),
    motif_center_aa %in% c("S", "T"),
    !is.na(`Pal1/Con Ratio`),
    `Pal1/Con Ratio` > 0,
    !is.na(`Pal1/Con P value`),
    !is.na(Pal1_log2FC)
  ) %>%
  distinct(site_id, .keep_all = TRUE)

pal5_background <- site_data %>%
  filter(
    !is.na(motif_sequence_15mer),
    motif_center_aa %in% c("S", "T"),
    !is.na(`Pal5/Con Ratio`),
    `Pal5/Con Ratio` > 0,
    !is.na(`Pal5/Con P value`),
    !is.na(Pal5_log2FC)
  ) %>%
  distinct(site_id, .keep_all = TRUE)

pal1_down <- pal1_background %>%
  filter(
    `Pal1/Con P value` < 0.05,
    Pal1_log2FC < 0
  )

pal5_down <- pal5_background %>%
  filter(
    `Pal5/Con P value` < 0.05,
    Pal5_log2FC < 0
  )


# ============================================================================
# 4. 通用辅助函数
# ============================================================================

# 将可能包含分号、逗号或斜杠的 Gene name 拆分为单个基因。
# 注意：
# 若斜杠是某些正式基因名的一部分，可根据实际数据删除 "\\/"。
split_gene_symbols <- function(data) {
  data %>%
    mutate(
      gene_symbol_raw = as.character(`Gene name`)
    ) %>%
    separate_rows(
      gene_symbol_raw,
      sep = "\\s*[;,/]\\s*"
    ) %>%
    mutate(
      gene_symbol = str_trim(gene_symbol_raw),
      gene_symbol = na_if(gene_symbol, "")
    ) %>%
    filter(!is.na(gene_symbol))
}


# SYMBOL 转 ENTREZID。
map_symbol_to_entrez <- function(symbols) {
  symbols <- unique(
    symbols[
      !is.na(symbols) &
        symbols != ""
    ]
  )

  if (length(symbols) == 0) {
    return(
      tibble(
        SYMBOL = character(),
        ENTREZID = character()
      )
    )
  }

  suppressMessages(
    AnnotationDbi::select(
      org.Hs.eg.db,
      keys = symbols,
      keytype = "SYMBOL",
      columns = c(
        "SYMBOL",
        "ENTREZID",
        "GENENAME"
      )
    )
  ) %>%
    as_tibble() %>%
    filter(!is.na(ENTREZID)) %>%
    distinct(SYMBOL, ENTREZID, .keep_all = TRUE)
}


# 将富集分析对象安全地转换成表。
safe_enrich_df <- function(x) {
  if (is.null(x)) {
    return(tibble())
  }

  out <- tryCatch(
    as.data.frame(x),
    error = function(e) data.frame()
  )

  as_tibble(out)
}


# 保存 ggplot/enrichplot 图。
safe_ggsave <- function(
    filename,
    plot,
    width = 10,
    height = 8,
    dpi = 300
) {
  tryCatch(
    {
      ggsave(
        filename = filename,
        plot = plot,
        width = width,
        height = height,
        dpi = dpi
      )
    },
    error = function(e) {
      message(
        "图形保存失败：",
        filename,
        "\n原因：",
        conditionMessage(e)
      )
    }
  )
}


# 从富集结果中提取有丝分裂相关条目。
extract_mitosis_terms <- function(enrich_df) {
  if (nrow(enrich_df) == 0) {
    return(enrich_df)
  }

  enrich_df %>%
    filter(
      str_detect(
        Description,
        regex(
          mitosis_keyword_regex,
          ignore_case = TRUE
        )
      )
    )
}


# 计算 Fisher 富集。
fisher_enrichment <- function(
    foreground_ids,
    background_ids,
    target_ids,
    category_name,
    analysis_level,
    dose
) {
  foreground_ids <- unique(
    foreground_ids[
      !is.na(foreground_ids)
    ]
  )

  background_ids <- unique(
    background_ids[
      !is.na(background_ids)
    ]
  )

  target_ids <- unique(
    target_ids[
      !is.na(target_ids)
    ]
  )

  foreground_ids <- intersect(
    foreground_ids,
    background_ids
  )

  target_ids <- intersect(
    target_ids,
    background_ids
  )

  a <- length(
    intersect(
      foreground_ids,
      target_ids
    )
  )

  b <- length(
    setdiff(
      foreground_ids,
      target_ids
    )
  )

  background_nonforeground <- setdiff(
    background_ids,
    foreground_ids
  )

  c <- length(
    intersect(
      background_nonforeground,
      target_ids
    )
  )

  d <- length(
    setdiff(
      background_nonforeground,
      target_ids
    )
  )

  mat <- matrix(
    c(a, b, c, d),
    nrow = 2,
    byrow = TRUE
  )

  ft <- fisher.test(mat)

  tibble(
    dose = dose,
    analysis_level = analysis_level,
    category = category_name,
    foreground_target = a,
    foreground_other = b,
    background_target = c,
    background_other = d,
    foreground_total = a + b,
    background_total = a + b + c + d,
    odds_ratio = unname(ft$estimate),
    conf_low = ft$conf.int[1],
    conf_high = ft$conf.int[2],
    p_value = ft$p.value
  )
}


# 每个基因保留一个代表性位点：
# 主分析选择下降最强的位点，即 log2FC 最小的位点。
build_gene_rank <- function(
    data,
    log2fc_col,
    rank_col
) {
  log2fc_col <- rlang::ensym(log2fc_col)
  rank_col <- rlang::ensym(rank_col)

  ranked_table <- split_gene_symbols(data) %>%
    filter(
      !is.na(!!log2fc_col),
      !is.na(!!rank_col)
    ) %>%
    group_by(gene_symbol) %>%
    slice_min(
      order_by = !!log2fc_col,
      n = 1,
      with_ties = FALSE
    ) %>%
    ungroup() %>%
    select(
      gene_symbol,
      representative_log2FC = !!log2fc_col,
      representative_rank_score = !!rank_col,
      site_id,
      `Protein accession`,
      Position,
      `Amino acid`
    )

  gene_map <- map_symbol_to_entrez(
    ranked_table$gene_symbol
  )

  ranked_entrez <- ranked_table %>%
    inner_join(
      gene_map,
      by = c(
        "gene_symbol" = "SYMBOL"
      )
    ) %>%
    group_by(ENTREZID) %>%
    slice_max(
      order_by = abs(representative_rank_score),
      n = 1,
      with_ties = FALSE
    ) %>%
    ungroup()

  gene_list <- ranked_entrez$representative_rank_score
  names(gene_list) <- ranked_entrez$ENTREZID

  gene_list <- sort(
    gene_list,
    decreasing = TRUE
  )

  list(
    table = ranked_entrez,
    gene_list = gene_list
  )
}


# 生成简单 ORA 点图。
plot_ora_dot <- function(
    result_df,
    title,
    top_n = 20
) {
  if (nrow(result_df) == 0) {
    return(NULL)
  }

  plot_df <- result_df %>%
    filter(
      !is.na(p.adjust),
      p.adjust > 0
    ) %>%
    arrange(p.adjust) %>%
    slice_head(n = top_n) %>%
    mutate(
      Description = fct_reorder(
        Description,
        -log10(p.adjust)
      )
    )

  ggplot(
    plot_df,
    aes(
      x = -log10(p.adjust),
      y = Description,
      size = Count,
      fill = GeneRatio
    )
  ) +
    geom_point(
      shape = 21
    ) +
    labs(
      title = title,
      x = expression(-log[10]("adjusted P")),
      y = NULL,
      size = "Gene count",
      fill = "Gene ratio"
    ) +
    theme_bw() +
    theme(
      plot.title = element_text(
        hjust = 0.5
      )
    )
}


# 生成 GSEA 点图。
plot_gsea_dot <- function(
    result_df,
    title,
    top_n_each_direction = 10
) {
  if (nrow(result_df) == 0) {
    return(NULL)
  }

  positive <- result_df %>%
    filter(
      NES > 0,
      !is.na(p.adjust)
    ) %>%
    arrange(p.adjust) %>%
    slice_head(n = top_n_each_direction)

  negative <- result_df %>%
    filter(
      NES < 0,
      !is.na(p.adjust)
    ) %>%
    arrange(p.adjust) %>%
    slice_head(n = top_n_each_direction)

  plot_df <- bind_rows(
    positive,
    negative
  ) %>%
    distinct(ID, .keep_all = TRUE) %>%
    mutate(
      Description = fct_reorder(
        Description,
        NES
      )
    )

  ggplot(
    plot_df,
    aes(
      x = NES,
      y = Description,
      size = setSize,
      fill = -log10(p.adjust)
    )
  ) +
    geom_point(
      shape = 21
    ) +
    geom_vline(
      xintercept = 0,
      linetype = 2
    ) +
    labs(
      title = title,
      x = "Normalized enrichment score",
      y = NULL,
      size = "Set size",
      fill = expression(-log[10]("adjusted P"))
    ) +
    theme_bw() +
    theme(
      plot.title = element_text(
        hjust = 0.5
      )
    )
}


# ============================================================================
# 5. 构建非冗余前景和背景基因
# ============================================================================

pal1_background_gene_long <- split_gene_symbols(
  pal1_background
)

pal5_background_gene_long <- split_gene_symbols(
  pal5_background
)

pal1_down_gene_long <- split_gene_symbols(
  pal1_down
)

pal5_down_gene_long <- split_gene_symbols(
  pal5_down
)

pal1_background_symbols <- unique(
  pal1_background_gene_long$gene_symbol
)

pal5_background_symbols <- unique(
  pal5_background_gene_long$gene_symbol
)

pal1_down_symbols <- unique(
  pal1_down_gene_long$gene_symbol
)

pal5_down_symbols <- unique(
  pal5_down_gene_long$gene_symbol
)

pal1_background_map <- map_symbol_to_entrez(
  pal1_background_symbols
)

pal5_background_map <- map_symbol_to_entrez(
  pal5_background_symbols
)

pal1_down_map <- map_symbol_to_entrez(
  pal1_down_symbols
)

pal5_down_map <- map_symbol_to_entrez(
  pal5_down_symbols
)

pal1_background_entrez <- unique(
  pal1_background_map$ENTREZID
)

pal5_background_entrez <- unique(
  pal5_background_map$ENTREZID
)

pal1_down_entrez <- intersect(
  unique(pal1_down_map$ENTREZID),
  pal1_background_entrez
)

pal5_down_entrez <- intersect(
  unique(pal5_down_map$ENTREZID),
  pal5_background_entrez
)

mapping_summary <- tibble(
  dataset = c(
    "Pal1 background",
    "Pal1 down",
    "Pal5 background",
    "Pal5 down"
  ),
  input_symbols = c(
    length(pal1_background_symbols),
    length(pal1_down_symbols),
    length(pal5_background_symbols),
    length(pal5_down_symbols)
  ),
  mapped_entrez = c(
    length(pal1_background_entrez),
    length(pal1_down_entrez),
    length(pal5_background_entrez),
    length(pal5_down_entrez)
  )
)

write_csv(
  mapping_summary,
  file.path(
    table_dir,
    "00_gene_mapping_summary.csv"
  )
)


# ============================================================================
# 6. 全局 ORA：GO-BP、GO-CC、GO-MF 和 Reactome
# ============================================================================

run_go_ora <- function(
    foreground,
    universe,
    ontology
) {
  if (
    length(foreground) < 3 ||
      length(universe) < 10
  ) {
    return(NULL)
  }

  enrichGO(
    gene = foreground,
    universe = universe,
    OrgDb = org.Hs.eg.db,
    keyType = "ENTREZID",
    ont = ontology,
    pAdjustMethod = "BH",
    pvalueCutoff = 1,
    qvalueCutoff = 1,
    minGSSize = 5,
    maxGSSize = 500,
    readable = TRUE
  )
}


run_reactome_ora <- function(
    foreground,
    universe
) {
  if (
    length(foreground) < 3 ||
      length(universe) < 10
  ) {
    return(NULL)
  }

  enrichPathway(
    gene = foreground,
    universe = universe,
    organism = "human",
    pAdjustMethod = "BH",
    pvalueCutoff = 1,
    qvalueCutoff = 1,
    minGSSize = 5,
    maxGSSize = 500,
    readable = TRUE
  )
}


pal1_go_bp_ora <- run_go_ora(
  pal1_down_entrez,
  pal1_background_entrez,
  "BP"
)

pal1_go_cc_ora <- run_go_ora(
  pal1_down_entrez,
  pal1_background_entrez,
  "CC"
)

pal1_go_mf_ora <- run_go_ora(
  pal1_down_entrez,
  pal1_background_entrez,
  "MF"
)

pal1_reactome_ora <- run_reactome_ora(
  pal1_down_entrez,
  pal1_background_entrez
)

pal5_go_bp_ora <- run_go_ora(
  pal5_down_entrez,
  pal5_background_entrez,
  "BP"
)

pal5_go_cc_ora <- run_go_ora(
  pal5_down_entrez,
  pal5_background_entrez,
  "CC"
)

pal5_go_mf_ora <- run_go_ora(
  pal5_down_entrez,
  pal5_background_entrez,
  "MF"
)

pal5_reactome_ora <- run_reactome_ora(
  pal5_down_entrez,
  pal5_background_entrez
)


ora_tables <- list(
  Pal1_GO_BP = safe_enrich_df(pal1_go_bp_ora),
  Pal1_GO_CC = safe_enrich_df(pal1_go_cc_ora),
  Pal1_GO_MF = safe_enrich_df(pal1_go_mf_ora),
  Pal1_Reactome = safe_enrich_df(pal1_reactome_ora),

  Pal5_GO_BP = safe_enrich_df(pal5_go_bp_ora),
  Pal5_GO_CC = safe_enrich_df(pal5_go_cc_ora),
  Pal5_GO_MF = safe_enrich_df(pal5_go_mf_ora),
  Pal5_Reactome = safe_enrich_df(pal5_reactome_ora)
)

write.xlsx(
  ora_tables,
  file = file.path(
    table_dir,
    "01_global_ORA_results.xlsx"
  ),
  overwrite = TRUE
)


# ORA 图形。
ora_plot_specs <- list(
  list(
    data = ora_tables$Pal1_GO_BP,
    title = "Pal1 downregulated phosphoproteins: GO BP ORA",
    file = "01A_Pal1_GO_BP_ORA.png"
  ),
  list(
    data = ora_tables$Pal1_GO_CC,
    title = "Pal1 downregulated phosphoproteins: GO CC ORA",
    file = "01B_Pal1_GO_CC_ORA.png"
  ),
  list(
    data = ora_tables$Pal1_Reactome,
    title = "Pal1 downregulated phosphoproteins: Reactome ORA",
    file = "01C_Pal1_Reactome_ORA.png"
  ),
  list(
    data = ora_tables$Pal5_GO_BP,
    title = "Pal5 downregulated phosphoproteins: GO BP ORA",
    file = "01D_Pal5_GO_BP_ORA.png"
  ),
  list(
    data = ora_tables$Pal5_GO_CC,
    title = "Pal5 downregulated phosphoproteins: GO CC ORA",
    file = "01E_Pal5_GO_CC_ORA.png"
  ),
  list(
    data = ora_tables$Pal5_Reactome,
    title = "Pal5 downregulated phosphoproteins: Reactome ORA",
    file = "01F_Pal5_Reactome_ORA.png"
  )
)

walk(
  ora_plot_specs,
  function(spec) {
    p <- plot_ora_dot(
      result_df = spec$data,
      title = spec$title,
      top_n = 20
    )

    if (!is.null(p)) {
      safe_ggsave(
        filename = file.path(
          figure_dir,
          spec$file
        ),
        plot = p,
        width = 11,
        height = 8
      )
    }
  }
)


# ============================================================================
# 7. 排序型 GSEA：GO-BP、GO-CC、GO-MF 和 Reactome
# ============================================================================

pal1_rank_result <- build_gene_rank(
  data = pal1_background,
  log2fc_col = Pal1_log2FC,
  rank_col = Pal1_rank_score
)

pal5_rank_result <- build_gene_rank(
  data = pal5_background,
  log2fc_col = Pal5_log2FC,
  rank_col = Pal5_rank_score
)

pal1_gene_list <- pal1_rank_result$gene_list
pal5_gene_list <- pal5_rank_result$gene_list

write_csv(
  pal1_rank_result$table,
  file.path(
    table_dir,
    "02A_Pal1_gene_rank_input.csv"
  )
)

write_csv(
  pal5_rank_result$table,
  file.path(
    table_dir,
    "02B_Pal5_gene_rank_input.csv"
  )
)


run_go_gsea <- function(
    gene_list,
    ontology
) {
  if (length(gene_list) < 20) {
    return(NULL)
  }

  gseGO(
    geneList = gene_list,
    OrgDb = org.Hs.eg.db,
    keyType = "ENTREZID",
    ont = ontology,
    minGSSize = gsea_min_size,
    maxGSSize = gsea_max_size,
    pvalueCutoff = 1,
    pAdjustMethod = "BH",
    eps = gsea_eps,
    by = "fgsea",
    verbose = FALSE
  )
}


run_reactome_gsea <- function(gene_list) {
  if (length(gene_list) < 20) {
    return(NULL)
  }

  gsePathway(
    geneList = gene_list,
    organism = "human",
    minGSSize = gsea_min_size,
    maxGSSize = gsea_max_size,
    pvalueCutoff = 1,
    pAdjustMethod = "BH",
    eps = gsea_eps,
    verbose = FALSE
  )
}


pal1_go_bp_gsea <- run_go_gsea(
  pal1_gene_list,
  "BP"
)

pal1_go_cc_gsea <- run_go_gsea(
  pal1_gene_list,
  "CC"
)

pal1_go_mf_gsea <- run_go_gsea(
  pal1_gene_list,
  "MF"
)

pal1_reactome_gsea <- run_reactome_gsea(
  pal1_gene_list
)

pal5_go_bp_gsea <- run_go_gsea(
  pal5_gene_list,
  "BP"
)

pal5_go_cc_gsea <- run_go_gsea(
  pal5_gene_list,
  "CC"
)

pal5_go_mf_gsea <- run_go_gsea(
  pal5_gene_list,
  "MF"
)

pal5_reactome_gsea <- run_reactome_gsea(
  pal5_gene_list
)


gsea_tables <- list(
  Pal1_GO_BP = safe_enrich_df(pal1_go_bp_gsea),
  Pal1_GO_CC = safe_enrich_df(pal1_go_cc_gsea),
  Pal1_GO_MF = safe_enrich_df(pal1_go_mf_gsea),
  Pal1_Reactome = safe_enrich_df(pal1_reactome_gsea),

  Pal5_GO_BP = safe_enrich_df(pal5_go_bp_gsea),
  Pal5_GO_CC = safe_enrich_df(pal5_go_cc_gsea),
  Pal5_GO_MF = safe_enrich_df(pal5_go_mf_gsea),
  Pal5_Reactome = safe_enrich_df(pal5_reactome_gsea)
)

write.xlsx(
  gsea_tables,
  file = file.path(
    table_dir,
    "02_ranked_GSEA_results.xlsx"
  ),
  overwrite = TRUE
)


gsea_plot_specs <- list(
  list(
    data = gsea_tables$Pal1_GO_BP,
    title = "Pal1 phosphoproteome: GO BP GSEA",
    file = "02A_Pal1_GO_BP_GSEA.png"
  ),
  list(
    data = gsea_tables$Pal1_GO_CC,
    title = "Pal1 phosphoproteome: GO CC GSEA",
    file = "02B_Pal1_GO_CC_GSEA.png"
  ),
  list(
    data = gsea_tables$Pal1_Reactome,
    title = "Pal1 phosphoproteome: Reactome GSEA",
    file = "02C_Pal1_Reactome_GSEA.png"
  ),
  list(
    data = gsea_tables$Pal5_GO_BP,
    title = "Pal5 phosphoproteome: GO BP GSEA",
    file = "02D_Pal5_GO_BP_GSEA.png"
  ),
  list(
    data = gsea_tables$Pal5_GO_CC,
    title = "Pal5 phosphoproteome: GO CC GSEA",
    file = "02E_Pal5_GO_CC_GSEA.png"
  ),
  list(
    data = gsea_tables$Pal5_Reactome,
    title = "Pal5 phosphoproteome: Reactome GSEA",
    file = "02F_Pal5_Reactome_GSEA.png"
  )
)

walk(
  gsea_plot_specs,
  function(spec) {
    p <- plot_gsea_dot(
      result_df = spec$data,
      title = spec$title,
      top_n_each_direction = 10
    )

    if (!is.null(p)) {
      safe_ggsave(
        filename = file.path(
          figure_dir,
          spec$file
        ),
        plot = p,
        width = 11,
        height = 8
      )
    }
  }
)


# ============================================================================
# 8. 提取全局分析中的有丝分裂相关条目
# ============================================================================

mitosis_ora_tables <- imap(
  ora_tables,
  function(df, nm) {
    extract_mitosis_terms(df) %>%
      mutate(
        result_source = nm,
        .before = 1
      )
  }
)

mitosis_gsea_tables <- imap(
  gsea_tables,
  function(df, nm) {
    extract_mitosis_terms(df) %>%
      mutate(
        result_source = nm,
        .before = 1
      )
  }
)

mitosis_ora_combined <- bind_rows(
  mitosis_ora_tables
)

mitosis_gsea_combined <- bind_rows(
  mitosis_gsea_tables
)

write.xlsx(
  list(
    ORA_mitosis_terms = mitosis_ora_combined,
    GSEA_mitosis_terms = mitosis_gsea_combined
  ),
  file = file.path(
    table_dir,
    "03_mitosis_terms_from_global_analysis.xlsx"
  ),
  overwrite = TRUE
)


# ============================================================================
# 9. Pal1 与 Pal5 一致性比较
# ============================================================================

compare_ora_results <- function(
    pal1_df,
    pal5_df,
    database_name
) {
  pal1_small <- pal1_df %>%
    transmute(
      ID,
      Description,
      Pal1_pvalue = pvalue,
      Pal1_p_adjust = p.adjust,
      Pal1_gene_ratio = GeneRatio,
      Pal1_count = Count
    )

  pal5_small <- pal5_df %>%
    transmute(
      ID,
      Description,
      Pal5_pvalue = pvalue,
      Pal5_p_adjust = p.adjust,
      Pal5_gene_ratio = GeneRatio,
      Pal5_count = Count
    )

  full_join(
    pal1_small,
    pal5_small,
    by = c(
      "ID",
      "Description"
    )
  ) %>%
    mutate(
      database = database_name,
      Pal1_significant =
        !is.na(Pal1_p_adjust) &
        Pal1_p_adjust < q_cutoff,

      Pal5_significant =
        !is.na(Pal5_p_adjust) &
        Pal5_p_adjust < q_cutoff,

      consistency_class = case_when(
        Pal1_significant &
          Pal5_significant ~ "Significant in both",

        Pal1_significant &
          !Pal5_significant ~ "Pal1 only",

        !Pal1_significant &
          Pal5_significant ~ "Pal5 only",

        TRUE ~ "Not significant"
      )
    ) %>%
    relocate(database)
}


compare_gsea_results <- function(
    pal1_df,
    pal5_df,
    database_name
) {
  pal1_small <- pal1_df %>%
    transmute(
      ID,
      Description,
      Pal1_NES = NES,
      Pal1_pvalue = pvalue,
      Pal1_p_adjust = p.adjust,
      Pal1_set_size = setSize,
      Pal1_core_enrichment = core_enrichment
    )

  pal5_small <- pal5_df %>%
    transmute(
      ID,
      Description,
      Pal5_NES = NES,
      Pal5_pvalue = pvalue,
      Pal5_p_adjust = p.adjust,
      Pal5_set_size = setSize,
      Pal5_core_enrichment = core_enrichment
    )

  full_join(
    pal1_small,
    pal5_small,
    by = c(
      "ID",
      "Description"
    )
  ) %>%
    mutate(
      database = database_name,

      Pal1_significant =
        !is.na(Pal1_p_adjust) &
        Pal1_p_adjust < q_cutoff,

      Pal5_significant =
        !is.na(Pal5_p_adjust) &
        Pal5_p_adjust < q_cutoff,

      direction_consistent = case_when(
        is.na(Pal1_NES) |
          is.na(Pal5_NES) ~ NA,

        sign(Pal1_NES) ==
          sign(Pal5_NES) ~ TRUE,

        TRUE ~ FALSE
      ),

      consistency_class = case_when(
        Pal1_significant &
          Pal5_significant &
          direction_consistent ~
          "Significant in both, same direction",

        Pal1_significant &
          Pal5_significant &
          !direction_consistent ~
          "Significant in both, opposite direction",

        Pal1_significant &
          !Pal5_significant ~
          "Pal1 only",

        !Pal1_significant &
          Pal5_significant ~
          "Pal5 only",

        TRUE ~
          "Not significant in both"
      ),

      stronger_at_Pal5 = case_when(
        is.na(Pal1_NES) |
          is.na(Pal5_NES) ~ NA,

        sign(Pal1_NES) !=
          sign(Pal5_NES) ~ NA,

        TRUE ~ abs(Pal5_NES) >
          abs(Pal1_NES)
      )
    ) %>%
    relocate(database)
}


ora_consistency <- bind_rows(
  compare_ora_results(
    ora_tables$Pal1_GO_BP,
    ora_tables$Pal5_GO_BP,
    "GO_BP"
  ),
  compare_ora_results(
    ora_tables$Pal1_GO_CC,
    ora_tables$Pal5_GO_CC,
    "GO_CC"
  ),
  compare_ora_results(
    ora_tables$Pal1_GO_MF,
    ora_tables$Pal5_GO_MF,
    "GO_MF"
  ),
  compare_ora_results(
    ora_tables$Pal1_Reactome,
    ora_tables$Pal5_Reactome,
    "Reactome"
  )
)

gsea_consistency <- bind_rows(
  compare_gsea_results(
    gsea_tables$Pal1_GO_BP,
    gsea_tables$Pal5_GO_BP,
    "GO_BP"
  ),
  compare_gsea_results(
    gsea_tables$Pal1_GO_CC,
    gsea_tables$Pal5_GO_CC,
    "GO_CC"
  ),
  compare_gsea_results(
    gsea_tables$Pal1_GO_MF,
    gsea_tables$Pal5_GO_MF,
    "GO_MF"
  ),
  compare_gsea_results(
    gsea_tables$Pal1_Reactome,
    gsea_tables$Pal5_Reactome,
    "Reactome"
  )
)

ora_mitosis_consistency <- ora_consistency %>%
  filter(
    str_detect(
      Description,
      regex(
        mitosis_keyword_regex,
        ignore_case = TRUE
      )
    )
  )

gsea_mitosis_consistency <- gsea_consistency %>%
  filter(
    str_detect(
      Description,
      regex(
        mitosis_keyword_regex,
        ignore_case = TRUE
      )
    )
  )

write.xlsx(
  list(
    ORA_all = ora_consistency,
    ORA_mitosis = ora_mitosis_consistency,
    GSEA_all = gsea_consistency,
    GSEA_mitosis = gsea_mitosis_consistency
  ),
  file = file.path(
    table_dir,
    "04_Pal1_Pal5_consistency.xlsx"
  ),
  overwrite = TRUE
)


# GSEA Pal1/Pal5 一致性散点图。
gsea_consistency_plot_data <- gsea_consistency %>%
  filter(
    !is.na(Pal1_NES),
    !is.na(Pal5_NES)
  ) %>%
  mutate(
    highlighted_mitosis = str_detect(
      Description,
      regex(
        mitosis_keyword_regex,
        ignore_case = TRUE
      )
    )
  )

if (nrow(gsea_consistency_plot_data) > 0) {
  p_gsea_consistency <- ggplot(
    gsea_consistency_plot_data,
    aes(
      x = Pal1_NES,
      y = Pal5_NES,
      shape = database
    )
  ) +
    geom_hline(
      yintercept = 0,
      linetype = 2
    ) +
    geom_vline(
      xintercept = 0,
      linetype = 2
    ) +
    geom_abline(
      slope = 1,
      intercept = 0,
      linetype = 3
    ) +
    geom_point(
      aes(
        size = highlighted_mitosis
      ),
      alpha = 0.65
    ) +
    scale_size_manual(
      values = c(
        `FALSE` = 1.5,
        `TRUE` = 3.5
      )
    ) +
    labs(
      title = "Pal1 versus Pal5 pathway-level GSEA consistency",
      x = "Pal1 NES",
      y = "Pal5 NES",
      size = "Mitosis-related"
    ) +
    theme_bw() +
    theme(
      plot.title = element_text(
        hjust = 0.5
      )
    )

  safe_ggsave(
    filename = file.path(
      figure_dir,
      "04_Pal1_Pal5_GSEA_consistency.png"
    ),
    plot = p_gsea_consistency,
    width = 9,
    height = 8
  )
}


# ============================================================================
# 10. SAC、动粒、RZZ/fibrous corona 目标蛋白集
# ============================================================================

# 说明：
# 1. 下列核心基因集是用于“老师指定目标验证”的手工核心集合。
# 2. chromosome segregation 范围很广，主分析建议使用 GO 注释自动构建。
# 3. 所有基因符号均建议在分析前人工核对一次。

target_gene_sets_manual <- list(
  Kinetochore_core = c(
    "CENPA", "CENPB", "CENPC", "CENPE", "CENPF",
    "CENPH", "CENPI", "CENPK", "CENPL", "CENPM",
    "CENPN", "CENPO", "CENPP", "CENPQ", "CENPT",
    "CENPU", "CENPW", "CENPX",
    "NDC80", "NUF2", "SPC24", "SPC25",
    "KNL1", "CASC5", "MIS12", "DSN1", "NSL1",
    "KNTC1", "ZWINT", "SKA1", "SKA2", "SKA3"
  ),

  SAC_core = c(
    "MAD1L1", "MAD2L1", "MAD2L2",
    "BUB1", "BUB1B", "BUB3",
    "TTK", "CDC20", "CASC5", "KNL1",
    "MPS1", "TRIP13", "PCH2",
    "ZWINT", "CENPE"
  ),

  RZZ_fibrous_corona_core = c(
    "KNTC1",
    "ZW10",
    "ZWILCH",
    "SPDL1",
    "CENPE",
    "CENPF",
    "MAD1L1",
    "MAD2L1",
    "DYNC1H1",
    "DCTN1"
  ),

  Chromosomal_passenger_complex = c(
    "AURKB",
    "INCENP",
    "BIRC5",
    "CDCA8"
  )
)


# 自动从 GO 注释中建立 chromosome segregation 相关基因集。
go_annotation_table <- suppressMessages(
  AnnotationDbi::select(
    org.Hs.eg.db,
    keys = keys(
      org.Hs.eg.db,
      keytype = "SYMBOL"
    ),
    keytype = "SYMBOL",
    columns = c(
      "GO",
      "ONTOLOGY",
      "SYMBOL"
    )
  )
) %>%
  as_tibble() %>%
  filter(
    !is.na(GO),
    ONTOLOGY == "BP"
  )

go_term_table <- suppressMessages(
  AnnotationDbi::select(
    GO.db::GO.db,
    keys = unique(go_annotation_table$GO),
    keytype = "GOID",
    columns = c(
      "GOID",
      "TERM"
    )
  )
) %>%
  as_tibble() %>%
  distinct(GOID, .keep_all = TRUE)

go_annotation_with_term <- go_annotation_table %>%
  left_join(
    go_term_table,
    by = c(
      "GO" = "GOID"
    )
  )

chromosome_segregation_go_genes <- go_annotation_with_term %>%
  filter(
    str_detect(
      TERM,
      regex(
        "chromosome segregation|sister chromatid segregation",
        ignore_case = TRUE
      )
    )
  ) %>%
  distinct(SYMBOL) %>%
  pull(SYMBOL)

target_gene_sets <- c(
  target_gene_sets_manual,
  list(
    Chromosome_segregation_GO =
      chromosome_segregation_go_genes
  )
)

target_gene_sets <- map(
  target_gene_sets,
  ~ unique(
    .x[
      !is.na(.x) &
        .x != ""
    ]
  )
)

target_gene_set_summary <- imap_dfr(
  target_gene_sets,
  ~ tibble(
    category = .y,
    number_of_genes = length(.x),
    genes = paste(.x, collapse = ";")
  )
)

write_csv(
  target_gene_set_summary,
  file.path(
    table_dir,
    "05A_target_gene_set_definitions.csv"
  )
)


# ============================================================================
# 11. 目标蛋白集：位点层面和蛋白层面 Fisher 富集
# ============================================================================

# 位点层面：
# 一个目标蛋白上的每个磷酸化位点均作为独立位点。
run_target_site_fisher <- function(
    background_data,
    foreground_data,
    target_gene_sets,
    dose
) {
  background_long <- split_gene_symbols(
    background_data
  )

  foreground_long <- split_gene_symbols(
    foreground_data
  )

  # 对多基因共享肽：
  # 同一 site_id 只要映射到目标类别中的任一基因，就定义为目标位点。
  background_site_gene <- background_long %>%
    distinct(
      site_id,
      gene_symbol
    )

  foreground_site_ids <- unique(
    foreground_long$site_id
  )

  background_site_ids <- unique(
    background_site_gene$site_id
  )

  imap_dfr(
    target_gene_sets,
    function(target_genes, category_name) {
      target_site_ids <- background_site_gene %>%
        filter(
          gene_symbol %in% target_genes
        ) %>%
        distinct(site_id) %>%
        pull(site_id)

      fisher_enrichment(
        foreground_ids = foreground_site_ids,
        background_ids = background_site_ids,
        target_ids = target_site_ids,
        category_name = category_name,
        analysis_level = "Phosphosite",
        dose = dose
      )
    }
  )
}


# 蛋白层面：
# 每个非冗余基因只计算一次。
run_target_gene_fisher <- function(
    background_data,
    foreground_data,
    target_gene_sets,
    dose
) {
  background_genes <- split_gene_symbols(
    background_data
  ) %>%
    distinct(gene_symbol) %>%
    pull(gene_symbol)

  foreground_genes <- split_gene_symbols(
    foreground_data
  ) %>%
    distinct(gene_symbol) %>%
    pull(gene_symbol)

  imap_dfr(
    target_gene_sets,
    function(target_genes, category_name) {
      fisher_enrichment(
        foreground_ids = foreground_genes,
        background_ids = background_genes,
        target_ids = target_genes,
        category_name = category_name,
        analysis_level = "Protein/gene",
        dose = dose
      )
    }
  )
}


target_fisher_results <- bind_rows(
  run_target_site_fisher(
    pal1_background,
    pal1_down,
    target_gene_sets,
    "Pal1"
  ),

  run_target_site_fisher(
    pal5_background,
    pal5_down,
    target_gene_sets,
    "Pal5"
  ),

  run_target_gene_fisher(
    pal1_background,
    pal1_down,
    target_gene_sets,
    "Pal1"
  ),

  run_target_gene_fisher(
    pal5_background,
    pal5_down,
    target_gene_sets,
    "Pal5"
  )
) %>%
  group_by(analysis_level) %>%
  mutate(
    p_adjust = p.adjust(
      p_value,
      method = "BH"
    )
  ) %>%
  ungroup()

write_csv(
  target_fisher_results,
  file.path(
    table_dir,
    "05B_target_gene_set_Fisher_enrichment.csv"
  )
)


# Fisher 结果森林图。
target_forest_df <- target_fisher_results %>%
  mutate(
    odds_ratio_plot = if_else(
      is.infinite(odds_ratio),
      NA_real_,
      odds_ratio
    ),
    category_label = paste(
      category,
      dose,
      sep = " | "
    ),
    category_label = fct_reorder(
      category_label,
      odds_ratio_plot
    )
  ) %>%
  filter(
    !is.na(odds_ratio_plot),
    odds_ratio_plot > 0,
    !is.na(conf_low),
    !is.na(conf_high)
  )

if (nrow(target_forest_df) > 0) {
  p_target_forest <- ggplot(
    target_forest_df,
    aes(
      x = odds_ratio_plot,
      y = category_label
    )
  ) +
    geom_vline(
      xintercept = 1,
      linetype = 2
    ) +
    geom_errorbar(
      aes(
        xmin = .data$conf_low,
        xmax = .data$conf_high
      ),
      orientation = "y",
      width = 0.2
    ) +
    geom_point(
      aes(
        shape = analysis_level
      ),
      size = 2.5
    ) +
    scale_x_log10() +
    facet_wrap(
      ~ analysis_level,
      scales = "free_y"
    ) +
    labs(
      title = "Targeted mitotic protein-set enrichment",
      x = "Odds ratio, log10 scale",
      y = NULL
    ) +
    theme_bw() +
    theme(
      plot.title = element_text(
        hjust = 0.5
      )
    )

  safe_ggsave(
    filename = file.path(
      figure_dir,
      "05_target_gene_set_Fisher_forest.png"
    ),
    plot = p_target_forest,
    width = 11,
    height = 9
  )
}


# ============================================================================
# 12. 目标蛋白集：连续 log2FC 分布比较
# ============================================================================

build_target_annotation <- function(
    data,
    target_gene_sets
) {
  data_long <- split_gene_symbols(
    data
  )

  category_map <- imap_dfr(
    target_gene_sets,
    ~ tibble(
      gene_symbol = .x,
      target_category = .y
    )
  )

  data_long %>%
    left_join(
      category_map,
      by = "gene_symbol"
    ) %>%
    mutate(
      target_category =
        replace_na(
          target_category,
          "Other quantified proteins"
        )
    )
}


pal1_target_annotated <- build_target_annotation(
  pal1_background,
  target_gene_sets
)

pal5_target_annotated <- build_target_annotation(
  pal5_background,
  target_gene_sets
)


compare_target_log2fc <- function(
    data,
    log2fc_col,
    dose
) {
  log2fc_col <- rlang::ensym(log2fc_col)

  target_categories <- setdiff(
    unique(data$target_category),
    "Other quantified proteins"
  )

  map_dfr(
    target_categories,
    function(cat) {
      target_values <- data %>%
        filter(
          target_category == cat
        ) %>%
        pull(!!log2fc_col)

      other_values <- data %>%
        filter(
          target_category ==
            "Other quantified proteins"
        ) %>%
        pull(!!log2fc_col)

      target_values <- target_values[
        !is.na(target_values)
      ]

      other_values <- other_values[
        !is.na(other_values)
      ]

      if (
        length(target_values) < 2 ||
          length(other_values) < 2
      ) {
        return(
          tibble(
            dose = dose,
            category = cat,
            target_n = length(target_values),
            other_n = length(other_values),
            target_median = ifelse(
              length(target_values) > 0,
              median(target_values),
              NA_real_
            ),
            other_median = ifelse(
              length(other_values) > 0,
              median(other_values),
              NA_real_
            ),
            wilcox_p = NA_real_
          )
        )
      }

      wt <- wilcox.test(
        target_values,
        other_values,
        exact = FALSE
      )

      tibble(
        dose = dose,
        category = cat,
        target_n = length(target_values),
        other_n = length(other_values),
        target_median = median(target_values),
        other_median = median(other_values),
        median_difference =
          median(target_values) -
          median(other_values),
        wilcox_p = wt$p.value
      )
    }
  )
}


target_log2fc_tests <- bind_rows(
  compare_target_log2fc(
    pal1_target_annotated,
    Pal1_log2FC,
    "Pal1"
  ),

  compare_target_log2fc(
    pal5_target_annotated,
    Pal5_log2FC,
    "Pal5"
  )
) %>%
  group_by(dose) %>%
  mutate(
    wilcox_p_adjust = p.adjust(
      wilcox_p,
      method = "BH"
    )
  ) %>%
  ungroup()

write_csv(
  target_log2fc_tests,
  file.path(
    table_dir,
    "05C_target_gene_set_log2FC_tests.csv"
  )
)


# ============================================================================
# 13. 输出老师点名蛋白及目标类别候选表
# ============================================================================

teacher_priority_genes <- c(
  "CENPE",
  "CENPF",
  "BUB1",
  "BUB1B",
  "ZW10",
  "ZWILCH",
  "CASC5",
  "KNL1",
  "MAD1L1",
  "MAD2L1",
  "INCENP"
)

all_target_genes <- unique(
  c(
    unlist(
      target_gene_sets,
      use.names = FALSE
    ),
    teacher_priority_genes
  )
)

candidate_category_map <- imap_dfr(
  target_gene_sets,
  ~ tibble(
    gene_symbol = .x,
    target_category = .y
  )
)

candidate_table <- split_gene_symbols(
  site_data
) %>%
  filter(
    gene_symbol %in% all_target_genes
  ) %>%
  left_join(
    candidate_category_map,
    by = "gene_symbol"
  ) %>%
  group_by(site_id) %>%
  mutate(
    target_category = paste(
      sort(
        unique(
          target_category[
            !is.na(target_category)
          ]
        )
      ),
      collapse = ";"
    ),

    teacher_priority =
      any(
        gene_symbol %in%
          teacher_priority_genes
      )
  ) %>%
  ungroup() %>%
  distinct(site_id, .keep_all = TRUE) %>%
  transmute(
    gene_symbol,
    protein_accession =
      protein_accession_clean,

    protein_name =
      if (
        "Protein name" %in%
          colnames(site_data)
      ) {
        `Protein name`
      } else {
        NA_character_
      },

    target_category,
    teacher_priority,
    position = as.numeric(.data$Position),
    phosphosite = paste0(
      .data$`Amino acid`,
      .data$Position
    ),
    site_id,
    modified_sequence =
      `Modified sequence`,
    motif_sequence_15mer,
    motif_type,
    localization_probability =
      `Localization probability`,
    Pal1_ratio =
      `Pal1/Con Ratio`,
    Pal1_log2FC,
    Pal1_p_value =
      `Pal1/Con P value`,
    Pal5_ratio =
      `Pal5/Con Ratio`,
    Pal5_log2FC,
    Pal5_p_value =
      `Pal5/Con P value`,
    dose_delta_log2FC =
      Pal5_log2FC -
      Pal1_log2FC
  ) %>%
  arrange(
    desc(.data$teacher_priority),
    .data$gene_symbol,
    .data$position
  )

write_csv(
  candidate_table,
  file.path(
    table_dir,
    "05D_mitotic_candidate_phosphosites.csv"
  )
)


# ============================================================================
# 14. 激酶特征分析：创建标准输入模板
# ============================================================================

# 建议外部文件：
# kinase_substrate_reference.csv
#
# 必需字段：
# kinase
# substrate_gene
# substrate_accession
# residue
# position
# evidence
# source
#
# 一行对应一个激酶—底物位点关系。
# 只建议把“具体到位点”的关系放入主分析。

kinase_reference_path <- file.path(
  template_dir,
  "kinase_substrate_reference.csv"
)

if (!file.exists(kinase_reference_path)) {
  kinase_reference_template <- tibble(
    kinase = c(
      "CDK4",
      "CDK6",
      "CDK1",
      "AURKA",
      "AURKB",
      "PLK1",
      "TTK"
    ),
    substrate_gene = NA_character_,
    substrate_accession = NA_character_,
    residue = NA_character_,
    position = NA_integer_,
    evidence = NA_character_,
    source = NA_character_
  )

  write_csv(
    kinase_reference_template,
    kinase_reference_path
  )

  message(
    "已创建激酶—底物模板：",
    kinase_reference_path
  )
}


# ============================================================================
# 15. 激酶特征分析：数据库匹配、底物分布和 KSEA 式得分
# ============================================================================

# 标准化激酶名称。
standardize_kinase_name <- function(x) {
  x <- str_to_upper(
    str_trim(x)
  )

  case_when(
    x %in% c("MPS1", "TTK", "MPS1/TTK") ~ "TTK",
    x %in% c("AURORA A", "AURORA-A", "AURKA") ~ "AURKA",
    x %in% c("AURORA B", "AURORA-B", "AURKB") ~ "AURKB",
    TRUE ~ x
  )
}


# 以背景中所有位点的均值和标准差为参照，
# 计算每个激酶底物集的标准化均值得分：
#
# z = (substrate_mean - background_mean) /
#     (background_sd / sqrt(number_of_substrates))
#
# 负值表示该激酶已知底物整体偏向下降。
calculate_ksea_like <- function(
    matched_data,
    background_data,
    log2fc_col,
    dose,
    min_substrates = 3
) {
  log2fc_col <- rlang::ensym(log2fc_col)

  background_values <- background_data %>%
    pull(!!log2fc_col)

  background_values <- background_values[
    !is.na(background_values)
  ]

  background_mean <- mean(
    background_values
  )

  background_sd <- sd(
    background_values
  )

  matched_data %>%
    filter(
      !is.na(!!log2fc_col)
    ) %>%
    group_by(kinase) %>%
    summarise(
      n_substrates =
        n_distinct(site_id),

      substrate_mean =
        mean(
          !!log2fc_col,
          na.rm = TRUE
        ),

      substrate_median =
        median(
          !!log2fc_col,
          na.rm = TRUE
        ),

      number_down =
        sum(
          !!log2fc_col < 0,
          na.rm = TRUE
        ),

      number_up =
        sum(
          !!log2fc_col > 0,
          na.rm = TRUE
        ),

      .groups = "drop"
    ) %>%
    mutate(
      dose = dose,

      ksea_like_z = if_else(
        n_substrates >= min_substrates &
          !is.na(background_sd) &
          background_sd > 0,

        (
          substrate_mean -
            background_mean
        ) /
          (
            background_sd /
              sqrt(n_substrates)
          ),

        NA_real_
      ),

      p_value = if_else(
        !is.na(ksea_like_z),

        2 *
          pnorm(
            -abs(ksea_like_z)
          ),

        NA_real_
      ),

      p_adjust = p.adjust(
        p_value,
        method = "BH"
      ),

      background_mean =
        background_mean,

      background_sd =
        background_sd
    ) %>%
    relocate(dose)
}


# 用置换检验评估激酶底物平均 log2FC。
calculate_kinase_permutation <- function(
    matched_data,
    background_data,
    log2fc_col,
    dose,
    n_perm = 10000,
    min_substrates = 3
) {
  log2fc_col <- rlang::ensym(log2fc_col)

  background_values <- background_data %>%
    pull(!!log2fc_col)

  background_values <- background_values[
    !is.na(background_values)
  ]

  kinase_groups <- matched_data %>%
    filter(
      !is.na(!!log2fc_col)
    ) %>%
    group_split(kinase)

  map_dfr(
    kinase_groups,
    function(df) {
      kinase_name <- unique(
        df$kinase
      )

      observed_values <- df %>%
        distinct(
          site_id,
          .keep_all = TRUE
        ) %>%
        pull(!!log2fc_col)

      observed_values <- observed_values[
        !is.na(observed_values)
      ]

      n_sub <- length(
        observed_values
      )

      if (
        n_sub < min_substrates ||
          n_sub > length(background_values)
      ) {
        return(
          tibble(
            dose = dose,
            kinase = kinase_name,
            n_substrates = n_sub,
            observed_mean = ifelse(
              n_sub > 0,
              mean(observed_values),
              NA_real_
            ),
            permutation_p = NA_real_
          )
        )
      }

      observed_mean <- mean(
        observed_values
      )

      null_means <- replicate(
        n_perm,
        mean(
          sample(
            background_values,
            size = n_sub,
            replace = FALSE
          )
        )
      )

      permutation_p <- (
        sum(
          abs(null_means) >=
            abs(observed_mean)
        ) +
          1
      ) /
        (
          n_perm +
            1
        )

      tibble(
        dose = dose,
        kinase = kinase_name,
        n_substrates = n_sub,
        observed_mean = observed_mean,
        permutation_p = permutation_p
      )
    }
  ) %>%
    group_by(dose) %>%
    mutate(
      permutation_fdr = p.adjust(
        permutation_p,
        method = "BH"
      )
    ) %>%
    ungroup()
}


if (file.exists(kinase_reference_path)) {
  kinase_reference <- read_csv(
    kinase_reference_path,
    show_col_types = FALSE
  ) %>%
    mutate(
      kinase =
        standardize_kinase_name(
          kinase
        ),

      substrate_gene =
        str_trim(
          substrate_gene
        ),

      substrate_accession =
        str_trim(
          substrate_accession
        ),

      residue =
        str_to_upper(
          str_trim(
            residue
          )
        ),

      position =
        as.integer(
          position
        ),

      reference_site_id =
        paste(
          substrate_accession,
          position,
          residue,
          sep = "_"
        )
    ) %>%
    filter(
      !is.na(kinase),
      kinase != "",
      !is.na(position),
      !is.na(residue),
      residue %in% c(
        "S",
        "T",
        "Y"
      )
    )

  if (nrow(kinase_reference) > 0) {
    kinase_site_matches <- site_data %>%
      inner_join(
        kinase_reference,
        by = c(
          "protein_accession_clean" =
            "substrate_accession",

          "Position" =
            "position",

          "Amino acid" =
            "residue"
        )
      ) %>%
      distinct(
        kinase,
        site_id,
        .keep_all = TRUE
      )

    kinase_site_match_summary <-
      kinase_reference %>%
      distinct(
        kinase,
        reference_site_id,
        .keep_all = TRUE
      ) %>%
      left_join(
        kinase_site_matches %>%
          transmute(
            kinase,
            reference_site_id =
              paste(
                protein_accession_clean,
                Position,
                `Amino acid`,
                sep = "_"
              ),
            detected = TRUE,
            site_id,
            Pal1_log2FC,
            Pal1_p_value =
              `Pal1/Con P value`,
            Pal5_log2FC,
            Pal5_p_value =
              `Pal5/Con P value`,
            motif_type,
            motif_sequence_15mer
          ),
        by = c(
          "kinase",
          "reference_site_id"
        )
      ) %>%
      mutate(
        detected =
          replace_na(
            detected,
            FALSE
          )
      )

    ksea_like_results <- bind_rows(
      calculate_ksea_like(
        kinase_site_matches,
        pal1_background,
        Pal1_log2FC,
        "Pal1"
      ),

      calculate_ksea_like(
        kinase_site_matches,
        pal5_background,
        Pal5_log2FC,
        "Pal5"
      )
    )

    kinase_permutation_results <- bind_rows(
      calculate_kinase_permutation(
        kinase_site_matches,
        pal1_background,
        Pal1_log2FC,
        "Pal1"
      ),

      calculate_kinase_permutation(
        kinase_site_matches,
        pal5_background,
        Pal5_log2FC,
        "Pal5"
      )
    )

    write.xlsx(
      list(
        Kinase_reference =
          kinase_reference,

        Matched_sites =
          kinase_site_matches,

        Detection_summary =
          kinase_site_match_summary,

        KSEA_like_score =
          ksea_like_results,

        Permutation_test =
          kinase_permutation_results
      ),
      file = file.path(
        table_dir,
        "06_kinase_signature_analysis.xlsx"
      ),
      overwrite = TRUE
    )

    kinase_plot_df <- ksea_like_results %>%
      filter(
        kinase %in% c(
          "CDK4",
          "CDK6",
          "CDK1",
          "AURKA",
          "AURKB",
          "PLK1",
          "TTK"
        ),
        !is.na(ksea_like_z)
      )

    if (nrow(kinase_plot_df) > 0) {
      p_kinase <- ggplot(
        kinase_plot_df,
        aes(
          x = kinase,
          y = ksea_like_z,
          shape = dose
        )
      ) +
        geom_hline(
          yintercept = 0,
          linetype = 2
        ) +
        geom_point(
          size = 3
        ) +
        labs(
          title = "Kinase substrate-set phosphorylation signatures",
          x = NULL,
          y = "KSEA-like Z score"
        ) +
        theme_bw() +
        theme(
          plot.title = element_text(
            hjust = 0.5
          ),
          axis.text.x = element_text(
            angle = 45,
            hjust = 1
          )
        )

      safe_ggsave(
        filename = file.path(
          figure_dir,
          "06_kinase_signature_scores.png"
        ),
        plot = p_kinase,
        width = 9,
        height = 7
      )
    }
  } else {
    message(
      "kinase_substrate_reference.csv 尚未填写有效位点，已跳过激酶特征分析。"
    )
  }
}


# ============================================================================
# 16. 已知 CDK4/6 底物验证：创建标准输入模板
# ============================================================================

# 建议外部文件：
# known_CDK46_substrates.csv
#
# 必需字段：
# substrate_gene
# substrate_accession
# residue
# position
# kinase
# evidence_level
# site_function
# source
#
# 高置信度和扩展底物应通过 evidence_level 区分。

cdk46_reference_path <- file.path(
  template_dir,
  "known_CDK46_substrates.csv"
)

if (!file.exists(cdk46_reference_path)) {
  cdk46_reference_template <- tibble(
    substrate_gene = c(
      "RB1"
    ),
    substrate_accession = NA_character_,
    residue = NA_character_,
    position = NA_integer_,
    kinase = "CDK4/6",
    evidence_level = "High-confidence or literature-supported",
    site_function = NA_character_,
    source = NA_character_
  )

  write_csv(
    cdk46_reference_template,
    cdk46_reference_path
  )

  message(
    "已创建 CDK4/6 底物模板：",
    cdk46_reference_path
  )
}


# ============================================================================
# 17. 已知 CDK4/6 底物：精确位点匹配和内部参照分析
# ============================================================================

if (file.exists(cdk46_reference_path)) {
  cdk46_reference <- read_csv(
    cdk46_reference_path,
    show_col_types = FALSE
  ) %>%
    mutate(
      substrate_gene =
        str_trim(
          substrate_gene
        ),

      substrate_accession =
        str_trim(
          substrate_accession
        ),

      residue =
        str_to_upper(
          str_trim(
            residue
          )
        ),

      position =
        as.integer(
          position
        ),

      known_site =
        paste0(
          residue,
          position
        ),

      reference_site_id =
        paste(
          substrate_accession,
          position,
          residue,
          sep = "_"
        )
    ) %>%
    filter(
      !is.na(position),
      !is.na(residue),
      residue %in% c(
        "S",
        "T",
        "Y"
      )
    )

  if (nrow(cdk46_reference) > 0) {
    # 精确位点匹配。
    cdk46_exact_matches <- site_data %>%
      inner_join(
        cdk46_reference,
        by = c(
          "protein_accession_clean" =
            "substrate_accession",

          "Position" =
            "position",

          "Amino acid" =
            "residue"
        )
      ) %>%
      distinct(
        reference_site_id,
        site_id,
        .keep_all = TRUE
      )

    # 蛋白是否至少在本磷酸化组中出现。
    detected_proteins <- site_data %>%
      distinct(
        protein_accession_clean
      ) %>%
      mutate(
        protein_detected = TRUE
      )

    # 匹配状态汇总。
    cdk46_detection_summary <- cdk46_reference %>%
      left_join(
        detected_proteins,
        by = c(
          "substrate_accession" =
            "protein_accession_clean"
        )
      ) %>%
      left_join(
        cdk46_exact_matches %>%
          transmute(
            reference_site_id,
            exact_site_detected = TRUE,
            detected_site_id = site_id,
            motif_type,
            motif_sequence_15mer,
            localization_probability =
              `Localization probability`,
            Pal1_ratio =
              `Pal1/Con Ratio`,
            Pal1_log2FC,
            Pal1_p_value =
              `Pal1/Con P value`,
            Pal5_ratio =
              `Pal5/Con Ratio`,
            Pal5_log2FC,
            Pal5_p_value =
              `Pal5/Con P value`
          ),
        by = "reference_site_id"
      ) %>%
      mutate(
        protein_detected =
          replace_na(
            protein_detected,
            FALSE
          ),

        exact_site_detected =
          replace_na(
            exact_site_detected,
            FALSE
          ),

        match_class = case_when(
          exact_site_detected ~
            "Exact phosphosite detected",

          protein_detected &
            !exact_site_detected ~
            "Protein detected, known site not detected",

          !protein_detected ~
            "Protein not detected",

          TRUE ~
            "Unclassified"
        ),

        dose_delta_log2FC =
          Pal5_log2FC -
          Pal1_log2FC,

        Pal1_direction = case_when(
          is.na(Pal1_log2FC) ~ NA_character_,
          Pal1_log2FC < 0 ~ "Down",
          Pal1_log2FC > 0 ~ "Up",
          TRUE ~ "No change"
        ),

        Pal5_direction = case_when(
          is.na(Pal5_log2FC) ~ NA_character_,
          Pal5_log2FC < 0 ~ "Down",
          Pal5_log2FC > 0 ~ "Up",
          TRUE ~ "No change"
        ),

        stronger_reduction_at_Pal5 =
          !is.na(dose_delta_log2FC) &
          dose_delta_log2FC < 0
      )

    # 精确匹配位点集合与背景分布比较。
    compare_known_substrate_set <- function(
        exact_matches,
        background_data,
        log2fc_col,
        dose
    ) {
      log2fc_col <- rlang::ensym(log2fc_col)

      known_values <- exact_matches %>%
        distinct(
          site_id,
          .keep_all = TRUE
        ) %>%
        pull(!!log2fc_col)

      known_values <- known_values[
        !is.na(known_values)
      ]

      background_values <- background_data %>%
        filter(
          !site_id %in%
            unique(
              exact_matches$site_id
            )
        ) %>%
        pull(!!log2fc_col)

      background_values <- background_values[
        !is.na(background_values)
      ]

      if (
        length(known_values) < 2 ||
          length(background_values) < 2
      ) {
        return(
          tibble(
            dose = dose,
            known_site_n =
              length(known_values),
            background_site_n =
              length(background_values),
            known_median =
              ifelse(
                length(known_values) > 0,
                median(known_values),
                NA_real_
              ),
            background_median =
              ifelse(
                length(background_values) > 0,
                median(background_values),
                NA_real_
              ),
            wilcox_p = NA_real_
          )
        )
      }

      wt <- wilcox.test(
        known_values,
        background_values,
        exact = FALSE
      )

      background_down_rate <- mean(
        background_values < 0
      )

      number_known_down <- sum(
        known_values < 0
      )

      bt <- binom.test(
        x = number_known_down,
        n = length(known_values),
        p = background_down_rate,
        alternative = "greater"
      )

      tibble(
        dose = dose,
        known_site_n =
          length(known_values),
        background_site_n =
          length(background_values),
        known_median =
          median(known_values),
        background_median =
          median(background_values),
        median_difference =
          median(known_values) -
          median(background_values),
        known_down_n =
          number_known_down,
        known_down_rate =
          mean(known_values < 0),
        background_down_rate =
          background_down_rate,
        wilcox_p =
          wt$p.value,
        directional_binomial_p =
          bt$p.value
      )
    }

    cdk46_set_tests <- bind_rows(
      compare_known_substrate_set(
        cdk46_exact_matches,
        pal1_background,
        Pal1_log2FC,
        "Pal1"
      ),

      compare_known_substrate_set(
        cdk46_exact_matches,
        pal5_background,
        Pal5_log2FC,
        "Pal5"
      )
    ) %>%
      mutate(
        wilcox_fdr = p.adjust(
          wilcox_p,
          method = "BH"
        ),

        directional_binomial_fdr =
          p.adjust(
            directional_binomial_p,
            method = "BH"
          )
      )

    # 仅对 Pal1 和 Pal5 均有数值的精确匹配位点进行剂量配对。
    cdk46_dose_pair_data <- cdk46_exact_matches %>%
      distinct(
        site_id,
        .keep_all = TRUE
      ) %>%
      filter(
        !is.na(Pal1_log2FC),
        !is.na(Pal5_log2FC)
      ) %>%
      mutate(
        dose_delta_log2FC =
          Pal5_log2FC -
          Pal1_log2FC
      )

    if (nrow(cdk46_dose_pair_data) >= 2) {
      cdk46_dose_paired_test <- tibble(
        n_sites =
          nrow(cdk46_dose_pair_data),

        median_Pal1 =
          median(
            cdk46_dose_pair_data$Pal1_log2FC
          ),

        median_Pal5 =
          median(
            cdk46_dose_pair_data$Pal5_log2FC
          ),

        median_delta =
          median(
            cdk46_dose_pair_data$dose_delta_log2FC
          ),

        paired_wilcox_p =
          wilcox.test(
            cdk46_dose_pair_data$Pal5_log2FC,
            cdk46_dose_pair_data$Pal1_log2FC,
            paired = TRUE,
            exact = FALSE
          )$p.value
      )
    } else {
      cdk46_dose_paired_test <- tibble(
        n_sites =
          nrow(cdk46_dose_pair_data),
        median_Pal1 = NA_real_,
        median_Pal5 = NA_real_,
        median_delta = NA_real_,
        paired_wilcox_p = NA_real_
      )
    }

    write.xlsx(
      list(
        Reference =
          cdk46_reference,

        Detection_summary =
          cdk46_detection_summary,

        Exact_matches =
          cdk46_exact_matches,

        Set_level_tests =
          cdk46_set_tests,

        Dose_pair_data =
          cdk46_dose_pair_data,

        Dose_paired_test =
          cdk46_dose_paired_test
      ),
      file = file.path(
        table_dir,
        "07_known_CDK46_substrate_validation.xlsx"
      ),
      overwrite = TRUE
    )

    # 已知底物 Pal1/Pal5 配对图。
    if (nrow(cdk46_dose_pair_data) > 0) {
      cdk46_pair_plot_data <- cdk46_dose_pair_data %>%
        select(
          site_id,
          substrate_gene,
          known_site,
          Pal1_log2FC,
          Pal5_log2FC
        ) %>%
        pivot_longer(
          cols = c(
            Pal1_log2FC,
            Pal5_log2FC
          ),
          names_to = "dose",
          values_to = "log2FC"
        ) %>%
        mutate(
          dose = recode(
            dose,
            Pal1_log2FC = "Pal1",
            Pal5_log2FC = "Pal5"
          )
        )

      p_cdk46_pair <- ggplot(
        cdk46_pair_plot_data,
        aes(
          x = dose,
          y = log2FC,
          group = site_id
        )
      ) +
        geom_hline(
          yintercept = 0,
          linetype = 2
        ) +
        geom_line(
          alpha = 0.5
        ) +
        geom_point(
          size = 2
        ) +
        labs(
          title = "Known CDK4/6 substrate phosphosites",
          x = NULL,
          y = "log2 fold change"
        ) +
        theme_bw() +
        theme(
          plot.title = element_text(
            hjust = 0.5
          )
        )

      safe_ggsave(
        filename = file.path(
          figure_dir,
          "07_known_CDK46_substrate_paired_plot.png"
        ),
        plot = p_cdk46_pair,
        width = 8,
        height = 7
      )
    }
  } else {
    message(
      "known_CDK46_substrates.csv 尚未填写有效位点，已跳过已知 CDK4/6 底物验证。"
    )
  }
}


# ============================================================================
# 18. 汇总运行信息
# ============================================================================

analysis_summary <- tibble(
  item = c(
    "Pal1 quantified S/T sites",
    "Pal5 quantified S/T sites",
    "Pal1 significantly downregulated S/T sites",
    "Pal5 significantly downregulated S/T sites",
    "Pal1 background genes mapped to ENTREZID",
    "Pal5 background genes mapped to ENTREZID",
    "Pal1 downregulated genes mapped to ENTREZID",
    "Pal5 downregulated genes mapped to ENTREZID",
    "Target gene-set categories",
    "Mitotic candidate phosphosites"
  ),

  value = c(
    nrow(pal1_background),
    nrow(pal5_background),
    nrow(pal1_down),
    nrow(pal5_down),
    length(pal1_background_entrez),
    length(pal5_background_entrez),
    length(pal1_down_entrez),
    length(pal5_down_entrez),
    length(target_gene_sets),
    nrow(candidate_table)
  )
)

write_csv(
  analysis_summary,
  file.path(
    table_dir,
    "99_analysis_summary.csv"
  )
)

writeLines(
  capture.output(
    sessionInfo()
  ),
  con = file.path(
    analysis_dir,
    "sessionInfo.txt"
  )
)

message(
  paste0(
    "\n分析代码运行结束。\n",
    "结果目录：",
    analysis_dir,
    "\n\n",
    "请特别检查：\n",
    "1. tables/01_global_ORA_results.xlsx\n",
    "2. tables/02_ranked_GSEA_results.xlsx\n",
    "3. tables/04_Pal1_Pal5_consistency.xlsx\n",
    "4. tables/05B_target_gene_set_Fisher_enrichment.csv\n",
    "5. tables/05D_mitotic_candidate_phosphosites.csv\n",
    "6. input_templates/kinase_substrate_reference.csv\n",
    "7. input_templates/known_CDK46_substrates.csv\n"
  )
)
