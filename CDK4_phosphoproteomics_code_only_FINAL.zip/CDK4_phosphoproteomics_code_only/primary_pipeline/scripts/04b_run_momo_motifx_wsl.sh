#!/usr/bin/env bash
set -euo pipefail

# Run the R4 MoMo motif-x matrix inside WSL/Linux.
# PROJECT_ROOT defaults to the parent of this script directory, so the whole
# code package can be moved. MOMO_BIN can point to a custom/patched binary.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="${PROJECT_ROOT:-$(cd "${SCRIPT_DIR}/.." && pwd)}"
MOMO_BIN="${MOMO_BIN:-$(command -v momo || true)}"
MEME_RUNTIME_LIB="${MEME_RUNTIME_LIB:-}"

if [[ -z "${MOMO_BIN}" || ! -x "${MOMO_BIN}" ]]; then
  echo "MoMo executable not found. Install MEME Suite or set MOMO_BIN." >&2
  exit 1
fi

R4_DIR="${PROJECT_ROOT}/results/R4_missingness_and_MoMo"
INPUT_DIR="${R4_DIR}/MoMo_inputs"
OUTPUT_DIR="${R4_DIR}/MoMo_output"

export LC_ALL=C
if [[ -n "${MEME_RUNTIME_LIB}" ]]; then
  export LD_LIBRARY_PATH="${MEME_RUNTIME_LIB}:${LD_LIBRARY_PATH:-}"
fi
mkdir -p "${OUTPUT_DIR}"

for dose in Pal1 Pal5; do
  for threshold in 0 0p5 0p6 1; do
    for center in S T; do
      condition="${dose}_log2FC_lt_${threshold}_${center}"
      foreground="${INPUT_DIR}/${dose}_log2FC_lt_${threshold}_foreground_${center}_no_X_15mer.txt"
      background="${INPUT_DIR}/${dose}_background_${center}_no_X_15mer.txt"
      out="${OUTPUT_DIR}/${condition}"

      echo "Running ${condition}"
      "${MOMO_BIN}" motifx \
        --oc "${out}" \
        --width 15 \
        --protein-database "${background}" \
        --db-background \
        --remove-unknowns T \
        --eliminate-repeats 15 \
        --min-occurrences 20 \
        --score-threshold 1e-6 \
        --verbosity 2 \
        "${foreground}"
    done
  done
done

echo "MoMo matrix complete: ${OUTPUT_DIR}"
