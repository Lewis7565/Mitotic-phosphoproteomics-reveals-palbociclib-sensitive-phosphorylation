# Master runner for the cleaned R2.0-R10 workflow.
# Run from the manuscript delivery package root:
#   Rscript scripts/00_run_pipeline.R

source(file.path("scripts", "00_config.R"), encoding = "UTF-8")

run_step <- function(script) {
  message("\n===== Running ", script, " =====")
  source(file.path(project_root, "scripts", script), encoding = "UTF-8")
}

run_step("01_R2_0_data_preparation.R")
run_step("02_R2_1_global_pathway_and_targeted_analysis.R")
run_step("03_R3_threshold_sensitivity.R")
run_step("04_R4_missingness_and_MoMo_inputs.R")
run_step("05_R5_motif_and_dose_response.R")

# Use the frozen kinase reference by default. Refresh from OmniPath only when
# explicitly requested because the API output is time-dependent.
r6_reference_dir <- file.path(
  project_root, "results", "R6_kinase_signature", "input_reference"
)
dir.create(r6_reference_dir, recursive = TRUE, showWarnings = FALSE)
file.copy(
  kinase_reference_config,
  file.path(r6_reference_dir, "kinase_substrate_reference_R6.csv"),
  overwrite = TRUE
)
if (tolower(Sys.getenv("REFRESH_KINASE_REFERENCE", unset = "false")) == "true") {
  run_step("06a_R6_build_kinase_reference.R")
}
run_step("06b_R6_kinase_signature.R")

r7_reference_dir <- file.path(
  project_root, "results", "R7_known_CDK46_substrate_validation", "input_reference"
)
dir.create(r7_reference_dir, recursive = TRUE, showWarnings = FALSE)
if (file.exists(cdk46_annotation_config)) {
  file.copy(
    cdk46_annotation_config,
    file.path(r7_reference_dir, "known_CDK46_site_priority_annotations.csv"),
    overwrite = TRUE
  )
}
run_step("07_R7_CDK46_and_RB1_validation.R")
run_step("08_R8_PLK1_sensitivity.R")
run_step("09_R9_SF_vs_PLK1.R")
run_step("10_R10_site_count_bias_control.R")

capture.output(
  sessionInfo(),
  file = file.path(project_root, "results", "sessionInfo_R2_R10.txt")
)
message("\nR2.0-R10 pipeline complete. Results: ", file.path(project_root, "results"))
