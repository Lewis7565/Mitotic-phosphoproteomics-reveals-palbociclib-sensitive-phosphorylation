# ============================================================================
# 03. Foreground-threshold sensitivity + cutoff-independent validation
# ============================================================================
# 运行位置：建议直接接在你之前两份脚本之后运行。
# 前提：上一份 follow-up 脚本已经创建 site_data、pal1_background、pal5_background、
#       target_gene_sets，以及 GO/Reactome/Fisher/GSEA 的辅助函数。
#
# 本脚本回答导师最新提出的 3 个优先问题：
# 1) foreground threshold sensitivity: log2FC < 0 / -0.5 / -0.6 / -1.0
# 2) cutoff-independent analysis: 全部 quantified sites 的连续 log2FC
# 3) missing-phosphosite motif bias: 预留原始 intensity/abundance 列配置接口
#
# 重要：阈值敏感性分析中 P < 0.05 固定，仅改变 log2FC cutoff；background 固定。
# ============================================================================

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(stringr)
  library(purrr)
  library(tibble)
  library(ggplot2)
  library(readr)
  library(openxlsx)
  library(forcats)
  library(clusterProfiler)
  library(org.Hs.eg.db)
  library(AnnotationDbi)
  library(ReactomePA)
})

# ----------------------------------------------------------------------------
# 0. 输入检查和参数
# ----------------------------------------------------------------------------
required_objects_sensitivity <- c(
  "site_data", "pal1_background", "pal5_background", "target_gene_sets"
)
missing_objects_sensitivity <- required_objects_sensitivity[
  !vapply(required_objects_sensitivity, exists, logical(1), inherits = TRUE)
]
if (length(missing_objects_sensitivity) > 0) {
  stop(
    "请先完整运行前两份脚本。缺少对象：",
    paste(missing_objects_sensitivity, collapse = ", ")
  )
}

required_functions_sensitivity <- c(
  "split_gene_symbols", "map_symbol_to_entrez", "safe_enrich_df",
  "fisher_enrichment", "run_go_ora", "run_reactome_ora",
  "run_target_site_fisher", "run_target_gene_fisher",
  "run_go_gsea", "run_reactome_gsea", "safe_ggsave"
)
missing_functions_sensitivity <- required_functions_sensitivity[
  !vapply(required_functions_sensitivity, exists, logical(1), inherits = TRUE)
]
if (length(missing_functions_sensitivity) > 0) {
  stop(
    "前一份 follow-up 脚本中的辅助函数尚未加载：",
    paste(missing_functions_sensitivity, collapse = ", ")
  )
}

# 如果旧脚本还没有 SF 分类，这里统一补上。
site_data <- site_data %>%
  mutate(
    plus1_aa = substr(motif_sequence_15mer, 9, 9),
    motif_type = case_when(
      motif_center_aa == "S" & plus1_aa == "P" ~ "SP",
      motif_center_aa == "T" & plus1_aa == "P" ~ "TP",
      motif_center_aa == "S" & plus1_aa == "F" ~ "SF",
      motif_center_aa == "S" ~ "Other_S",
      motif_center_aa == "T" ~ "Other_T",
      motif_center_aa == "Y" ~ "Y",
      TRUE ~ NA_character_
    ),
    proline_directed = motif_type %in% c("SP", "TP"),
    sf_positive = motif_type == "SF"
  )

# 保持与原分析相同的 quantified S/T background。
pal1_background <- site_data %>%
  filter(
    !is.na(motif_sequence_15mer),
    motif_center_aa %in% c("S", "T"),
    !is.na(`Pal1/Con Ratio`), `Pal1/Con Ratio` > 0,
    !is.na(`Pal1/Con P value`),
    !is.na(Pal1_log2FC)
  ) %>%
  distinct(site_id, .keep_all = TRUE)

pal5_background <- site_data %>%
  filter(
    !is.na(motif_sequence_15mer),
    motif_center_aa %in% c("S", "T"),
    !is.na(`Pal5/Con Ratio`), `Pal5/Con Ratio` > 0,
    !is.na(`Pal5/Con P value`),
    !is.na(Pal5_log2FC)
  ) %>%
  distinct(site_id, .keep_all = TRUE)

thresholds <- c(0, -0.5, -0.6, -1.0)
foreground_p_cutoff <- 0.05
sensitivity_fdr_cutoff <- 0.05
exploratory_fdr_cutoff <- 0.20

# 输出目录：接在旧 analysis_dir 下。
if (!exists("analysis_dir")) {
  analysis_dir <- file.path(getwd(), "phosphoproteomics_followup_analysis")
}
sensitivity_dir <- file.path(analysis_dir, "foreground_threshold_sensitivity")
sensitivity_table_dir <- file.path(sensitivity_dir, "tables")
sensitivity_figure_dir <- file.path(sensitivity_dir, "figures")
momo_export_dir <- file.path(sensitivity_dir, "MoMo_inputs")
dir.create(sensitivity_table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(sensitivity_figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(momo_export_dir, recursive = TRUE, showWarnings = FALSE)

threshold_label <- function(x) {
  paste0("log2FC_lt_", ifelse(x == 0, "0", str_replace(as.character(abs(x)), "\\.", "p")))
}

# ----------------------------------------------------------------------------
# 1. 基础函数：根据不同 cutoff 构建 foreground
# ----------------------------------------------------------------------------
build_foreground <- function(background_data, dose, log2fc_cutoff, p_cutoff = 0.05) {
  if (dose == "Pal1") {
    background_data %>%
      filter(
        `Pal1/Con P value` < p_cutoff,
        Pal1_log2FC < log2fc_cutoff
      )
  } else if (dose == "Pal5") {
    background_data %>%
      filter(
        `Pal5/Con P value` < p_cutoff,
        Pal5_log2FC < log2fc_cutoff
      )
  } else {
    stop("dose 必须是 Pal1 或 Pal5")
  }
}

# ----------------------------------------------------------------------------
# 2. Motif enrichment：SP / TP / SF / SP+TP
# ----------------------------------------------------------------------------
# SP 和 SF 只在 S 位点内部比较；TP 只在 T 位点内部比较，避免 S/T 比例本身造成混杂。
# SP+TP (proline-directed) 则在全部 S/T 位点中比较。
run_one_motif_fisher <- function(background_data, foreground_data, motif_name, dose, cutoff) {
  if (motif_name == "SP") {
    bg <- background_data %>% filter(motif_center_aa == "S")
    fg <- foreground_data %>% filter(motif_center_aa == "S")
    target_ids <- bg %>% filter(motif_type == "SP") %>% pull(site_id) %>% unique()
    comparison <- "SP vs other S"
  } else if (motif_name == "TP") {
    bg <- background_data %>% filter(motif_center_aa == "T")
    fg <- foreground_data %>% filter(motif_center_aa == "T")
    target_ids <- bg %>% filter(motif_type == "TP") %>% pull(site_id) %>% unique()
    comparison <- "TP vs other T"
  } else if (motif_name == "SF") {
    bg <- background_data %>% filter(motif_center_aa == "S")
    fg <- foreground_data %>% filter(motif_center_aa == "S")
    target_ids <- bg %>% filter(motif_type == "SF") %>% pull(site_id) %>% unique()
    comparison <- "SF vs other S"
  } else if (motif_name == "SP_TP") {
    bg <- background_data %>% filter(motif_center_aa %in% c("S", "T"))
    fg <- foreground_data %>% filter(motif_center_aa %in% c("S", "T"))
    target_ids <- bg %>% filter(proline_directed) %>% pull(site_id) %>% unique()
    comparison <- "SP+TP vs other S/T"
  } else {
    stop("未知 motif：", motif_name)
  }

  out <- fisher_enrichment(
    foreground_ids = unique(fg$site_id),
    background_ids = unique(bg$site_id),
    target_ids = target_ids,
    category_name = motif_name,
    analysis_level = "Phosphosite",
    dose = dose
  )

  out %>%
    mutate(
      log2fc_cutoff = cutoff,
      threshold = threshold_label(cutoff),
      comparison = comparison,
      foreground_fraction = if_else(foreground_total > 0, foreground_target / foreground_total, NA_real_),
      background_fraction = if_else(background_total > 0, (foreground_target + background_target) / background_total, NA_real_)
    )
}

run_motif_threshold_panel <- function(background_data, foreground_data, dose, cutoff) {
  map_dfr(
    c("SP", "TP", "SF", "SP_TP"),
    ~ run_one_motif_fisher(background_data, foreground_data, .x, dose, cutoff)
  )
}

# ----------------------------------------------------------------------------
# 3. ORA：GO BP/CC/MF + Reactome
# ----------------------------------------------------------------------------
build_entrez_sets <- function(background_data, foreground_data) {
  bg_symbols <- split_gene_symbols(background_data) %>%
    distinct(gene_symbol) %>%
    pull(gene_symbol)
  fg_symbols <- split_gene_symbols(foreground_data) %>%
    distinct(gene_symbol) %>%
    pull(gene_symbol)

  bg_map <- map_symbol_to_entrez(bg_symbols)
  fg_map <- map_symbol_to_entrez(fg_symbols)
  bg_entrez <- unique(bg_map$ENTREZID)
  fg_entrez <- intersect(unique(fg_map$ENTREZID), bg_entrez)

  list(
    background_symbols = bg_symbols,
    foreground_symbols = fg_symbols,
    background_entrez = bg_entrez,
    foreground_entrez = fg_entrez
  )
}

run_threshold_ora <- function(background_data, foreground_data, dose, cutoff) {
  ids <- build_entrez_sets(background_data, foreground_data)

  res <- list(
    GO_BP = safe_enrich_df(run_go_ora(ids$foreground_entrez, ids$background_entrez, "BP")),
    GO_CC = safe_enrich_df(run_go_ora(ids$foreground_entrez, ids$background_entrez, "CC")),
    GO_MF = safe_enrich_df(run_go_ora(ids$foreground_entrez, ids$background_entrez, "MF")),
    Reactome = safe_enrich_df(run_reactome_ora(ids$foreground_entrez, ids$background_entrez))
  )

  bind_rows(res, .id = "database") %>%
    mutate(
      dose = dose,
      log2fc_cutoff = cutoff,
      threshold = threshold_label(cutoff),
      foreground_genes = length(ids$foreground_entrez),
      background_genes = length(ids$background_entrez)
    )
}

# ----------------------------------------------------------------------------
# 4. Targeted mitotic / kinetochore enrichment
# ----------------------------------------------------------------------------
run_threshold_targeted <- function(background_data, foreground_data, dose, cutoff) {
  bind_rows(
    run_target_site_fisher(background_data, foreground_data, target_gene_sets, dose),
    run_target_gene_fisher(background_data, foreground_data, target_gene_sets, dose)
  ) %>%
    group_by(analysis_level) %>%
    mutate(p_adjust = p.adjust(p_value, method = "BH")) %>%
    ungroup() %>%
    mutate(
      log2fc_cutoff = cutoff,
      threshold = threshold_label(cutoff)
    )
}

# ----------------------------------------------------------------------------
# 5. MoMo 输入导出
# ----------------------------------------------------------------------------
# 你已经在其他代码中运行 MoMo，因此这里不重复实现 MoMo 本身；
# 每个 threshold 自动导出 foreground/background 15-mer，方便直接接入你的 MoMo 脚本。
export_momo_sequences <- function(background_data, foreground_data, dose, cutoff) {
  tag <- paste(dose, threshold_label(cutoff), sep = "_")

  bg_seq <- background_data %>%
    filter(!is.na(motif_sequence_15mer)) %>%
    distinct(site_id, .keep_all = TRUE) %>%
    select(site_id, motif_sequence_15mer, motif_type, `Gene name`, `Protein accession`, Position)

  fg_seq <- foreground_data %>%
    filter(!is.na(motif_sequence_15mer)) %>%
    distinct(site_id, .keep_all = TRUE) %>%
    select(site_id, motif_sequence_15mer, motif_type, `Gene name`, `Protein accession`, Position)

  write_csv(bg_seq, file.path(momo_export_dir, paste0(tag, "_background_15mer.csv")))
  write_csv(fg_seq, file.path(momo_export_dir, paste0(tag, "_foreground_15mer.csv")))
  write_lines(bg_seq$motif_sequence_15mer, file.path(momo_export_dir, paste0(tag, "_background_sequences.txt")))
  write_lines(fg_seq$motif_sequence_15mer, file.path(momo_export_dir, paste0(tag, "_foreground_sequences.txt")))
}

# ----------------------------------------------------------------------------
# 6. 批量运行四个 cutoff × Pal1/Pal5
# ----------------------------------------------------------------------------
threshold_results <- list()

for (dose in c("Pal1", "Pal5")) {
  background_data <- if (dose == "Pal1") pal1_background else pal5_background

  for (cutoff in thresholds) {
    message("Running threshold sensitivity: ", dose, " | log2FC < ", cutoff)

    foreground_data <- build_foreground(
      background_data = background_data,
      dose = dose,
      log2fc_cutoff = cutoff,
      p_cutoff = foreground_p_cutoff
    )

    key <- paste(dose, threshold_label(cutoff), sep = "__")

    size_table <- tibble(
      dose = dose,
      log2fc_cutoff = cutoff,
      threshold = threshold_label(cutoff),
      background_sites = n_distinct(background_data$site_id),
      foreground_sites = n_distinct(foreground_data$site_id),
      background_genes = n_distinct(split_gene_symbols(background_data)$gene_symbol),
      foreground_genes = n_distinct(split_gene_symbols(foreground_data)$gene_symbol)
    )

    motif_table <- run_motif_threshold_panel(background_data, foreground_data, dose, cutoff)
    ora_table <- run_threshold_ora(background_data, foreground_data, dose, cutoff)
    targeted_table <- run_threshold_targeted(background_data, foreground_data, dose, cutoff)

    export_momo_sequences(background_data, foreground_data, dose, cutoff)

    threshold_results[[key]] <- list(
      size = size_table,
      motif = motif_table,
      ora = ora_table,
      targeted = targeted_table
    )
  }
}

foreground_size_summary <- map_dfr(threshold_results, "size")
motif_threshold_summary <- map_dfr(threshold_results, "motif") %>%
  group_by(dose, category) %>%
  mutate(p_adjust_across_thresholds = p.adjust(p_value, method = "BH")) %>%
  ungroup()
ora_threshold_all <- map_dfr(threshold_results, "ora")
targeted_threshold_all <- map_dfr(threshold_results, "targeted")

write.xlsx(
  list(
    Foreground_sizes = foreground_size_summary,
    Motif_thresholds = motif_threshold_summary,
    ORA_all = ora_threshold_all,
    Targeted_all = targeted_threshold_all
  ),
  file = file.path(sensitivity_table_dir, "01_threshold_sensitivity_all_results.xlsx"),
  overwrite = TRUE
)

# ----------------------------------------------------------------------------
# 7. Threshold-stability summary
# ----------------------------------------------------------------------------
# ORA：统计每个 pathway 在 4 个 cutoff 中显著几次，以及方向/强度信息。
# ORA 本身没有 NES，因此稳定性以 adjusted P、GeneRatio/Count 和重复出现次数为主。
ora_stability <- ora_threshold_all %>%
  filter(!is.na(ID), !is.na(p.adjust)) %>%
  group_by(dose, database, ID, Description) %>%
  summarise(
    n_thresholds_tested = n_distinct(log2fc_cutoff),
    n_FDR_lt_0p05 = sum(p.adjust < sensitivity_fdr_cutoff, na.rm = TRUE),
    n_FDR_lt_0p20 = sum(p.adjust < exploratory_fdr_cutoff, na.rm = TRUE),
    best_FDR = min(p.adjust, na.rm = TRUE),
    median_Count = median(Count, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  arrange(dose, database, desc(n_FDR_lt_0p05), best_FDR)

# Targeted：OR > 1 = enrichment；OR < 1 = depletion。
targeted_stability <- targeted_threshold_all %>%
  group_by(dose, analysis_level, category) %>%
  summarise(
    n_thresholds_tested = n_distinct(log2fc_cutoff),
    n_OR_gt_1 = sum(odds_ratio > 1, na.rm = TRUE),
    n_FDR_lt_0p05 = sum(p_adjust < sensitivity_fdr_cutoff, na.rm = TRUE),
    n_FDR_lt_0p20 = sum(p_adjust < exploratory_fdr_cutoff, na.rm = TRUE),
    median_OR = median(odds_ratio[is.finite(odds_ratio)], na.rm = TRUE),
    best_FDR = min(p_adjust, na.rm = TRUE),
    .groups = "drop"
  )

motif_stability <- motif_threshold_summary %>%
  group_by(dose, category, comparison) %>%
  summarise(
    n_thresholds_tested = n_distinct(log2fc_cutoff),
    n_OR_gt_1 = sum(odds_ratio > 1, na.rm = TRUE),
    n_OR_lt_1 = sum(odds_ratio < 1, na.rm = TRUE),
    median_OR = median(odds_ratio[is.finite(odds_ratio)], na.rm = TRUE),
    min_p = min(p_value, na.rm = TRUE),
    .groups = "drop"
  )

write.xlsx(
  list(
    Motif_stability = motif_stability,
    ORA_stability = ora_stability,
    Targeted_stability = targeted_stability
  ),
  file = file.path(sensitivity_table_dir, "02_threshold_stability_summary.xlsx"),
  overwrite = TRUE
)

# ----------------------------------------------------------------------------
# 8. 可视化：foreground size + motif OR across thresholds
# ----------------------------------------------------------------------------
p_size <- ggplot(
  foreground_size_summary,
  aes(x = log2fc_cutoff, y = foreground_sites, group = dose, shape = dose)
) +
  geom_line() +
  geom_point(size = 3) +
  scale_x_reverse(breaks = thresholds) +
  labs(
    title = "Foreground size across log2FC thresholds",
    x = "Foreground criterion: log2FC < cutoff (P < 0.05 fixed)",
    y = "Number of phosphosites"
  ) +
  theme_bw()

safe_ggsave(
  file.path(sensitivity_figure_dir, "01_foreground_size_vs_threshold.png"),
  p_size, width = 8, height = 6
)

motif_plot_df <- motif_threshold_summary %>%
  filter(is.finite(odds_ratio), odds_ratio > 0)

p_motif <- ggplot(
  motif_plot_df,
  aes(x = log2fc_cutoff, y = odds_ratio, group = dose, shape = dose)
) +
  geom_hline(yintercept = 1, linetype = 2) +
  geom_line() +
  geom_point(size = 2.5) +
  scale_x_reverse(breaks = thresholds) +
  scale_y_log10() +
  facet_wrap(~ category, scales = "free_y") +
  labs(
    title = "Motif enrichment/depletion across foreground thresholds",
    x = "Foreground criterion: log2FC < cutoff (P < 0.05 fixed)",
    y = "Odds ratio (log10 scale)"
  ) +
  theme_bw()

safe_ggsave(
  file.path(sensitivity_figure_dir, "02_motif_OR_vs_threshold.png"),
  p_motif, width = 10, height = 8
)

# ============================================================================
# 9. Cutoff-independent motif analysis：使用所有 quantified sites 的 log2FC
# ============================================================================
# 与 Fisher 不同，这里不定义 foreground。
# SP vs other S、TP vs other T、SF vs other S、SP+TP vs other S/T。
run_continuous_motif_test <- function(background_data, dose, motif_name) {
  log2fc_col <- if (dose == "Pal1") "Pal1_log2FC" else "Pal5_log2FC"

  if (motif_name == "SP") {
    df <- background_data %>% filter(motif_center_aa == "S") %>%
      mutate(group = if_else(motif_type == "SP", "Motif", "Other"))
    comparison <- "SP vs other S"
  } else if (motif_name == "TP") {
    df <- background_data %>% filter(motif_center_aa == "T") %>%
      mutate(group = if_else(motif_type == "TP", "Motif", "Other"))
    comparison <- "TP vs other T"
  } else if (motif_name == "SF") {
    df <- background_data %>% filter(motif_center_aa == "S") %>%
      mutate(group = if_else(motif_type == "SF", "Motif", "Other"))
    comparison <- "SF vs other S"
  } else if (motif_name == "SP_TP") {
    df <- background_data %>% filter(motif_center_aa %in% c("S", "T")) %>%
      mutate(group = if_else(proline_directed, "Motif", "Other"))
    comparison <- "SP+TP vs other S/T"
  } else {
    stop("未知 motif")
  }

  df <- df %>%
    filter(!is.na(.data[[log2fc_col]]), !is.na(group))

  motif_values <- df %>% filter(group == "Motif") %>% pull(all_of(log2fc_col))
  other_values <- df %>% filter(group == "Other") %>% pull(all_of(log2fc_col))

  p <- if (length(motif_values) >= 3 && length(other_values) >= 3) {
    wilcox.test(motif_values, other_values, alternative = "two.sided", exact = FALSE)$p.value
  } else {
    NA_real_
  }

  tibble(
    dose = dose,
    motif = motif_name,
    comparison = comparison,
    n_motif = length(motif_values),
    n_other = length(other_values),
    median_log2FC_motif = median(motif_values, na.rm = TRUE),
    median_log2FC_other = median(other_values, na.rm = TRUE),
    median_difference = median(motif_values, na.rm = TRUE) - median(other_values, na.rm = TRUE),
    wilcox_p = p
  )
}

continuous_motif_results <- bind_rows(
  map_dfr(c("SP", "TP", "SF", "SP_TP"), ~ run_continuous_motif_test(pal1_background, "Pal1", .x)),
  map_dfr(c("SP", "TP", "SF", "SP_TP"), ~ run_continuous_motif_test(pal5_background, "Pal5", .x))
) %>%
  group_by(dose) %>%
  mutate(wilcox_FDR = p.adjust(wilcox_p, method = "BH")) %>%
  ungroup()

write_csv(
  continuous_motif_results,
  file.path(sensitivity_table_dir, "03_cutoff_independent_motif_log2FC_tests.csv")
)

# ============================================================================
# 10. Cutoff-independent pathway analysis：直接使用 log2FC 排序
# ============================================================================
# 你之前的 GSEA score = sign(log2FC) * -log10(P)。
# 这仍然可以保留为“legacy/site-significance weighted ranking”。
# 但导师这次明确要求 full ranked log2FC distribution，因此这里新增：
#   A. Median-site log2FC ranking（主推荐：不由单个最低位点支配）
#   B. Minimum-site log2FC ranking（用于与旧 minimum-site 逻辑对照）
# 注意：GSEA 需要每个 gene/ENTREZID 只有一个 score，因此必须做 gene-level aggregation。

build_log2fc_gene_rank <- function(data, dose, method = c("median", "minimum")) {
  method <- match.arg(method)
  log2fc_col <- if (dose == "Pal1") "Pal1_log2FC" else "Pal5_log2FC"

  long <- split_gene_symbols(data) %>%
    filter(!is.na(.data[[log2fc_col]]))

  if (method == "median") {
    gene_scores <- long %>%
      group_by(gene_symbol) %>%
      summarise(
        gene_log2FC_score = median(.data[[log2fc_col]], na.rm = TRUE),
        n_sites = n_distinct(site_id),
        .groups = "drop"
      )
  } else {
    gene_scores <- long %>%
      group_by(gene_symbol) %>%
      summarise(
        gene_log2FC_score = min(.data[[log2fc_col]], na.rm = TRUE),
        n_sites = n_distinct(site_id),
        .groups = "drop"
      )
  }

  gene_map <- map_symbol_to_entrez(gene_scores$gene_symbol)

  rank_table <- gene_scores %>%
    inner_join(gene_map, by = c("gene_symbol" = "SYMBOL")) %>%
    group_by(ENTREZID) %>%
    slice_max(order_by = abs(gene_log2FC_score), n = 1, with_ties = FALSE) %>%
    ungroup()

  gene_list <- rank_table$gene_log2FC_score
  names(gene_list) <- rank_table$ENTREZID
  gene_list <- sort(gene_list, decreasing = TRUE)

  list(table = rank_table, gene_list = gene_list)
}

run_custom_target_gsea <- function(gene_list, target_gene_sets) {
  target_entrez <- imap_dfr(
    target_gene_sets,
    function(symbols, set_name) {
      mapped <- map_symbol_to_entrez(symbols)
      genes <- unique(mapped$ENTREZID)
      genes <- genes[!is.na(genes)]
      if (length(genes) == 0) {
        return(tibble(term = character(), gene = character()))
      }
      tibble(term = rep(set_name, length(genes)), gene = genes)
    }
  ) %>%
    filter(!is.na(gene)) %>%
    distinct(term, gene)

  if (length(gene_list) < 20 || nrow(target_entrez) == 0) return(NULL)

  clusterProfiler::GSEA(
    geneList = gene_list,
    TERM2GENE = target_entrez,
    minGSSize = 3,
    maxGSSize = 500,
    pvalueCutoff = 1,
    pAdjustMethod = "BH",
    eps = if (exists("gsea_eps")) gsea_eps else 1e-20,
    by = "fgsea",
    verbose = FALSE
  )
}

tag_gsea_table <- function(x, dose, method, database) {
  out <- safe_enrich_df(x)
  if (nrow(out) == 0) {
    return(out)
  }
  out %>% mutate(dose = dose, aggregation = method, database = database)
}

cutoff_independent_gsea_results <- list()
cutoff_independent_rank_inputs <- list()

for (dose in c("Pal1", "Pal5")) {
  background_data <- if (dose == "Pal1") pal1_background else pal5_background

  for (method in c("median", "minimum")) {
    rank_obj <- build_log2fc_gene_rank(background_data, dose, method)
    gene_list <- rank_obj$gene_list
    key <- paste(dose, method, sep = "_")

    cutoff_independent_rank_inputs[[key]] <- rank_obj$table %>%
      mutate(dose = dose, aggregation = method)

    cutoff_independent_gsea_results[[paste0(key, "_GO_BP")]] <-
      tag_gsea_table(run_go_gsea(gene_list, "BP"), dose, method, "GO_BP")

    cutoff_independent_gsea_results[[paste0(key, "_GO_CC")]] <-
      tag_gsea_table(run_go_gsea(gene_list, "CC"), dose, method, "GO_CC")

    cutoff_independent_gsea_results[[paste0(key, "_GO_MF")]] <-
      tag_gsea_table(run_go_gsea(gene_list, "MF"), dose, method, "GO_MF")

    cutoff_independent_gsea_results[[paste0(key, "_Reactome")]] <-
      tag_gsea_table(run_reactome_gsea(gene_list), dose, method, "Reactome")

    cutoff_independent_gsea_results[[paste0(key, "_Targeted")]] <-
      tag_gsea_table(run_custom_target_gsea(gene_list, target_gene_sets), dose, method, "Targeted_mitotic")
  }
}

cutoff_independent_gsea_all <- bind_rows(cutoff_independent_gsea_results)
cutoff_independent_rank_all <- bind_rows(cutoff_independent_rank_inputs)

write.xlsx(
  list(
    Gene_rank_inputs = cutoff_independent_rank_all,
    GSEA_all = cutoff_independent_gsea_all,
    GSEA_mitosis_focus = cutoff_independent_gsea_all %>%
      filter(
        str_detect(
          Description,
          regex(
            "mitotic|mitosis|kinetochore|centromere|spindle|chromosome segregation|sister chromatid|checkpoint|fibrous corona|RZZ",
            ignore_case = TRUE
          )
        ) | database == "Targeted_mitotic"
      )
  ),
  file = file.path(sensitivity_table_dir, "04_cutoff_independent_log2FC_GSEA.xlsx"),
  overwrite = TRUE
)

# 单独保存旧 ranking score，便于最后并排解释，但不重新替代 log2FC-only 主分析。
legacy_rank_note <- tibble(
  ranking = "Previous analysis",
  formula = "sign(log2FC) * -log10(P value)",
  interpretation = "Direction + site-level statistical significance weighted rank; keep as comparator, not the new cutoff-independent log2FC-only analysis."
)
write_csv(legacy_rank_note, file.path(sensitivity_table_dir, "04B_legacy_GSEA_rank_definition.csv"))

# ============================================================================
# 11. Missing-phosphosite motif bias：需要原始 condition-level abundance/intensity
# ============================================================================
# 重要：仅有 Pal1/Con Ratio、Pal5/Con Ratio 和 P value 不足以可靠区分：
# control-only / Pal1-only / Pal5-only。
# 需要原始 Site_quant 中每个 condition/replicate 的 intensity 或 abundance 列。
#
# 当你确认列名后，把下面三个向量填上，并把 RUN_MISSINGNESS_ANALYSIS 改为 TRUE。
RUN_MISSINGNESS_ANALYSIS <- FALSE

control_abundance_cols <- c(
  # 例："Con_1", "Con_2", "Con_3"
)
pal1_abundance_cols <- c(
  # 例："Pal1_1", "Pal1_2", "Pal1_3"
)
pal5_abundance_cols <- c(
  # 例："Pal5_1", "Pal5_2", "Pal5_3"
)

has_signal <- function(df, cols) {
  if (length(cols) == 0) stop("abundance/intensity 列尚未配置。")
  if (!all(cols %in% colnames(df))) {
    stop("以下 abundance/intensity 列不存在：", paste(setdiff(cols, colnames(df)), collapse = ", "))
  }
  mat <- as.data.frame(df[, cols, drop = FALSE])
  mat[] <- lapply(mat, function(x) suppressWarnings(as.numeric(x)))
  rowSums(!is.na(mat) & mat > 0) > 0
}

run_missingness_motif_fisher <- function(df, group_col, group_name, reference_name = "Detected_all") {
  test_one <- function(motif_name) {
    if (motif_name == "SP") {
      sub <- df %>% filter(motif_center_aa == "S")
      target <- sub$motif_type == "SP"
    } else if (motif_name == "TP") {
      sub <- df %>% filter(motif_center_aa == "T")
      target <- sub$motif_type == "TP"
    } else if (motif_name == "SF") {
      sub <- df %>% filter(motif_center_aa == "S")
      target <- sub$motif_type == "SF"
    } else {
      sub <- df %>% filter(motif_center_aa %in% c("S", "T"))
      target <- sub$proline_directed
    }

    grp <- sub[[group_col]] == group_name
    ref <- sub[[group_col]] == reference_name
    a <- sum(grp & target, na.rm = TRUE)
    b <- sum(grp & !target, na.rm = TRUE)
    c <- sum(ref & target, na.rm = TRUE)
    d <- sum(ref & !target, na.rm = TRUE)

    if ((a + b) == 0 || (c + d) == 0) {
      return(tibble(category = motif_name, odds_ratio = NA_real_, p_value = NA_real_))
    }

    ft <- fisher.test(matrix(c(a, b, c, d), nrow = 2, byrow = TRUE))
    tibble(
      missingness_group = group_name,
      reference_group = reference_name,
      category = motif_name,
      group_target = a,
      group_other = b,
      reference_target = c,
      reference_other = d,
      odds_ratio = unname(ft$estimate),
      p_value = ft$p.value
    )
  }

  map_dfr(c("SP", "TP", "SF", "SP_TP"), test_one)
}

if (RUN_MISSINGNESS_ANALYSIS) {
  site_presence <- site_data %>%
    filter(!is.na(motif_sequence_15mer), motif_center_aa %in% c("S", "T")) %>%
    distinct(site_id, .keep_all = TRUE)

  detected_control_vec <- has_signal(site_presence, control_abundance_cols)
  detected_pal1_vec <- has_signal(site_presence, pal1_abundance_cols)
  detected_pal5_vec <- has_signal(site_presence, pal5_abundance_cols)

  site_presence <- site_presence %>%
    mutate(
      detected_control = detected_control_vec,
      detected_pal1 = detected_pal1_vec,
      detected_pal5 = detected_pal5_vec,
      missingness_group = case_when(
        detected_control & detected_pal1 & detected_pal5 ~ "Detected_all",
        detected_control & !detected_pal1 & !detected_pal5 ~ "Control_only",
        !detected_control & detected_pal1 & !detected_pal5 ~ "Pal1_only",
        !detected_control & !detected_pal1 & detected_pal5 ~ "Pal5_only",
        detected_control & !detected_pal1 & detected_pal5 ~ "Pal1_missing",
        detected_control & detected_pal1 & !detected_pal5 ~ "Pal5_missing",
        !detected_control & detected_pal1 & detected_pal5 ~ "Control_missing",
        TRUE ~ "Other"
      )
    )

  missingness_counts <- site_presence %>%
    count(missingness_group, motif_type, name = "n") %>%
    group_by(missingness_group) %>%
    mutate(fraction = n / sum(n)) %>%
    ungroup()

  missingness_fisher <- map_dfr(
    c("Control_only", "Pal1_only", "Pal5_only", "Pal1_missing", "Pal5_missing"),
    ~ run_missingness_motif_fisher(site_presence, "missingness_group", .x, "Detected_all")
  ) %>%
    group_by(category) %>%
    mutate(p_adjust = p.adjust(p_value, method = "BH")) %>%
    ungroup()

  write.xlsx(
    list(
      Site_presence = site_presence,
      Motif_composition = missingness_counts,
      Motif_Fisher = missingness_fisher
    ),
    file = file.path(sensitivity_table_dir, "05_missing_phosphosite_motif_bias.xlsx"),
    overwrite = TRUE
  )
}

# ============================================================================
# 12. 最终运行摘要
# ============================================================================
message("\n============================================================")
message("Foreground-threshold sensitivity analysis completed.")
message("Main outputs: ", sensitivity_dir)
message("1) 01_threshold_sensitivity_all_results.xlsx")
message("2) 02_threshold_stability_summary.xlsx")
message("3) 03_cutoff_independent_motif_log2FC_tests.csv")
message("4) 04_cutoff_independent_log2FC_GSEA.xlsx")
message("5) MoMo_inputs/ (每个 threshold 的 foreground/background 15-mer)")
if (!RUN_MISSINGNESS_ANALYSIS) {
  message("6) Missingness analysis not run: please configure raw abundance/intensity columns first.")
}
message("============================================================\n")
