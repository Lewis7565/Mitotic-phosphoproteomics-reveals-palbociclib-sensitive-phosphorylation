# ============================================================================
# R6.0 — Kinase-signature analysis
# CDK4/6 vs CDK1 / AURKA / AURKB / PLK1 / TTK(MPS1)
# ============================================================================
# 建议运行顺序：
#   R1.0 -> R2.0 -> R3.0 -> R4.0 -> R5.0 -> 本脚本 R6.0
#
# 核心问题：
#   整体磷酸化响应是否更符合 CDK4/6 substrate suppression，
#   还是更符合其他有丝分裂激酶（CDK1, AURKA/B, PLK1, TTK/MPS1）的改变？
#
# 重要：
# 1) 主分析要求“具体到 phosphosite”的 kinase-substrate reference。
# 2) 不建议仅凭 SP/TP motif 将位点归因给 CDK4/6 或 CDK1：
#    proline-directed motif 缺乏足够 kinase specificity。
# 3) 本脚本会自动创建模板 kinase_substrate_reference_R6.csv。
#    填好后重新运行，即可完成主分析。
# 4) 同时做：
#    - exact site matching / detection coverage
#    - continuous substrate-set shift
#    - KSEA-like Z
#    - empirical permutation test
#    - foreground-threshold Fisher robustness
#    - Pal1 vs Pal5 substrate dose shift
#    - kinase comparison/ranking
# ============================================================================

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(stringr)
  library(purrr)
  library(tibble)
  library(ggplot2)
  library(readr)
  library(openxlsx)
  library(forcats)
})

# ----------------------------------------------------------------------------
# 0. Input check
# ----------------------------------------------------------------------------
required_objects_r6 <- c(
  "site_data",
  "pal1_background",
  "pal5_background"
)

missing_objects_r6 <- required_objects_r6[
  !vapply(required_objects_r6, exists, logical(1), inherits = TRUE)
]

if (length(missing_objects_r6) > 0) {
  stop(
    "请先完整运行前面的分析。缺少对象：",
    paste(missing_objects_r6, collapse = ", ")
  )
}

required_cols_r6 <- c(
  "Protein accession",
  "protein_accession_clean",
  "Gene name",
  "Position",
  "Amino acid",
  "site_id",
  "motif_sequence_15mer",
  "motif_type",
  "Pal1_log2FC",
  "Pal5_log2FC",
  "Pal1/Con P value",
  "Pal5/Con P value"
)

missing_cols_r6 <- setdiff(
  required_cols_r6,
  colnames(site_data)
)

if (length(missing_cols_r6) > 0) {
  stop(
    "site_data 缺少 R6.0 所需列：",
    paste(missing_cols_r6, collapse = ", ")
  )
}

if (!exists("analysis_dir")) {
  analysis_dir <- file.path(
    getwd(),
    "phosphoproteomics_followup_analysis"
  )
}

r6_dir <- file.path(
  analysis_dir,
  "R6_kinase_signature"
)

r6_table_dir <- file.path(r6_dir, "tables")
r6_figure_dir <- file.path(r6_dir, "figures")
r6_input_dir <- file.path(r6_dir, "input_reference")

dir.create(r6_table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(r6_figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(r6_input_dir, recursive = TRUE, showWarnings = FALSE)

set.seed(20260808)

focus_kinases <- c(
  "CDK4",
  "CDK6",
  "CDK1",
  "AURKA",
  "AURKB",
  "PLK1",
  "TTK"
)

thresholds <- c(
  0,
  -0.5,
  -0.6,
  -1.0
)

foreground_p_cutoff <- 0.05
n_permutations <- 10000
min_detected_substrates <- 3

# ----------------------------------------------------------------------------
# 1. Kinase name standardization
# ----------------------------------------------------------------------------
standardize_kinase_name <- function(x) {

  x <- str_to_upper(
    str_trim(
      as.character(x)
    )
  )

  case_when(
    x %in% c(
      "MPS1",
      "TTK",
      "MPS1/TTK",
      "TTK/MPS1"
    ) ~ "TTK",

    x %in% c(
      "AURORA A",
      "AURORA-A",
      "AURKA"
    ) ~ "AURKA",

    x %in% c(
      "AURORA B",
      "AURORA-B",
      "AURKB"
    ) ~ "AURKB",

    x %in% c(
      "CDK4/6",
      "CDK4-CDK6",
      "CDK4_6"
    ) ~ "CDK4_6",

    TRUE ~ x
  )
}

# ----------------------------------------------------------------------------
# 2. Create external exact-site reference template
# ----------------------------------------------------------------------------
kinase_reference_path <- file.path(
  r6_input_dir,
  "kinase_substrate_reference_R6.csv"
)

if (!file.exists(kinase_reference_path)) {

  kinase_reference_template <- tibble(
    kinase = focus_kinases,
    substrate_gene = NA_character_,
    substrate_accession = NA_character_,
    residue = NA_character_,
    position = NA_integer_,
    evidence_level = NA_character_,
    evidence_type = NA_character_,
    source_database = NA_character_,
    source_reference = NA_character_,
    notes = NA_character_
  )

  write_csv(
    kinase_reference_template,
    kinase_reference_path
  )

  message(
    "已创建 kinase substrate reference 模板：\n",
    kinase_reference_path,
    "\n\n",
    "请优先填写“具体到位点”的 kinase-substrate relationship。\n",
    "一行 = 一个 kinase × substrate phosphosite。\n",
    "填好后重新运行 R6.0 即可完成主分析。"
  )
}

# ----------------------------------------------------------------------------
# 3. Helper functions
# ----------------------------------------------------------------------------
safe_fisher <- function(a, b, c, d) {

  if (
    any(is.na(c(a, b, c, d))) ||
      (a + b) == 0 ||
      (c + d) == 0
  ) {
    return(
      tibble(
        odds_ratio = NA_real_,
        conf_low = NA_real_,
        conf_high = NA_real_,
        p_value = NA_real_
      )
    )
  }

  ft <- fisher.test(
    matrix(
      c(a, b, c, d),
      nrow = 2,
      byrow = TRUE
    )
  )

  tibble(
    odds_ratio = unname(ft$estimate),
    conf_low = ft$conf.int[1],
    conf_high = ft$conf.int[2],
    p_value = ft$p.value
  )
}

safe_wilcox_less <- function(x, y) {

  x <- x[is.finite(x)]
  y <- y[is.finite(y)]

  if (
    length(x) < min_detected_substrates ||
      length(y) < 10
  ) {
    return(NA_real_)
  }

  tryCatch(
    wilcox.test(
      x,
      y,
      alternative = "less",
      exact = FALSE
    )$p.value,
    error = function(e) NA_real_
  )
}

safe_paired_wilcox <- function(x, y) {

  ok <- is.finite(x) & is.finite(y)

  x <- x[ok]
  y <- y[ok]

  if (length(x) < min_detected_substrates) {
    return(NA_real_)
  }

  tryCatch(
    wilcox.test(
      x,
      y,
      paired = TRUE,
      exact = FALSE
    )$p.value,
    error = function(e) NA_real_
  )
}

# ----------------------------------------------------------------------------
# 4. KSEA-like Z score
# ----------------------------------------------------------------------------
calculate_ksea_like <- function(
    matched_data,
    background_data,
    log2fc_col,
    dose,
    min_substrates = min_detected_substrates
) {

  log2fc_col <- rlang::ensym(log2fc_col)

  background_values <- background_data %>%
    distinct(site_id, .keep_all = TRUE) %>%
    pull(!!log2fc_col)

  background_values <- background_values[
    is.finite(background_values)
  ]

  bg_mean <- mean(background_values)
  bg_sd <- sd(background_values)

  matched_data %>%
    filter(
      is.finite(!!log2fc_col)
    ) %>%
    distinct(
      kinase,
      site_id,
      .keep_all = TRUE
    ) %>%
    group_by(kinase) %>%
    summarise(
      dose = dose,
      n_substrates = n(),
      substrate_mean = mean(
        !!log2fc_col,
        na.rm = TRUE
      ),
      substrate_median = median(
        !!log2fc_col,
        na.rm = TRUE
      ),
      background_mean = bg_mean,
      background_sd = bg_sd,
      ksea_like_z = if_else(
        n_substrates >= min_substrates &
          is.finite(bg_sd) &
          bg_sd > 0,
        (
          substrate_mean -
            bg_mean
        ) /
          (
            bg_sd /
              sqrt(n_substrates)
          ),
        NA_real_
      ),
      .groups = "drop"
    )
}

# ----------------------------------------------------------------------------
# 5. Empirical permutation test
#    one-sided decrease + two-sided p
# ----------------------------------------------------------------------------
calculate_kinase_permutation <- function(
    matched_data,
    background_data,
    log2fc_col,
    dose,
    n_perm = n_permutations,
    min_substrates = min_detected_substrates
) {

  log2fc_col <- rlang::ensym(log2fc_col)

  bg_tbl <- background_data %>%
    distinct(site_id, .keep_all = TRUE) %>%
    filter(
      is.finite(!!log2fc_col)
    )

  background_values <- bg_tbl %>%
    pull(!!log2fc_col)

  kinase_groups <- matched_data %>%
    filter(
      is.finite(!!log2fc_col)
    ) %>%
    distinct(
      kinase,
      site_id,
      .keep_all = TRUE
    ) %>%
    group_split(kinase)

  map_dfr(
    kinase_groups,
    function(sub) {

      kinase_name <- unique(sub$kinase)[1]

      observed_values <- sub %>%
        pull(!!log2fc_col)

      observed_values <- observed_values[
        is.finite(observed_values)
      ]

      n_sub <- length(observed_values)

      if (
        n_sub < min_substrates ||
          n_sub > length(background_values)
      ) {
        return(
          tibble(
            dose = dose,
            kinase = kinase_name,
            n_substrates = n_sub,
            observed_mean = ifelse(
              n_sub > 0,
              mean(observed_values),
              NA_real_
            ),
            permutation_p_decrease = NA_real_,
            permutation_p_two_sided = NA_real_
          )
        )
      }

      observed_mean <- mean(observed_values)

      null_means <- replicate(
        n_perm,
        mean(
          sample(
            background_values,
            size = n_sub,
            replace = FALSE
          )
        )
      )

      p_decrease <- (
        sum(
          null_means <= observed_mean
        ) +
          1
      ) /
        (
          n_perm +
            1
        )

      centered_observed <-
        observed_mean -
        mean(background_values)

      centered_null <-
        null_means -
        mean(background_values)

      p_two <- (
        sum(
          abs(centered_null) >=
            abs(centered_observed)
        ) +
          1
      ) /
        (
          n_perm +
            1
        )

      tibble(
        dose = dose,
        kinase = kinase_name,
        n_substrates = n_sub,
        observed_mean = observed_mean,
        background_mean = mean(background_values),
        mean_shift = observed_mean -
          mean(background_values),
        permutation_p_decrease = p_decrease,
        permutation_p_two_sided = p_two
      )
    }
  ) %>%
    group_by(dose) %>%
    mutate(
      permutation_fdr_decrease = p.adjust(
        permutation_p_decrease,
        method = "BH"
      ),
      permutation_fdr_two_sided = p.adjust(
        permutation_p_two_sided,
        method = "BH"
      )
    ) %>%
    ungroup()
}

# ----------------------------------------------------------------------------
# 6. Continuous substrate-set distribution test
# ----------------------------------------------------------------------------
calculate_continuous_kinase_shift <- function(
    matched_data,
    background_data,
    log2fc_col,
    dose
) {

  log2fc_col <- rlang::ensym(log2fc_col)

  bg <- background_data %>%
    distinct(site_id, .keep_all = TRUE) %>%
    filter(
      is.finite(!!log2fc_col)
    )

  matched_data %>%
    filter(
      is.finite(!!log2fc_col)
    ) %>%
    distinct(
      kinase,
      site_id,
      .keep_all = TRUE
    ) %>%
    group_by(kinase) %>%
    group_modify(
      ~ {
        kinase_values <- .x %>%
          pull(!!log2fc_col)

        kinase_site_ids <- .x$site_id

        comparison_values <- bg %>%
          filter(
            !site_id %in% kinase_site_ids
          ) %>%
          pull(!!log2fc_col)

        tibble(
          dose = dose,
          n_substrates = length(kinase_values),
          substrate_median =
            median(
              kinase_values,
              na.rm = TRUE
            ),
          substrate_mean =
            mean(
              kinase_values,
              na.rm = TRUE
            ),
          background_median =
            median(
              comparison_values,
              na.rm = TRUE
            ),
          median_shift =
            median(
              kinase_values,
              na.rm = TRUE
            ) -
              median(
                comparison_values,
                na.rm = TRUE
              ),
          wilcox_p_decrease =
            safe_wilcox_less(
              kinase_values,
              comparison_values
            )
        )
      }
    ) %>%
    ungroup() %>%
    group_by(dose) %>%
    mutate(
      wilcox_fdr_decrease =
        p.adjust(
          wilcox_p_decrease,
          method = "BH"
        )
    ) %>%
    ungroup()
}

# ----------------------------------------------------------------------------
# 7. Threshold-sensitive Fisher enrichment
# ----------------------------------------------------------------------------
calculate_threshold_kinase_fisher <- function(
    matched_data,
    background_data,
    dose,
    log2fc_col,
    p_col
) {

  log2fc_col <- rlang::ensym(log2fc_col)
  p_col <- rlang::ensym(p_col)

  background_data <- background_data %>%
    distinct(site_id, .keep_all = TRUE)

  background_ids <- background_data$site_id

  matched_in_background <- matched_data %>%
    filter(
      site_id %in% background_ids
    ) %>%
    distinct(
      kinase,
      site_id
    )

  map_dfr(
    thresholds,
    function(cutoff) {

      foreground_ids <- background_data %>%
        filter(
          !is.na(!!p_col),
          !!p_col < foreground_p_cutoff,
          !is.na(!!log2fc_col),
          !!log2fc_col < cutoff
        ) %>%
        pull(site_id) %>%
        unique()

      map_dfr(
        focus_kinases,
        function(k) {

          target_ids <- matched_in_background %>%
            filter(
              kinase == k
            ) %>%
            pull(site_id) %>%
            unique()

          a <- length(
            intersect(
              foreground_ids,
              target_ids
            )
          )

          b <- length(
            setdiff(
              foreground_ids,
              target_ids
            )
          )

          non_fg <- setdiff(
            background_ids,
            foreground_ids
          )

          c <- length(
            intersect(
              non_fg,
              target_ids
            )
          )

          d <- length(
            setdiff(
              non_fg,
              target_ids
            )
          )

          ft <- safe_fisher(
            a,
            b,
            c,
            d
          )

          bind_cols(
            tibble(
              dose = dose,
              log2fc_cutoff = cutoff,
              kinase = k,
              foreground_target = a,
              foreground_other = b,
              background_nonforeground_target = c,
              background_nonforeground_other = d,
              foreground_total = a + b,
              kinase_sites_in_background =
                length(target_ids)
            ),
            ft
          )
        }
      )
    }
  ) %>%
    group_by(
      dose,
      log2fc_cutoff
    ) %>%
    mutate(
      p_adjust = p.adjust(
        p_value,
        method = "BH"
      )
    ) %>%
    ungroup()
}

# ----------------------------------------------------------------------------
# 8. Build CDK4/6 union set
# ----------------------------------------------------------------------------
add_cdk46_union <- function(
    matched_data
) {

  cdk46_union <- matched_data %>%
    filter(
      kinase %in% c(
        "CDK4",
        "CDK6"
      )
    ) %>%
    mutate(
      kinase = "CDK4_6"
    ) %>%
    distinct(
      kinase,
      site_id,
      .keep_all = TRUE
    )

  bind_rows(
    matched_data,
    cdk46_union
  )
}

# ----------------------------------------------------------------------------
# 9. Load kinase reference
# ----------------------------------------------------------------------------
kinase_reference <- read_csv(
  kinase_reference_path,
  show_col_types = FALSE
) %>%
  mutate(
    kinase =
      standardize_kinase_name(
        kinase
      ),
    substrate_gene =
      str_trim(
        as.character(
          substrate_gene
        )
      ),
    substrate_accession =
      str_trim(
        as.character(
          substrate_accession
        )
      ),
    residue =
      str_to_upper(
        str_trim(
          as.character(
            residue
          )
        )
      ),
    position =
      suppressWarnings(
        as.integer(
          position
        )
      ),
    evidence_level =
      as.character(
        evidence_level
      ),
    reference_site_id =
      paste(
        substrate_accession,
        position,
        residue,
        sep = "_"
      )
  ) %>%
  filter(
    kinase %in% c(
      focus_kinases,
      "CDK4_6"
    ),
    !is.na(substrate_accession),
    substrate_accession != "",
    !is.na(position),
    !is.na(residue),
    residue %in% c(
      "S",
      "T",
      "Y"
    )
  ) %>%
  distinct(
    kinase,
    reference_site_id,
    .keep_all = TRUE
  )

# ----------------------------------------------------------------------------
# 10. If reference is still empty, stop gracefully
# ----------------------------------------------------------------------------
if (nrow(kinase_reference) == 0) {

  message(
    "\n============================================================\n",
    "R6.0 reference template 已建立，但还没有有效 kinase-substrate phosphosite。\n",
    "请填写：\n",
    kinase_reference_path,
    "\n然后重新运行本脚本。\n\n",
    "主分析必须使用具体 phosphosite 关系，",
    "不建议仅凭 SP/TP motif 区分 CDK4/6 与 CDK1。\n",
    "============================================================\n"
  )

} else {

  # --------------------------------------------------------------------------
  # 11. Exact site matching
  # --------------------------------------------------------------------------
  kinase_site_matches <- site_data %>%
    inner_join(
      kinase_reference,
      by = c(
        "protein_accession_clean" =
          "substrate_accession",
        "Position" =
          "position",
        "Amino acid" =
          "residue"
      )
    ) %>%
    distinct(
      kinase,
      site_id,
      .keep_all = TRUE
    )

  kinase_site_matches_all <- add_cdk46_union(
    kinase_site_matches
  )

  kinase_reference_all <- add_cdk46_union(
    kinase_reference %>%
      mutate(
        site_id = reference_site_id
      )
  ) %>%
    mutate(
      reference_site_id = if_else(
        is.na(reference_site_id),
        site_id,
        reference_site_id
      )
    )

  # --------------------------------------------------------------------------
  # 12. Detection coverage
  # --------------------------------------------------------------------------
  reference_counts <- kinase_reference_all %>%
    distinct(
      kinase,
      reference_site_id
    ) %>%
    count(
      kinase,
      name = "n_reference_sites"
    )

  matched_counts <- kinase_site_matches_all %>%
    distinct(
      kinase,
      site_id
    ) %>%
    count(
      kinase,
      name = "n_detected_sites"
    )

  kinase_detection_summary <- reference_counts %>%
    full_join(
      matched_counts,
      by = "kinase"
    ) %>%
    mutate(
      n_reference_sites =
        replace_na(
          n_reference_sites,
          0L
        ),
      n_detected_sites =
        replace_na(
          n_detected_sites,
          0L
        ),
      detection_fraction =
        if_else(
          n_reference_sites > 0,
          n_detected_sites /
            n_reference_sites,
          NA_real_
        ),
      enough_for_primary =
        n_detected_sites >=
          min_detected_substrates
    ) %>%
    arrange(
      match(
        kinase,
        c(
          "CDK4_6",
          focus_kinases
        )
      )
    )

  # --------------------------------------------------------------------------
  # 13. Continuous distribution / KSEA / permutation
  # --------------------------------------------------------------------------
  ksea_like_results <- bind_rows(
    calculate_ksea_like(
      kinase_site_matches_all,
      pal1_background,
      Pal1_log2FC,
      "Pal1"
    ),
    calculate_ksea_like(
      kinase_site_matches_all,
      pal5_background,
      Pal5_log2FC,
      "Pal5"
    )
  )

  permutation_results <- bind_rows(
    calculate_kinase_permutation(
      kinase_site_matches_all,
      pal1_background,
      Pal1_log2FC,
      "Pal1"
    ),
    calculate_kinase_permutation(
      kinase_site_matches_all,
      pal5_background,
      Pal5_log2FC,
      "Pal5"
    )
  )

  continuous_shift_results <- bind_rows(
    calculate_continuous_kinase_shift(
      kinase_site_matches_all,
      pal1_background,
      Pal1_log2FC,
      "Pal1"
    ),
    calculate_continuous_kinase_shift(
      kinase_site_matches_all,
      pal5_background,
      Pal5_log2FC,
      "Pal5"
    )
  )

  # --------------------------------------------------------------------------
  # 14. Threshold robustness
  # --------------------------------------------------------------------------
  threshold_fisher_results <- bind_rows(
    calculate_threshold_kinase_fisher(
      kinase_site_matches,
      pal1_background,
      "Pal1",
      Pal1_log2FC,
      `Pal1/Con P value`
    ),
    calculate_threshold_kinase_fisher(
      kinase_site_matches,
      pal5_background,
      "Pal5",
      Pal5_log2FC,
      `Pal5/Con P value`
    )
  )

  # CDK4/6 union Fisher separately
  threshold_fisher_cdk46 <- bind_rows(
    calculate_threshold_kinase_fisher(
      kinase_site_matches_all %>%
        filter(
          kinase == "CDK4_6"
        ),
      pal1_background,
      "Pal1",
      Pal1_log2FC,
      `Pal1/Con P value`
    ),
    calculate_threshold_kinase_fisher(
      kinase_site_matches_all %>%
        filter(
          kinase == "CDK4_6"
        ),
      pal5_background,
      "Pal5",
      Pal5_log2FC,
      `Pal5/Con P value`
    )
  ) %>%
    filter(
      kinase == "CDK4"
    ) %>%
    mutate(
      kinase = "CDK4_6"
    )

  # 上面 generic helper 固定遍历 focus_kinases，因此更安全地直接单独计算 union：
  calculate_union_fisher <- function(
      matched_union,
      background_data,
      dose,
      log2fc_col,
      p_col
  ) {

    log2fc_col <- rlang::ensym(log2fc_col)
    p_col <- rlang::ensym(p_col)

    bg <- background_data %>%
      distinct(site_id, .keep_all = TRUE)

    bg_ids <- unique(bg$site_id)

    target_ids <- matched_union %>%
      filter(
        site_id %in% bg_ids
      ) %>%
      pull(site_id) %>%
      unique()

    map_dfr(
      thresholds,
      function(cutoff) {

        fg_ids <- bg %>%
          filter(
            !is.na(!!p_col),
            !!p_col <
              foreground_p_cutoff,
            !is.na(!!log2fc_col),
            !!log2fc_col <
              cutoff
          ) %>%
          pull(site_id) %>%
          unique()

        non_fg <- setdiff(
          bg_ids,
          fg_ids
        )

        a <- length(
          intersect(
            fg_ids,
            target_ids
          )
        )

        b <- length(
          setdiff(
            fg_ids,
            target_ids
          )
        )

        c <- length(
          intersect(
            non_fg,
            target_ids
          )
        )

        d <- length(
          setdiff(
            non_fg,
            target_ids
          )
        )

        bind_cols(
          tibble(
            dose = dose,
            log2fc_cutoff = cutoff,
            kinase = "CDK4_6",
            foreground_target = a,
            foreground_other = b,
            background_nonforeground_target = c,
            background_nonforeground_other = d,
            foreground_total = a + b,
            kinase_sites_in_background =
              length(target_ids)
          ),
          safe_fisher(
            a,
            b,
            c,
            d
          )
        )
      }
    )
  }

  threshold_fisher_union <- bind_rows(
    calculate_union_fisher(
      kinase_site_matches_all %>%
        filter(
          kinase == "CDK4_6"
        ),
      pal1_background,
      "Pal1",
      Pal1_log2FC,
      `Pal1/Con P value`
    ),
    calculate_union_fisher(
      kinase_site_matches_all %>%
        filter(
          kinase == "CDK4_6"
        ),
      pal5_background,
      "Pal5",
      Pal5_log2FC,
      `Pal5/Con P value`
    )
  )

  threshold_fisher_results <- bind_rows(
    threshold_fisher_results,
    threshold_fisher_union
  ) %>%
    group_by(
      dose,
      log2fc_cutoff
    ) %>%
    mutate(
      p_adjust_all_kinases =
        p.adjust(
          p_value,
          method = "BH"
        )
    ) %>%
    ungroup()

  threshold_stability <- threshold_fisher_results %>%
    group_by(
      dose,
      kinase
    ) %>%
    summarise(
      thresholds_tested =
        sum(
          !is.na(
            odds_ratio
          )
        ),
      thresholds_OR_gt1 =
        sum(
          odds_ratio > 1,
          na.rm = TRUE
        ),
      thresholds_FDR_lt_005 =
        sum(
          p_adjust_all_kinases <
            0.05,
          na.rm = TRUE
        ),
      thresholds_FDR_lt_020 =
        sum(
          p_adjust_all_kinases <
            0.20,
          na.rm = TRUE
        ),
      median_OR =
        median(
          odds_ratio,
          na.rm = TRUE
        ),
      best_FDR =
        min(
          p_adjust_all_kinases,
          na.rm = TRUE
        ),
      .groups = "drop"
    )

  # --------------------------------------------------------------------------
  # 15. Pal1 vs Pal5 dose behavior of exact kinase substrates
  # --------------------------------------------------------------------------
  kinase_dose_shift <- kinase_site_matches_all %>%
    filter(
      is.finite(
        Pal1_log2FC
      ),
      is.finite(
        Pal5_log2FC
      )
    ) %>%
    distinct(
      kinase,
      site_id,
      .keep_all = TRUE
    ) %>%
    mutate(
      delta_Pal5_minus_Pal1 =
        Pal5_log2FC -
        Pal1_log2FC
    ) %>%
    group_by(
      kinase
    ) %>%
    summarise(
      n_paired_sites = n(),
      median_Pal1 =
        median(
          Pal1_log2FC,
          na.rm = TRUE
        ),
      median_Pal5 =
        median(
          Pal5_log2FC,
          na.rm = TRUE
        ),
      median_delta =
        median(
          delta_Pal5_minus_Pal1,
          na.rm = TRUE
        ),
      fraction_more_negative_at_Pal5 =
        mean(
          delta_Pal5_minus_Pal1 < 0,
          na.rm = TRUE
        ),
      paired_wilcox_p =
        safe_paired_wilcox(
          Pal5_log2FC,
          Pal1_log2FC
        ),
      .groups = "drop"
    ) %>%
    mutate(
      paired_wilcox_fdr =
        p.adjust(
          paired_wilcox_p,
          method = "BH"
        )
    )

  # --------------------------------------------------------------------------
  # 16. Integrated kinase summary
  # --------------------------------------------------------------------------
  kinase_integrated_summary <- ksea_like_results %>%
    select(
      dose,
      kinase,
      n_substrates,
      substrate_mean,
      substrate_median,
      ksea_like_z
    ) %>%
    left_join(
      continuous_shift_results %>%
        select(
          dose,
          kinase,
          median_shift,
          wilcox_p_decrease,
          wilcox_fdr_decrease
        ),
      by = c(
        "dose",
        "kinase"
      )
    ) %>%
    left_join(
      permutation_results %>%
        select(
          dose,
          kinase,
          mean_shift,
          permutation_p_decrease,
          permutation_fdr_decrease,
          permutation_p_two_sided,
          permutation_fdr_two_sided
        ),
      by = c(
        "dose",
        "kinase"
      )
    ) %>%
    left_join(
      threshold_stability,
      by = c(
        "dose",
        "kinase"
      )
    ) %>%
    mutate(
      negative_ksea =
        !is.na(
          ksea_like_z
        ) &
          ksea_like_z < 0,

      continuous_support =
        !is.na(
          wilcox_fdr_decrease
        ) &
          wilcox_fdr_decrease <
            0.20,

      permutation_support =
        !is.na(
          permutation_fdr_decrease
        ) &
          permutation_fdr_decrease <
            0.20,

      threshold_support =
        thresholds_FDR_lt_020 >
          0,

      evidence_layers_supported =
        rowSums(
          cbind(
            negative_ksea,
            continuous_support,
            permutation_support,
            threshold_support
          ),
          na.rm = TRUE
        ),

      interpretation_class =
        case_when(
          n_substrates <
            min_detected_substrates ~
            "Insufficient detected substrates",

          evidence_layers_supported >=
            3 ~
            "Multi-layer support for decreased substrate phosphorylation",

          evidence_layers_supported ==
            2 ~
            "Moderate support",

          evidence_layers_supported ==
            1 ~
            "Weak / exploratory support",

          TRUE ~
            "No clear decrease signature"
        )
    ) %>%
    arrange(
      dose,
      desc(
        evidence_layers_supported
      ),
      ksea_like_z
    )

  # --------------------------------------------------------------------------
  # 17. CDK4/6 versus alternative mitotic kinase comparison
  # --------------------------------------------------------------------------
  kinase_competition <- kinase_integrated_summary %>%
    filter(
      kinase %in% c(
        "CDK4_6",
        focus_kinases
      )
    ) %>%
    group_by(
      dose
    ) %>%
    mutate(
      rank_by_ksea_decrease =
        rank(
          ksea_like_z,
          ties.method = "min",
          na.last = "keep"
        ),
      rank_by_median_shift =
        rank(
          median_shift,
          ties.method = "min",
          na.last = "keep"
        )
    ) %>%
    ungroup()

  # --------------------------------------------------------------------------
  # 18. Exact matched sites priority table
  # --------------------------------------------------------------------------
  matched_site_priority <- kinase_site_matches_all %>%
    transmute(
      kinase,
      substrate_gene,
      substrate_accession =
        protein_accession_clean,
      residue =
        `Amino acid`,
      position =
        Position,
      site_id,
      evidence_level,
      evidence_type,
      source_database,
      source_reference,
      motif_type,
      motif_sequence_15mer,
      localization_probability =
        `Localization probability`,
      Pal1_log2FC,
      Pal1_p_value =
        `Pal1/Con P value`,
      Pal5_log2FC,
      Pal5_p_value =
        `Pal5/Con P value`,
      delta_Pal5_minus_Pal1 =
        Pal5_log2FC -
        Pal1_log2FC,
      down_both =
        `Pal1/Con P value` <
          0.05 &
          Pal1_log2FC < 0 &
          `Pal5/Con P value` <
          0.05 &
          Pal5_log2FC < 0
    ) %>%
    arrange(
      kinase,
      Pal5_log2FC
    )

  # --------------------------------------------------------------------------
  # 19. Plots
  # --------------------------------------------------------------------------
  plot_order <- c(
    "CDK4_6",
    "CDK4",
    "CDK6",
    "CDK1",
    "AURKA",
    "AURKB",
    "PLK1",
    "TTK"
  )

  kinase_plot_df <- kinase_integrated_summary %>%
    filter(
      kinase %in%
        plot_order,
      !is.na(
        ksea_like_z
      )
    ) %>%
    mutate(
      kinase =
        factor(
          kinase,
          levels =
            plot_order
        )
    )

  p_ksea <- ggplot(
    kinase_plot_df,
    aes(
      x = kinase,
      y = ksea_like_z,
      shape = dose
    )
  ) +
    geom_hline(
      yintercept = 0,
      linetype = 2
    ) +
    geom_point(
      size = 3
    ) +
    labs(
      title =
        "Kinase substrate-set phosphorylation signatures",
      subtitle =
        "More negative KSEA-like Z = stronger downward substrate shift",
      x = NULL,
      y = "KSEA-like Z score"
    ) +
    theme_bw() +
    theme(
      axis.text.x =
        element_text(
          angle = 45,
          hjust = 1
        )
    )

  ggsave(
    file.path(
      r6_figure_dir,
      "01_kinase_KSEA_like_scores.png"
    ),
    p_ksea,
    width = 9,
    height = 6.5,
    dpi = 300
  )

  p_median <- kinase_integrated_summary %>%
    filter(
      kinase %in%
        plot_order
    ) %>%
    mutate(
      kinase =
        factor(
          kinase,
          levels =
            plot_order
        )
    ) %>%
    ggplot(
      aes(
        x = kinase,
        y = median_shift,
        shape = dose
      )
    ) +
    geom_hline(
      yintercept = 0,
      linetype = 2
    ) +
    geom_point(
      size = 3
    ) +
    labs(
      title =
        "Continuous kinase-substrate log2FC shift",
      subtitle =
        "Negative values indicate substrates are shifted below the quantified background",
      x = NULL,
      y =
        "Substrate median - background median"
    ) +
    theme_bw() +
    theme(
      axis.text.x =
        element_text(
          angle = 45,
          hjust = 1
        )
    )

  ggsave(
    file.path(
      r6_figure_dir,
      "02_kinase_continuous_median_shift.png"
    ),
    p_median,
    width = 9,
    height = 6.5,
    dpi = 300
  )

  threshold_plot_df <-
    threshold_fisher_results %>%
    filter(
      kinase %in%
        plot_order,
      is.finite(
        odds_ratio
      ),
      odds_ratio > 0
    ) %>%
    mutate(
      kinase =
        factor(
          kinase,
          levels =
            plot_order
        ),
      cutoff_label =
        paste0(
          "log2FC < ",
          log2fc_cutoff
        )
    )

  p_threshold <- ggplot(
    threshold_plot_df,
    aes(
      x = odds_ratio,
      y = kinase,
      shape = cutoff_label
    )
  ) +
    geom_vline(
      xintercept = 1,
      linetype = 2
    ) +
    geom_point(
      size = 2.5
    ) +
    scale_x_log10() +
    facet_wrap(
      ~ dose
    ) +
    labs(
      title =
        "Kinase substrate enrichment across foreground thresholds",
      x =
        "Odds ratio (log10 scale)",
      y = NULL,
      shape =
        "Foreground"
    ) +
    theme_bw()

  ggsave(
    file.path(
      r6_figure_dir,
      "03_kinase_threshold_Fisher_OR.png"
    ),
    p_threshold,
    width = 11,
    height = 7,
    dpi = 300
  )

  # --------------------------------------------------------------------------
  # 20. Output workbook
  # --------------------------------------------------------------------------
  write.xlsx(
    list(
      Kinase_reference =
        kinase_reference_all,

      Detection_summary =
        kinase_detection_summary,

      Exact_matched_sites =
        matched_site_priority,

      Integrated_summary =
        kinase_integrated_summary,

      Kinase_competition =
        kinase_competition,

      KSEA_like_score =
        ksea_like_results,

      Continuous_shift =
        continuous_shift_results,

      Permutation_test =
        permutation_results,

      Threshold_Fisher =
        threshold_fisher_results,

      Threshold_stability =
        threshold_stability,

      Dose_shift =
        kinase_dose_shift
    ),
    file = file.path(
      r6_table_dir,
      "01_R6_kinase_signature_analysis.xlsx"
    ),
    overwrite = TRUE
  )

  write_csv(
    matched_site_priority,
    file.path(
      r6_table_dir,
      "02_R6_exact_kinase_substrate_matches.csv"
    )
  )

  write_csv(
    kinase_integrated_summary,
    file.path(
      r6_table_dir,
      "03_R6_kinase_integrated_summary.csv"
    )
  )

  message(
    "\n============================================================\n",
    "R6.0 kinase-signature analysis completed.\n",
    "主要输出：\n",
    "1) tables/01_R6_kinase_signature_analysis.xlsx\n",
    "2) tables/02_R6_exact_kinase_substrate_matches.csv\n",
    "3) tables/03_R6_kinase_integrated_summary.csv\n",
    "\n优先查看：\n",
    "- Detection_summary\n",
    "- Integrated_summary\n",
    "- Kinase_competition\n",
    "- Threshold_stability\n",
    "- Dose_shift\n",
    "\nInterpretation principle:\n",
    "不要只依据某一种统计方法归因 kinase；\n",
    "优先寻找 continuous + permutation + threshold robustness 的一致证据。\n",
    "============================================================\n"
  )
}
