# Central configuration for the R2.0-R10 phosphoproteomics workflow.

# R may start in the "C" locale on Windows, which cannot translate Chinese
# paths or comments. Prefer a UTF-8 locale while keeping a harmless fallback.
try(suppressWarnings(Sys.setlocale("LC_CTYPE", ".UTF-8")), silent = TRUE)

project_root <- normalizePath(
  Sys.getenv("PHOSPHO_PROJECT_ROOT", unset = getwd()),
  winslash = "/",
  mustWork = TRUE
)

input_xlsx <- Sys.getenv(
  "PHOSPHO_INPUT_XLSX",
  unset = file.path(project_root, "input", "raw", "MS_identified_information.xlsx")
)
fasta_path_config <- Sys.getenv(
  "PHOSPHO_FASTA",
  unset = file.path(project_root, "input", "reference", "Homo_sapiens_9606_SP_20230103.fasta")
)
kinase_reference_config <- file.path(
  project_root, "input", "reference", "kinase_substrate_reference_R6.csv"
)
cdk46_annotation_config <- file.path(
  project_root, "input", "reference", "known_CDK46_site_priority_annotations.csv"
)

stopifnot(
  file.exists(input_xlsx),
  file.exists(fasta_path_config),
  file.exists(kinase_reference_config)
)

Sys.setenv(
  PHOSPHO_PROJECT_ROOT = project_root,
  PHOSPHO_INPUT_XLSX = input_xlsx,
  PHOSPHO_FASTA = fasta_path_config
)

dir.create(file.path(project_root, "results"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(project_root, "cache"), recursive = TRUE, showWarnings = FALSE)

options(stringsAsFactors = FALSE)
set.seed(20260823)
