# R2.0-R12 code map

This code folder is self-contained: `scripts/` and `input/` are siblings under
`04_Code_and_Reproducibility`. Open a terminal in that folder before running
the commands below.

Run the R2.0-R10 pipeline with the `Rscript` installed on the workstation:

```powershell
Rscript scripts\00_run_pipeline.R
```

Then run the final adjusted analysis and publication figures:

```powershell
Rscript scripts\12_R12_adjusted_pathways_and_firth.R
Rscript scripts\14_manuscript_figures.R
```

MoMo is a separate WSL/Linux step because it requires MEME Suite. After R4
has generated the foreground/background files, run:

```bash
bash scripts/04b_run_momo_motifx_wsl.sh
python scripts/04c_summarize_momo_outputs.py
```

The R2.0-R10 runner fixes the random seed, uses the frozen kinase-substrate
reference by default, records `sessionInfo()`, and executes those scripts in
numerical order. R12, MoMo, and the figure builder remain explicit separate
steps. Raw input paths can be overridden with the environment variables
documented in `00_config.R`.

| Step | Script | Main analytical purpose | Principal outputs |
|---|---|---|---|
| Configuration | `00_config.R` | Portable project paths, seed, raw workbook/FASTA locations | Shared objects and paths |
| Runner | `00_run_pipeline.R` | End-to-end execution and session recording | `results/sessionInfo_R2_R10.txt` |
| R2.0 | `01_R2_0_data_preparation.R` | Import, clean, site identifiers, FASTA validation, 15-mer motifs, log2FC/rank scores | Preprocessed RDS and QC tables |
| R2.1 | `02_R2_1_global_pathway_and_targeted_analysis.R` | Background-controlled motif tests, GO/Reactome ORA, ranked GSEA, targeted sets, candidates | Global/targeted workbooks and candidate table |
| R3 | `03_R3_threshold_sensitivity.R` | Four downregulation thresholds and cutoff-independent analyses | Threshold and stability workbooks |
| R4 | `04_R4_missingness_and_MoMo_inputs.R` | Detection/missingness sensitivity and MoMo input construction | Missingness workbook, MoMo manifest/QC |
| R4-MoMo | `04b_run_momo_motifx_wsl.sh` | Run native MoMo motif-x discovery for Pal1/Pal5, four thresholds, and S/T centers | Sixteen complete MoMo result folders |
| R4-MoMo summary | `04c_summarize_momo_outputs.py` | Parse native outputs and build publication tables, logos, and reproducibility figures | MoMo CSV tables and PNG figures |
| R5 | `05_R5_motif_and_dose_response.R` | Motif class responses and Pal1-to-Pal5 dose shifts | Motif/dose-response workbook |
| R6a | `06a_R6_build_kinase_reference.R` | Optional refresh of external kinase reference | Frozen kinase reference CSV |
| R6b | `06b_R6_kinase_signature.R` | Exact-site kinase matching, continuous/threshold/permutation tests | Kinase-signature workbook |
| R7 | `07_R7_CDK46_and_RB1_validation.R` | Curated CDK4/6 reference and RB1 site-level validation | CDK4/6/RB1 workbook |
| R8 | `08_R8_PLK1_sensitivity.R` | PLK1 dose response and exact-site exclusion analyses | PLK1 sensitivity workbook |
| R9 | `09_R9_SF_vs_PLK1.R` | SF enrichment within PLK1 sites and exclusion robustness | SF-vs-PLK1 workbook |
| R10 | `10_R10_site_count_bias_control.R` | Matched permutations and regressions adjusting quantified-site count | Site-count-bias workbook |
| R12 | `12_R12_adjusted_pathways_and_firth.R` | Full-family adjusted GO/Reactome models and Firth RZZ/SAC models | Final adjusted-analysis workbook |
| Figures | `14_manuscript_figures.R` | Consistent publication graphics and exact source-data exports | PDF/SVG/PNG figures and CSVs |

## Reproducibility notes

- The raw phosphoproteomics workbook and FASTA file are copied into `input/` for a self-contained handoff.
- Manuscript figure/table builders read the fully rerun frozen result workbooks under `input/frozen_results/`.
- The frozen kinase reference is the default because rebuilding it requires a live external source and could change over time.
- Manual pathway definitions and the CDK4/6 annotation are versioned under `input/reference/`.
- R4 MoMo discovery is complete in the delivered results folder: all 16 planned Pal1/Pal5 × threshold × S/T runs have native HTML/TSV/TXT outputs. A rerun writes new native outputs under this code folder's `results/R4_missingness_and_MoMo/` directory.
- Full pathway tables remain in `results/`; the manuscript workbook contains only publication-sized summaries.

## Software requirements

- R 4.4.x with the packages loaded by the numbered scripts, including Bioconductor annotation packages and `logistf` for R12.
- Python 3 with pandas, matplotlib, scipy, and logomaker-compatible plotting dependencies for the MoMo summary step.
- WSL/Linux plus MEME Suite MoMo 5.5.7 (or a compatible release) for native motif-x discovery.
- Set `MOMO_BIN` if `momo` is not available on `PATH`; set `MEME_RUNTIME_LIB` only when a custom MEME runtime library directory is required.
