library(readxl)
library(dplyr)
library(stringr)
library(tidyr)
library(ggplot2)
library(purrr)
library(tibble)
library(Biostrings)

# Portable project paths. When sourced by 00_run_pipeline.R, project_root is
# already defined. The environment variables allow explicit overrides.
if (!exists("project_root", inherits = TRUE)) {
  project_root <- normalizePath(getwd(), winslash = "/", mustWork = TRUE)
}
file_path <- Sys.getenv(
  "PHOSPHO_INPUT_XLSX",
  unset = file.path(project_root, "input", "raw", "MS_identified_information.xlsx")
)
if (!file.exists(file_path)) stop("Input workbook not found: ", file_path)

site_data <- read_excel(
  path = file_path,
  sheet = "Site_quant",
  .name_repair = "unique"
)

dim(site_data)
head(site_data)
site_data <- site_data %>%
  mutate(
    Position = as.numeric(Position),
    `Localization probability` = as.numeric(`Localization probability`),
    
    `Pal1/Con Ratio` = as.numeric(`Pal1/Con Ratio`),
    `Pal1/Con P value` = as.numeric(`Pal1/Con P value`),
    
    `Pal5/Con Ratio` = as.numeric(`Pal5/Con Ratio`),
    `Pal5/Con P value` = as.numeric(`Pal5/Con P value`)
  )
site_data <- site_data %>%
  mutate(
    Pal1_log2FC = log2(`Pal1/Con Ratio`),
    Pal5_log2FC = log2(`Pal5/Con Ratio`)
  )
site_data <- site_data %>%
  mutate(
    Pal1_rank_score =
      sign(Pal1_log2FC) * -log10(`Pal1/Con P value`),
    
    Pal5_rank_score =
      sign(Pal5_log2FC) * -log10(`Pal5/Con P value`)
  )
site_data <- site_data %>%
  mutate(
    Pal1_status = case_when(
      `Pal1/Con P value` < 0.05 & Pal1_log2FC < 0 ~ "Down",
      `Pal1/Con P value` < 0.05 & Pal1_log2FC > 0 ~ "Up",
      TRUE ~ "Not_significant"
    ),
    
    Pal5_status = case_when(
      `Pal5/Con P value` < 0.05 & Pal5_log2FC < 0 ~ "Down",
      `Pal5/Con P value` < 0.05 & Pal5_log2FC > 0 ~ "Up",
      TRUE ~ "Not_significant"
    )
  )
table(site_data$Pal1_status, useNA = "ifany")
table(site_data$Pal5_status, useNA = "ifany")
background_sites <- site_data %>%
  filter(
    !is.na(`Modified sequence`),
    !is.na(`Amino acid`)
  )
pal1_down_sites <- site_data %>%
  filter(
    Pal1_status == "Down",
    !is.na(`Modified sequence`)
  )
pal5_down_sites <- site_data %>%
  filter(
    Pal5_status == "Down",
    !is.na(`Modified sequence`)
  )
head(
  site_data %>%
    select(
      `Gene name`,
      Position,
      `Amino acid`,
      `Modified sequence`,
      `Localization probability`
    ),
  20
)
site_data <- site_data %>%
  mutate(
    site_id = paste(
      `Protein accession`,
      Position,
      `Amino acid`,
      sep = "_"
    ),
    
    phospho_count_in_peptide = str_count(
      `Modified sequence`,
      fixed("[Phospho (STY)]")
    )
  )

table(
  site_data$phospho_count_in_peptide,
  useNA = "ifany"
)

site_data %>%
  summarise(
    total_rows = n(),
    single_phospho_rows =
      sum(phospho_count_in_peptide == 1, na.rm = TRUE),
    multi_phospho_rows =
      sum(phospho_count_in_peptide >= 2, na.rm = TRUE),
    multi_phospho_percentage =
      100 * multi_phospho_rows / total_rows
  )

site_data %>%
  filter(phospho_count_in_peptide >= 2) %>%
  select(
    `Protein accession`,
    Position,
    `Amino acid`,
    `Modified sequence`,
    phospho_count_in_peptide
  ) %>%
  head(20)



###导入fasta文件
fasta_path <- Sys.getenv(
  "PHOSPHO_FASTA",
  unset = file.path(project_root, "input", "reference", "Homo_sapiens_9606_SP_20230103.fasta")
)
if (!file.exists(fasta_path)) stop("FASTA file not found: ", fasta_path)
protein_fasta_raw <- readAAStringSet(fasta_path)
fasta_headers <- names(protein_fasta_raw)

fasta_accession <- str_extract(
  fasta_headers,
  "(?<=\\|)[^|]+(?=\\|)"
)
head(
  tibble(
    fasta_header = fasta_headers,
    fasta_accession = fasta_accession
  ),
  10
)
names(protein_fasta_raw) <- fasta_accession
protein_fasta <- protein_fasta_raw
####检查结果（覆盖率）
site_data <- site_data %>%
  mutate(
    protein_accession_clean =
      str_trim(`Protein accession`)
  )
site_data <- site_data %>%
  mutate(
    accession_found =
      protein_accession_clean %in%
      names(protein_fasta)
  )
site_data %>%
  summarise(
    total_site_rows = n(),
    matched_site_rows = sum(accession_found),
    unmatched_site_rows = sum(!accession_found),
    match_percentage =
      100 * mean(accession_found)
  )
site_data %>%
  distinct(protein_accession_clean) %>%
  mutate(
    accession_found =
      protein_accession_clean %in%
      names(protein_fasta)
  ) %>%
  summarise(
    total_proteins = n(),
    matched_proteins = sum(accession_found),
    unmatched_proteins = sum(!accession_found),
    match_percentage =
      100 * mean(accession_found)
  )
unmatched_accessions <- site_data %>%
  filter(!accession_found) %>%
  count(
    protein_accession_clean,
    sort = TRUE
  )

head(unmatched_accessions, 30)
#检查位置是否一致（可省略以后）
protein_lengths <- width(protein_fasta)
names(protein_lengths) <- names(protein_fasta)
site_data <- site_data %>%
  mutate(
    protein_length = if_else(
      accession_found,
      as.integer(protein_lengths[protein_accession_clean]),
      NA_integer_
    )
  )
site_data <- site_data %>%
  mutate(
    position_valid = case_when(
      !accession_found ~ FALSE,
      is.na(Position) ~ FALSE,
      Position < 1 ~ FALSE,
      Position > protein_length ~ FALSE,
      TRUE ~ TRUE
    )
  )
site_data %>%
  summarise(
    total_rows = n(),
    accession_matched = sum(accession_found),
    valid_positions = sum(position_valid),
    invalid_positions = sum(accession_found & !position_valid)
  )

#安全函数：
get_fasta_amino_acid <- function(accession, position, fasta) {
  
  if (
    is.na(accession) ||
    is.na(position) ||
    !accession %in% names(fasta)
  ) {
    return(NA_character_)
  }
  
  seq_string <- as.character(fasta[[accession]])
  
  if (
    position < 1 ||
    position > nchar(seq_string)
  ) {
    return(NA_character_)
  }
  
  substr(seq_string, position, position)
}
#批量提取+统计
site_data <- site_data %>%
  mutate(
    fasta_amino_acid = map2_chr(
      protein_accession_clean,
      Position,
      ~ get_fasta_amino_acid(
        accession = .x,
        position = .y,
        fasta = protein_fasta
      )
    )
  )
site_data <- site_data %>%
  mutate(
    fasta_amino_acid = map2_chr(
      protein_accession_clean,
      Position,
      ~ get_fasta_amino_acid(
        accession = .x,
        position = .y,
        fasta = protein_fasta
      )
    )
  )
site_data <- site_data %>%
  mutate(
    amino_acid_match =
      !is.na(fasta_amino_acid) &
      fasta_amino_acid == `Amino acid`
  )
site_data %>%
  summarise(
    total_rows = n(),
    accession_matched = sum(accession_found),
    valid_positions = sum(position_valid),
    amino_acid_matched = sum(amino_acid_match),
    amino_acid_mismatched =
      sum(position_valid & !amino_acid_match),
    final_match_percentage =
      100 * mean(amino_acid_match)
  )


##开始批量提取15
extract_site_window <- function(
    accession,
    position,
    amino_acid,
    fasta,
    flank = 7
) {
  
  if (
    is.na(accession) ||
    is.na(position) ||
    is.na(amino_acid) ||
    !accession %in% names(fasta)
  ) {
    return(NA_character_)
  }
  
  seq_string <- as.character(fasta[[accession]])
  seq_length <- nchar(seq_string)
  
  if (
    position < 1 ||
    position > seq_length
  ) {
    return(NA_character_)
  }
  
  center_aa <- substr(
    seq_string,
    position,
    position
  )
  
  if (center_aa != amino_acid) {
    return(NA_character_)
  }
  
  start_pos <- position - flank
  end_pos <- position + flank
  
  left_padding <- max(0, 1 - start_pos)
  right_padding <- max(0, end_pos - seq_length)
  
  real_start <- max(1, start_pos)
  real_end <- min(seq_length, end_pos)
  
  window_seq <- substr(
    seq_string,
    real_start,
    real_end
  )
  
  paste0(
    str_dup("X", left_padding),
    window_seq,
    str_dup("X", right_padding)
  )
}
site_data <- site_data %>%
  mutate(
    motif_sequence_15mer = pmap_chr(
      list(
        protein_accession_clean,
        Position,
        `Amino acid`
      ),
      ~ extract_site_window(
        accession = ..1,
        position = ..2,
        amino_acid = ..3,
        fasta = protein_fasta,
        flank = 7
      )
    )
  )
#验证15mer成果；
table(
  str_length(site_data$motif_sequence_15mer),
  useNA = "ifany"
)
site_data <- site_data %>%
  mutate(
    motif_center_aa =
      substr(motif_sequence_15mer, 8, 8)
  )
table(
  site_data$motif_center_aa,
  useNA = "ifany"
)
#检查中心是否与表格一致
site_data %>%
  summarise(
    extracted_sequences =
      sum(!is.na(motif_sequence_15mer)),
    
    center_matched =
      sum(
        motif_center_aa == `Amino acid`,
        na.rm = TRUE
      ),
    
    extraction_percentage =
      100 * mean(!is.na(motif_sequence_15mer))
  )
#导出下一位的氨基酸
site_data <- site_data %>%
  mutate(
    plus1_aa = substr(
      motif_sequence_15mer,
      9,
      9
    ),
    
    motif_type = case_when(
      motif_center_aa == "S" &
        plus1_aa == "P" ~ "SP",
      
      motif_center_aa == "T" &
        plus1_aa == "P" ~ "TP",
      
      motif_center_aa == "S" ~ "Other_S",
      
      motif_center_aa == "T" ~ "Other_T",
      
      motif_center_aa == "Y" ~ "Y",
      
      TRUE ~ NA_character_
    ),
    
    proline_directed =
      motif_type %in% c("SP", "TP")
  )
#看群体分布；
table(
  site_data$motif_type,
  useNA = "ifany"
)
#查看缺失位点
site_data %>%
  summarise(
    unmatched_total =
      sum(!accession_found),
    
    unmatched_pal1_down =
      sum(
        !accession_found &
          Pal1_status == "Down",
        na.rm = TRUE
      ),
    
    unmatched_pal5_down =
      sum(
        !accession_found &
          Pal5_status == "Down",
        na.rm = TRUE
      )
  )
table(
  site_data$motif_type,
  useNA = "ifany"
)


#Pal 1定量背景
pal1_background <- site_data %>%
  filter(
    !is.na(motif_sequence_15mer),
    
    motif_center_aa %in% c("S", "T"),
    
    !is.na(`Pal1/Con Ratio`),
    `Pal1/Con Ratio` > 0,
    
    !is.na(`Pal1/Con P value`),
    
    !is.na(Pal1_log2FC)
  ) %>%
  distinct(site_id, .keep_all = TRUE)
#Pal 5定量背景
pal5_background <- site_data %>%
  filter(
    !is.na(motif_sequence_15mer),
    
    motif_center_aa %in% c("S", "T"),
    
    !is.na(`Pal5/Con Ratio`),
    `Pal5/Con Ratio` > 0,
    
    !is.na(`Pal5/Con P value`),
    
    !is.na(Pal5_log2FC)
  ) %>%
  distinct(site_id, .keep_all = TRUE)
#背景规模
tibble(
  dataset = c(
    "Pal1 quantified S/T background",
    "Pal5 quantified S/T background"
  ),
  
  number_of_sites = c(
    nrow(pal1_background),
    nrow(pal5_background)
  )
)
#取前景
pal1_down <- pal1_background %>%
  filter(
    `Pal1/Con P value` < 0.05,
    Pal1_log2FC < 0
  )
pal5_down <- pal5_background %>%
  filter(
    `Pal5/Con P value` < 0.05,
    Pal5_log2FC < 0
  )
tibble(
  dose = c(
    "Palbociclib 1 µM",
    "Palbociclib 5 µM"
  ),
  
  quantified_ST_sites = c(
    nrow(pal1_background),
    nrow(pal5_background)
  ),
  
  significantly_downregulated_ST_sites = c(
    nrow(pal1_down),
    nrow(pal5_down)
  )
)


colnames(site_data)   # 返回数据框，显示第一行

# Optional checkpoint for restarting downstream modules without rebuilding
# FASTA windows. The in-memory objects remain available for the sourced run.
cache_dir <- file.path(project_root, "cache")
dir.create(cache_dir, recursive = TRUE, showWarnings = FALSE)
saveRDS(
  list(
    site_data = site_data,
    pal1_background = pal1_background,
    pal5_background = pal5_background,
    pal1_down = pal1_down,
    pal5_down = pal5_down
  ),
  file.path(cache_dir, "R2_0_preprocessed_objects.rds")
)


















































