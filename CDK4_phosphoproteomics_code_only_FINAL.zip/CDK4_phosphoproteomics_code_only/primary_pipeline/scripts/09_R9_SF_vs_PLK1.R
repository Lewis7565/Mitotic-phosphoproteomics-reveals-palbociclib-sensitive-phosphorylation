
# =============================================================================
# R9. SF motif versus PLK1 substrate sensitivity analysis
#
# Questions:
# 1) Are known PLK1 substrate phosphosites enriched among SF-positive sites?
# 2) Does SF enrichment remain after excluding known PLK1 substrate sites?
# 3) Does SF enrichment remain after excluding known PLK1 substrate proteins?
#
# Required objects:
#   site_data
#   pal1_background
#   pal5_background
#   analysis_dir
#
# Required reference:
#   kinase_substrate_reference_R6.csv
#   (same reference used in R6/R8)
# =============================================================================

suppressPackageStartupMessages({
  library(tidyverse)
  library(openxlsx)
})

# -----------------------------------------------------------------------------
# 0. Checks
# -----------------------------------------------------------------------------

required_objects <- c("site_data", "pal1_background", "pal5_background", "analysis_dir")
missing_objects <- required_objects[
  !vapply(required_objects, exists, logical(1), inherits = TRUE)
]

if (length(missing_objects) > 0) {
  stop(
    paste0(
      "R9 requires: ",
      paste(missing_objects, collapse = ", "),
      "\nPlease run/source the earlier preprocessing scripts first."
    )
  )
}

required_cols <- c(
  "site_id",
  "protein_accession_clean",
  "Position",
  "Amino acid",
  "Gene name",
  "Pal1_log2FC",
  "Pal5_log2FC",
  "Pal1/Con P value",
  "Pal5/Con P value"
)

missing_cols <- setdiff(required_cols, colnames(site_data))
if (length(missing_cols) > 0) {
  stop(
    paste0(
      "site_data is missing: ",
      paste(missing_cols, collapse = ", ")
    )
  )
}

r9_dir <- file.path(analysis_dir, "R9_SF_vs_PLK1")
r9_table_dir <- file.path(r9_dir, "tables")
r9_figure_dir <- file.path(r9_dir, "figures")

dir.create(r9_table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(r9_figure_dir, recursive = TRUE, showWarnings = FALSE)

# -----------------------------------------------------------------------------
# 1. Define SF robustly
# -----------------------------------------------------------------------------

site_data_r9 <- site_data

if ("sf_positive" %in% colnames(site_data_r9)) {

  site_data_r9 <- site_data_r9 %>%
    mutate(sf_positive_r9 = as.logical(sf_positive))

} else if ("plus1_aa" %in% colnames(site_data_r9)) {

  site_data_r9 <- site_data_r9 %>%
    mutate(
      sf_positive_r9 =
        `Amino acid` == "S" &
        str_to_upper(plus1_aa) == "F"
    )

} else if ("motif_sequence_15mer" %in% colnames(site_data_r9)) {

  site_data_r9 <- site_data_r9 %>%
    mutate(
      motif_sequence_15mer = str_to_upper(motif_sequence_15mer),
      sf_positive_r9 =
        `Amino acid` == "S" &
        str_sub(motif_sequence_15mer, 9, 9) == "F"
    )

} else {
  stop(
    paste0(
      "Cannot define SF. Need one of: ",
      "sf_positive, plus1_aa, motif_sequence_15mer."
    )
  )
}

sf_map <- site_data_r9 %>%
  select(site_id, sf_positive_r9) %>%
  distinct()

pal1_background_r9 <- pal1_background %>%
  select(-any_of("sf_positive_r9")) %>%
  left_join(sf_map, by = "site_id")

pal5_background_r9 <- pal5_background %>%
  select(-any_of("sf_positive_r9")) %>%
  left_join(sf_map, by = "site_id")

# -----------------------------------------------------------------------------
# 2. Load exact R6 kinase reference
# -----------------------------------------------------------------------------

reference_candidates <- c(
  file.path(analysis_dir, "R6_kinase_signature", "input_reference",
            "kinase_substrate_reference_R6.csv"),
  file.path(analysis_dir, "R6_kinase_signature_analysis", "input_reference",
            "kinase_substrate_reference_R6.csv"),
  file.path(analysis_dir, "input_reference",
            "kinase_substrate_reference_R6.csv")
)

reference_path <- reference_candidates[file.exists(reference_candidates)][1]

if (is.na(reference_path)) {
  stop(
    paste0(
      "Could not find kinase_substrate_reference_R6.csv.\n",
      "Please set reference_path manually to the same file used in R6/R8."
    )
  )
}

kinase_reference <- readr::read_csv(
  reference_path,
  show_col_types = FALSE
) %>%
  mutate(
    kinase = str_to_upper(str_trim(kinase)),
    kinase = case_when(
      kinase %in% c("MPS1", "MPS-1") ~ "TTK",
      TRUE ~ kinase
    ),
    substrate_accession = str_trim(substrate_accession),
    substrate_gene = str_trim(substrate_gene),
    residue = str_to_upper(str_trim(residue)),
    position = as.integer(position)
  ) %>%
  filter(
    !is.na(substrate_accession),
    !is.na(position),
    residue %in% c("S", "T", "Y")
  )

plk1_reference <- kinase_reference %>%
  filter(kinase == "PLK1") %>%
  distinct(
    substrate_accession,
    substrate_gene,
    residue,
    position,
    .keep_all = TRUE
  )

if (nrow(plk1_reference) == 0) {
  stop("No PLK1 sites found in the kinase reference.")
}

# -----------------------------------------------------------------------------
# 3. Exact PLK1 site matching
# -----------------------------------------------------------------------------

plk1_reference_join <- plk1_reference %>%
  rename(substrate_gene_ref = substrate_gene)

plk1_matches <- site_data_r9 %>%
  inner_join(
    plk1_reference_join,
    by = c(
      "protein_accession_clean" = "substrate_accession",
      "Position" = "position",
      "Amino acid" = "residue"
    )
  ) %>%
  distinct(site_id, .keep_all = TRUE)

plk1_site_ids <- unique(plk1_matches$site_id)

plk1_accessions <- unique(
  plk1_reference$substrate_accession[
    !is.na(plk1_reference$substrate_accession) &
      plk1_reference$substrate_accession != ""
  ]
)

# -----------------------------------------------------------------------------
# 4. Is SF enriched among exact PLK1 serine sites?
#    IMPORTANT: universe = quantified SERINE sites only
# -----------------------------------------------------------------------------

fisher_from_counts <- function(a, b, c, d) {
  ft <- fisher.test(
    matrix(c(a, b, c, d), nrow = 2, byrow = TRUE)
  )

  tibble(
    PLK1_SF = a,
    PLK1_nonSF = b,
    nonPLK1_SF = c,
    nonPLK1_nonSF = d,
    odds_ratio = unname(ft$estimate),
    conf_low = ft$conf.int[1],
    conf_high = ft$conf.int[2],
    p_value = ft$p.value
  )
}

plk1_sf_enrichment_one <- function(background_data, dose) {

  dat <- background_data %>%
    filter(
      `Amino acid` == "S",
      !is.na(sf_positive_r9)
    ) %>%
    distinct(site_id, .keep_all = TRUE) %>%
    mutate(is_PLK1_site = site_id %in% plk1_site_ids)

  a <- sum(dat$is_PLK1_site & dat$sf_positive_r9, na.rm = TRUE)
  b <- sum(dat$is_PLK1_site & !dat$sf_positive_r9, na.rm = TRUE)
  c <- sum(!dat$is_PLK1_site & dat$sf_positive_r9, na.rm = TRUE)
  d <- sum(!dat$is_PLK1_site & !dat$sf_positive_r9, na.rm = TRUE)

  fisher_from_counts(a, b, c, d) %>%
    mutate(
      dose = dose,
      quantified_serine_sites = nrow(dat),
      detected_PLK1_serine_sites = sum(dat$is_PLK1_site),
      SF_sites = sum(dat$sf_positive_r9)
    ) %>%
    relocate(dose)
}

plk1_sf_enrichment <- bind_rows(
  plk1_sf_enrichment_one(pal1_background_r9, "Pal1"),
  plk1_sf_enrichment_one(pal5_background_r9, "Pal5")
) %>%
  mutate(p_adjust = p.adjust(p_value, method = "BH"))

# -----------------------------------------------------------------------------
# 5. Supplementary protein-level SF/PLK1 overlap
# -----------------------------------------------------------------------------

plk1_protein_sf_one <- function(background_data, dose) {

  protein_df <- background_data %>%
    filter(`Amino acid` == "S") %>%
    group_by(protein_accession_clean) %>%
    summarise(
      contains_SF = any(sf_positive_r9 %in% TRUE, na.rm = TRUE),
      .groups = "drop"
    ) %>%
    mutate(
      is_PLK1_substrate_protein =
        protein_accession_clean %in% plk1_accessions
    )

  a <- sum(protein_df$is_PLK1_substrate_protein & protein_df$contains_SF)
  b <- sum(protein_df$is_PLK1_substrate_protein & !protein_df$contains_SF)
  c <- sum(!protein_df$is_PLK1_substrate_protein & protein_df$contains_SF)
  d <- sum(!protein_df$is_PLK1_substrate_protein & !protein_df$contains_SF)

  fisher_from_counts(a, b, c, d) %>%
    mutate(
      dose = dose,
      proteins_tested = nrow(protein_df)
    ) %>%
    relocate(dose)
}

plk1_protein_sf_enrichment <- bind_rows(
  plk1_protein_sf_one(pal1_background_r9, "Pal1"),
  plk1_protein_sf_one(pal5_background_r9, "Pal5")
) %>%
  mutate(p_adjust = p.adjust(p_value, method = "BH"))

# -----------------------------------------------------------------------------
# 6. SF enrichment across thresholds after PLK1 exclusion
# -----------------------------------------------------------------------------

log2fc_cutoffs <- c(
  "lt0" = 0,
  "lt_m0.5" = -0.5,
  "lt_m0.6" = -0.6,
  "lt_m1.0" = -1.0
)

apply_exclusion_r9 <- function(data, mode) {

  if (mode == "Baseline") {
    return(data)
  }

  if (mode == "Exclude_PLK1_sites") {
    return(
      data %>%
        filter(!site_id %in% plk1_site_ids)
    )
  }

  if (mode == "Exclude_PLK1_proteins") {
    return(
      data %>%
        filter(
          !protein_accession_clean %in% plk1_accessions
        )
    )
  }

  stop("Unknown exclusion mode: ", mode)
}

sf_threshold_fisher <- function(
    background_data,
    log2fc_col,
    p_col,
    cutoff_value,
    dose,
    cutoff_name,
    exclusion_mode
) {

  dat <- apply_exclusion_r9(
    background_data,
    exclusion_mode
  ) %>%
    filter(
      `Amino acid` == "S",
      !is.na(sf_positive_r9),
      !is.na({{ log2fc_col }}),
      !is.na({{ p_col }})
    ) %>%
    mutate(
      is_foreground =
        {{ p_col }} < 0.05 &
        {{ log2fc_col }} < cutoff_value
    )

  a <- sum(dat$is_foreground & dat$sf_positive_r9)
  b <- sum(dat$is_foreground & !dat$sf_positive_r9)
  c <- sum(!dat$is_foreground & dat$sf_positive_r9)
  d <- sum(!dat$is_foreground & !dat$sf_positive_r9)

  ft <- fisher.test(
    matrix(c(a, b, c, d), nrow = 2, byrow = TRUE)
  )

  tibble(
    dose = dose,
    cutoff = cutoff_name,
    exclusion_mode = exclusion_mode,
    serine_background_n = nrow(dat),
    foreground_n = sum(dat$is_foreground),
    foreground_SF_n = a,
    total_SF_n = sum(dat$sf_positive_r9),
    odds_ratio = unname(ft$estimate),
    conf_low = ft$conf.int[1],
    conf_high = ft$conf.int[2],
    p_value = ft$p.value
  )
}

run_sf_thresholds <- function(
    background_data,
    log2fc_col,
    p_col,
    dose
) {

  bind_rows(
    lapply(
      names(log2fc_cutoffs),
      function(cutoff_name) {

        cutoff_value <- log2fc_cutoffs[[cutoff_name]]

        bind_rows(
          lapply(
            c(
              "Baseline",
              "Exclude_PLK1_sites",
              "Exclude_PLK1_proteins"
            ),
            function(exclusion_mode) {

              sf_threshold_fisher(
                background_data = background_data,
                log2fc_col = {{ log2fc_col }},
                p_col = {{ p_col }},
                cutoff_value = cutoff_value,
                dose = dose,
                cutoff_name = cutoff_name,
                exclusion_mode = exclusion_mode
              )
            }
          )
        )
      }
    )
  ) %>%
    group_by(dose, exclusion_mode) %>%
    mutate(
      p_adjust = p.adjust(p_value, method = "BH")
    ) %>%
    ungroup()
}

sf_threshold_sensitivity <- bind_rows(
  run_sf_thresholds(
    pal1_background_r9,
    Pal1_log2FC,
    `Pal1/Con P value`,
    "Pal1"
  ),
  run_sf_thresholds(
    pal5_background_r9,
    Pal5_log2FC,
    `Pal5/Con P value`,
    "Pal5"
  )
)

sf_threshold_stability <- sf_threshold_sensitivity %>%
  group_by(dose, exclusion_mode) %>%
  summarise(
    n_thresholds = n(),
    thresholds_OR_gt1 = sum(odds_ratio > 1, na.rm = TRUE),
    thresholds_FDR_lt_005 = sum(p_adjust < 0.05, na.rm = TRUE),
    thresholds_FDR_lt_020 = sum(p_adjust < 0.20, na.rm = TRUE),
    median_OR = median(odds_ratio, na.rm = TRUE),
    min_OR = min(odds_ratio, na.rm = TRUE),
    max_OR = max(odds_ratio, na.rm = TRUE),
    best_FDR = min(p_adjust, na.rm = TRUE),
    .groups = "drop"
  )

sf_baseline_comparison <- sf_threshold_sensitivity %>%
  select(
    dose,
    cutoff,
    exclusion_mode,
    odds_ratio,
    p_adjust,
    foreground_n,
    foreground_SF_n,
    serine_background_n
  ) %>%
  pivot_wider(
    names_from = exclusion_mode,
    values_from = c(
      odds_ratio,
      p_adjust,
      foreground_n,
      foreground_SF_n,
      serine_background_n
    )
  ) %>%
  mutate(
    OR_ratio_site_exclusion =
      odds_ratio_Exclude_PLK1_sites / odds_ratio_Baseline,

    OR_ratio_protein_exclusion =
      odds_ratio_Exclude_PLK1_proteins / odds_ratio_Baseline,

    remains_enriched_after_site_exclusion =
      odds_ratio_Exclude_PLK1_sites > 1,

    remains_enriched_after_protein_exclusion =
      odds_ratio_Exclude_PLK1_proteins > 1
  )

# -----------------------------------------------------------------------------
# 7. Cutoff-independent continuous SF shift after exclusions
# -----------------------------------------------------------------------------

continuous_sf_test <- function(
    background_data,
    log2fc_col,
    dose,
    exclusion_mode
) {

  dat <- apply_exclusion_r9(
    background_data,
    exclusion_mode
  ) %>%
    filter(
      `Amino acid` == "S",
      !is.na(sf_positive_r9),
      !is.na({{ log2fc_col }})
    )

  sf_values <- dat %>%
    filter(sf_positive_r9) %>%
    pull({{ log2fc_col }})

  other_s <- dat %>%
    filter(!sf_positive_r9) %>%
    pull({{ log2fc_col }})

  tibble(
    dose = dose,
    exclusion_mode = exclusion_mode,
    n_SF = length(sf_values),
    n_other_S = length(other_s),
    median_SF = median(sf_values, na.rm = TRUE),
    median_other_S = median(other_s, na.rm = TRUE),
    median_difference =
      median(sf_values, na.rm = TRUE) -
      median(other_s, na.rm = TRUE),
    wilcox_less_p = if (
      length(sf_values) >= 3 &&
      length(other_s) >= 3
    ) {
      wilcox.test(
        sf_values,
        other_s,
        alternative = "less",
        exact = FALSE
      )$p.value
    } else {
      NA_real_
    },
    wilcox_two_sided_p = if (
      length(sf_values) >= 3 &&
      length(other_s) >= 3
    ) {
      wilcox.test(
        sf_values,
        other_s,
        exact = FALSE
      )$p.value
    } else {
      NA_real_
    }
  )
}

sf_continuous_sensitivity <- bind_rows(
  lapply(
    c(
      "Baseline",
      "Exclude_PLK1_sites",
      "Exclude_PLK1_proteins"
    ),
    function(mode) {
      bind_rows(
        continuous_sf_test(
          pal1_background_r9,
          Pal1_log2FC,
          "Pal1",
          mode
        ),
        continuous_sf_test(
          pal5_background_r9,
          Pal5_log2FC,
          "Pal5",
          mode
        )
      )
    }
  )
) %>%
  group_by(dose) %>%
  mutate(
    wilcox_less_FDR =
      p.adjust(wilcox_less_p, method = "BH"),
    wilcox_two_sided_FDR =
      p.adjust(wilcox_two_sided_p, method = "BH")
  ) %>%
  ungroup()

# -----------------------------------------------------------------------------
# 8. Exact PLK1 serine sites for manual biological inspection
# -----------------------------------------------------------------------------

plk1_sf_site_table <- plk1_matches %>%
  filter(`Amino acid` == "S") %>%
  mutate(
    substrate_gene =
      coalesce(
        substrate_gene_ref,
        `Gene name`
      )
  ) %>%
  transmute(
    site_id,
    substrate_gene,
    protein_accession = protein_accession_clean,
    residue = `Amino acid`,
    position = Position,
    sf_positive = sf_positive_r9,
    motif_type = if ("motif_type" %in% colnames(plk1_matches)) {
      motif_type
    } else {
      NA_character_
    },
    motif_sequence_15mer =
      if ("motif_sequence_15mer" %in% colnames(plk1_matches)) {
        motif_sequence_15mer
      } else {
        NA_character_
      },
    Pal1_log2FC,
    Pal1_p_value = `Pal1/Con P value`,
    Pal5_log2FC,
    Pal5_p_value = `Pal5/Con P value`
  ) %>%
  arrange(desc(sf_positive), Pal5_log2FC)

# -----------------------------------------------------------------------------
# 9. Figures
# -----------------------------------------------------------------------------

p_threshold <- sf_threshold_sensitivity %>%
  mutate(
    cutoff = factor(
      cutoff,
      levels = names(log2fc_cutoffs),
      labels = c("< 0", "< -0.5", "< -0.6", "< -1.0")
    )
  ) %>%
  ggplot(
    aes(
      x = cutoff,
      y = odds_ratio,
      group = exclusion_mode,
      linetype = exclusion_mode,
      shape = exclusion_mode
    )
  ) +
  geom_hline(yintercept = 1, linetype = 2) +
  geom_line() +
  geom_point(size = 2.5) +
  facet_wrap(~ dose) +
  scale_y_log10() +
  labs(
    title = "SF enrichment before and after PLK1 exclusion",
    subtitle = "Among quantified serine-centered phosphosites",
    x = "Foreground log2FC threshold (P < 0.05)",
    y = "SF odds ratio (log10 scale)"
  ) +
  theme_bw() +
  theme(legend.position = "bottom")

ggsave(
  file.path(
    r9_figure_dir,
    "01_SF_enrichment_after_PLK1_exclusion.png"
  ),
  p_threshold,
  width = 8,
  height = 5.5,
  dpi = 300
)

p_continuous <- sf_continuous_sensitivity %>%
  select(
    dose,
    exclusion_mode,
    median_SF,
    median_other_S
  ) %>%
  pivot_longer(
    cols = c(median_SF, median_other_S),
    names_to = "site_class",
    values_to = "median_log2FC"
  ) %>%
  mutate(
    site_class = recode(
      site_class,
      median_SF = "SF",
      median_other_S = "Other serine"
    )
  ) %>%
  ggplot(
    aes(
      x = exclusion_mode,
      y = median_log2FC,
      shape = site_class,
      group = site_class
    )
  ) +
  geom_hline(yintercept = 0, linetype = 2) +
  geom_line() +
  geom_point(size = 2.5) +
  facet_wrap(~ dose) +
  labs(
    title = "Continuous SF shift after PLK1 exclusion",
    x = NULL,
    y = "Median phosphosite log2FC"
  ) +
  theme_bw() +
  theme(
    axis.text.x = element_text(angle = 25, hjust = 1),
    legend.position = "bottom"
  )

ggsave(
  file.path(
    r9_figure_dir,
    "02_SF_continuous_shift_after_PLK1_exclusion.png"
  ),
  p_continuous,
  width = 9,
  height = 5.5,
  dpi = 300
)

# -----------------------------------------------------------------------------
# 10. Export
# -----------------------------------------------------------------------------

output_xlsx <- file.path(
  r9_table_dir,
  "01_R9_SF_vs_PLK1_analysis.xlsx"
)

openxlsx::write.xlsx(
  list(
    PLK1_SF_site_enrichment =
      plk1_sf_enrichment,

    PLK1_protein_SF_overlap =
      plk1_protein_sf_enrichment,

    SF_threshold_all =
      sf_threshold_sensitivity,

    SF_threshold_stability =
      sf_threshold_stability,

    SF_baseline_comparison =
      sf_baseline_comparison,

    SF_continuous =
      sf_continuous_sensitivity,

    PLK1_SF_sites =
      plk1_sf_site_table
  ),
  file = output_xlsx,
  overwrite = TRUE
)

cat("\n============================================================\n")
cat("R9 completed.\n")
cat("============================================================\n\n")

cat("A. PLK1-site SF enrichment:\n")
print(plk1_sf_enrichment)

cat("\nB. SF threshold robustness after PLK1 exclusion:\n")
print(sf_threshold_stability)

cat("\nC. Continuous SF shift after PLK1 exclusion:\n")
print(sf_continuous_sensitivity)

cat("\nOutput workbook:\n", output_xlsx, "\n")
