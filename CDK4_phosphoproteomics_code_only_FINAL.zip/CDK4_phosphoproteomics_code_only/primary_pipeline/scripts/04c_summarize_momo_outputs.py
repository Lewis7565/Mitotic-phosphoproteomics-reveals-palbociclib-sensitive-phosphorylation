from __future__ import annotations

import csv
import json
import math
import re
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.font_manager import FontProperties
from matplotlib.patches import PathPatch
from matplotlib.textpath import TextPath
from matplotlib.transforms import Affine2D


PROJECT_ROOT = Path(__file__).resolve().parents[1]
R4_DIR = PROJECT_ROOT / "results" / "R4_missingness_and_MoMo"
OUTPUT_ROOT = R4_DIR / "MoMo_output"
TABLE_DIR = R4_DIR / "tables"
FIGURE_DIR = R4_DIR / "figures" / "MoMo"
LOGO_DIR = FIGURE_DIR / "logos"

CONDITION_RE = re.compile(r"^(Pal[15])_log2FC_lt_(0|0p5|0p6|1)_([ST])$")
CUTOFF_MAP = {"0": 0.0, "0p5": -0.5, "0p6": -0.6, "1": -1.0}
CUTOFF_LABELS = {0.0: "<0", -0.5: "<−0.5", -0.6: "<−0.6", -1.0: "<−1"}
ALPHABET = "ACDEFGHIKLMNPQRSTVWY"
AA_COLORS = {
    **{aa: "#2C7BB6" for aa in "KRH"},
    **{aa: "#D7191C" for aa in "DE"},
    **{aa: "#1A9641" for aa in "STNQ"},
    **{aa: "#7B3294" for aa in "FWY"},
    **{aa: "#E08214" for aa in "GPA"},
    **{aa: "#4D4D4D" for aa in "CVILM"},
}


def read_momo_tsv(path: Path) -> list[dict[str, str]]:
    lines = [line for line in path.read_text(encoding="utf-8").splitlines() if line and not line.startswith("#")]
    if len(lines) <= 1:
        return []
    return list(csv.DictReader(lines, delimiter="\t"))


def parse_meme_motifs(path: Path) -> list[dict]:
    lines = path.read_text(encoding="utf-8").splitlines()
    motifs = []
    i = 0
    while i < len(lines):
        if not lines[i].startswith("MOTIF "):
            i += 1
            continue
        parts = lines[i].split(maxsplit=2)
        motif_id = parts[1]
        regexp = parts[2] if len(parts) > 2 else ""
        i += 1
        while i < len(lines) and not lines[i].startswith("letter-probability matrix:"):
            i += 1
        if i >= len(lines):
            break
        header = lines[i]
        width_match = re.search(r"\bw=\s*(\d+)", header)
        nsites_match = re.search(r"\bnsites=\s*(\d+)", header)
        width = int(width_match.group(1)) if width_match else 15
        nsites = int(nsites_match.group(1)) if nsites_match else None
        matrix = []
        for row in lines[i + 1 : i + 1 + width]:
            values = [float(value) for value in row.split()]
            if len(values) == len(ALPHABET):
                matrix.append(values)
        if len(matrix) == width:
            motifs.append({"motif_id": motif_id, "regexp": regexp, "nsites": nsites, "matrix": np.array(matrix)})
        i += width + 1
    return motifs


def draw_logo(matrix: np.ndarray, title: str, output_path: Path) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(9.0, 3.2))
    font = FontProperties(family="DejaVu Sans", weight="bold")
    max_bits = math.log2(len(ALPHABET))

    for pos, probs in enumerate(matrix):
        entropy = -sum(float(p) * math.log2(float(p)) for p in probs if p > 0)
        information = max(0.0, max_bits - entropy)
        heights = probs * information
        y = 0.0
        for aa_index in np.argsort(heights):
            height = float(heights[aa_index])
            if height < 0.015:
                continue
            aa = ALPHABET[aa_index]
            glyph = TextPath((0, 0), aa, size=1, prop=font)
            bbox = glyph.get_extents()
            if bbox.width == 0 or bbox.height == 0:
                continue
            transform = (
                Affine2D()
                .translate(-bbox.x0, -bbox.y0)
                .scale(0.88 / bbox.width, height / bbox.height)
                .translate(pos + 0.06, y)
            )
            ax.add_patch(PathPatch(glyph, transform=transform + ax.transData, color=AA_COLORS[aa], lw=0))
            y += height

    center = matrix.shape[0] // 2
    ax.axvline(center + 0.5, color="#777777", lw=0.8, ls="--", alpha=0.7)
    ax.set_xlim(0, matrix.shape[0])
    ax.set_ylim(0, max_bits + 0.15)
    ax.set_xticks(np.arange(matrix.shape[0]) + 0.5)
    ax.set_xticklabels([str(i - center) for i in range(matrix.shape[0])], fontsize=8)
    ax.set_ylabel("Information (bits)")
    ax.set_xlabel("Position relative to modified residue")
    ax.set_title(title, fontsize=11, loc="left")
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(output_path, dpi=300, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def build_summary() -> tuple[pd.DataFrame, pd.DataFrame]:
    records: list[dict] = []
    run_records: list[dict] = []
    for condition_dir in sorted(path for path in OUTPUT_ROOT.iterdir() if path.is_dir()):
        match = CONDITION_RE.match(condition_dir.name)
        if not match:
            continue
        dose, cutoff_tag, center = match.groups()
        cutoff = CUTOFF_MAP[cutoff_tag]
        tsv_path = condition_dir / "momo.tsv"
        txt_path = condition_dir / "momo.txt"
        html_path = condition_dir / "momo.html"
        rows = read_momo_tsv(tsv_path)
        run_records.append(
            {
                "condition": condition_dir.name,
                "dose": dose,
                "log2fc_cutoff": cutoff,
                "center": center,
                "motifs_discovered": len(rows),
                "html_present": html_path.exists() and html_path.stat().st_size > 0,
                "tsv_present": tsv_path.exists() and tsv_path.stat().st_size > 0,
                "meme_txt_present": txt_path.exists() and txt_path.stat().st_size > 0,
                "native_output_dir": str(condition_dir.relative_to(PROJECT_ROOT)),
            }
        )
        for motif_index, row in enumerate(rows, start=1):
            records.append(
                {
                    "condition": condition_dir.name,
                    "dose": dose,
                    "log2fc_cutoff": cutoff,
                    "threshold": CUTOFF_LABELS[cutoff],
                    "center": center,
                    "motif_rank": motif_index,
                    "motif_id": row["motif"],
                    "motif_pattern": row["regexp"],
                    "score": float(row["score"]),
                    "foreground_matches": int(row["fg_match"]),
                    "foreground_size": int(row["fg_size"]),
                    "background_matches": int(row["bg_match"]),
                    "background_size": int(row["bg_size"]),
                    "fold_enrichment": float(row["fg/bg"]),
                    "unadjusted_p_value": float(row["unadjusted_p-value"]),
                    "adjusted_p_value": np.nan,
                    "adjustment_note": "Not reported by MoMo with --db-background; interpret as discovery evidence, not a stand-alone multiplicity-corrected test.",
                    "native_output_dir": str(condition_dir.relative_to(PROJECT_ROOT)),
                }
            )

        for motif_index, motif in enumerate(parse_meme_motifs(txt_path), start=1):
            safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", motif["regexp"]).strip("_") or f"motif_{motif_index}"
            logo_name = f"{condition_dir.name}__{motif_index:02d}__{safe}.png"
            draw_logo(
                motif["matrix"],
                f"{condition_dir.name}: {motif['regexp']} (n={motif['nsites']})",
                LOGO_DIR / logo_name,
            )

    return pd.DataFrame(records), pd.DataFrame(run_records)


def plot_reproducibility(summary: pd.DataFrame) -> None:
    FIGURE_DIR.mkdir(parents=True, exist_ok=True)
    condition_order = [
        f"{dose}\n{CUTOFF_LABELS[cutoff]}"
        for dose in ["Pal1", "Pal5"]
        for cutoff in [0.0, -0.5, -0.6, -1.0]
    ]
    fig, axes = plt.subplots(2, 1, figsize=(10.5, 6.5), constrained_layout=True)
    for ax, center in zip(axes, ["S", "T"]):
        subset = summary[summary["center"] == center].copy()
        subset["condition_label"] = subset.apply(
            lambda row: f"{row['dose']}\n{CUTOFF_LABELS[row['log2fc_cutoff']]}", axis=1
        )
        patterns = sorted(subset["motif_pattern"].unique())
        matrix = np.full((len(patterns), len(condition_order)), np.nan)
        for i, pattern in enumerate(patterns):
            for j, condition in enumerate(condition_order):
                values = subset.loc[
                    (subset["motif_pattern"] == pattern) & (subset["condition_label"] == condition),
                    "fold_enrichment",
                ]
                if not values.empty:
                    matrix[i, j] = values.max()
        shown = np.ma.masked_invalid(matrix)
        image = ax.imshow(shown, cmap="YlGnBu", vmin=1, vmax=max(6.5, np.nanmax(matrix)), aspect="auto")
        for i in range(matrix.shape[0]):
            for j in range(matrix.shape[1]):
                if np.isfinite(matrix[i, j]):
                    ax.text(j, i, f"{matrix[i, j]:.1f}×", ha="center", va="center", fontsize=8)
        ax.set_yticks(range(len(patterns)), patterns, fontsize=8)
        ax.set_xticks(range(len(condition_order)), condition_order, fontsize=8)
        ax.set_title(f"{center}-centered motifs", loc="left", fontsize=11)
        ax.set_ylabel("MoMo motif pattern")
        ax.spines[:].set_visible(False)
    fig.colorbar(image, ax=axes, shrink=0.75, label="Foreground/background enrichment")
    fig.suptitle("MoMo motif-x discovery across dose and log2FC thresholds", fontsize=13)
    fig.savefig(FIGURE_DIR / "MoMo_motifx_reproducibility_heatmap.png", dpi=300, bbox_inches="tight", facecolor="white")
    plt.close(fig)

    sf = summary[(summary["center"] == "S") & (summary["motif_pattern"] == ".......SF......")].copy()
    fig, ax = plt.subplots(figsize=(7.2, 4.2))
    x_values = [0.0, -0.5, -0.6, -1.0]
    for dose, color, marker in [("Pal1", "#2C7BB6", "o"), ("Pal5", "#D7191C", "s")]:
        dose_df = sf[sf["dose"] == dose].set_index("log2fc_cutoff")
        y_values = [dose_df.loc[x, "fold_enrichment"] if x in dose_df.index else np.nan for x in x_values]
        ax.plot(range(4), y_values, color=color, marker=marker, lw=2, ms=6, label=dose)
    ax.axhline(1, color="#777777", lw=0.8, ls="--")
    ax.set_xticks(range(4), [CUTOFF_LABELS[x] for x in x_values])
    ax.set_ylabel("MoMo foreground/background enrichment")
    ax.set_xlabel("Downregulated foreground threshold (log2FC)")
    ax.set_title("SF motif is reproducibly discovered across all Pal5 thresholds", loc="left", fontsize=11)
    ax.legend(frameon=False)
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", color="#E6E6E6", lw=0.7)
    fig.tight_layout()
    fig.savefig(FIGURE_DIR / "MoMo_SF_enrichment_across_thresholds.png", dpi=300, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def main() -> None:
    TABLE_DIR.mkdir(parents=True, exist_ok=True)
    summary, runs = build_summary()
    summary = summary.sort_values(["dose", "log2fc_cutoff", "center", "motif_rank"], ascending=[True, False, True, True])
    runs = runs.sort_values(["dose", "log2fc_cutoff", "center"], ascending=[True, False, True])
    summary.to_csv(TABLE_DIR / "05_MoMo_motifx_all_discovered_motifs.csv", index=False)
    runs.to_csv(TABLE_DIR / "06_MoMo_run_completeness_manifest.csv", index=False)
    workbook_payload = {
        "motifs": summary.replace({np.nan: None}).to_dict(orient="records"),
        "runs": runs.replace({np.nan: None}).to_dict(orient="records"),
    }
    (TABLE_DIR / "MoMo_workbook_payload.json").write_text(
        json.dumps(workbook_payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    plot_reproducibility(summary)
    print(f"conditions={len(runs)} motifs={len(summary)} logos={len(list(LOGO_DIR.glob('*.png')))}")


if __name__ == "__main__":
    main()
