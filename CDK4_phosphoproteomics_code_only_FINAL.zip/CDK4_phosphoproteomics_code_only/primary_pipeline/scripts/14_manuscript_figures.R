#!/usr/bin/env Rscript

# Publication figures for the integrated R2.0-R12 analysis.
# This script reads the frozen result workbooks and exports PDF, SVG, PNG,
# and one CSV source-data file for every figure.

source(file.path("scripts", "00_config.R"))

suppressPackageStartupMessages({
  library(readxl)
  library(ggplot2)
  library(dplyr)
  library(tidyr)
  library(stringr)
  library(scales)
})

input_dir <- Sys.getenv("MANUSCRIPT_RESULT_INPUT", unset = file.path(project_root, "input", "frozen_results"))
main_dir <- file.path(project_root, "figures", "main")
supp_dir <- file.path(project_root, "figures", "supplementary")
source_dir <- file.path(project_root, "source_data")
dir.create(main_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(supp_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(source_dir, recursive = TRUE, showWarnings = FALSE)

pal <- c(Pal1 = "#3B82B8", Pal5 = "#D64B4B")
motif_pal <- c(SP = "#4C78A8", TP = "#72B7B2", SF = "#E45756")
target_pal <- c(Kinetochore_core = "#4C78A8", SAC_core = "#F2A541", RZZ_fibrous_corona_core = "#8F63B8")

theme_paper <- function(base_size = 10) {
  theme_classic(base_size = base_size, base_family = "Arial") +
    theme(
      axis.title = element_text(colour = "#1F2937"),
      axis.text = element_text(colour = "#374151"),
      plot.title = element_text(face = "bold", size = rel(1.15), colour = "#111827"),
      plot.subtitle = element_text(colour = "#4B5563"),
      legend.title = element_text(face = "bold"),
      strip.background = element_rect(fill = "#EEF2F6", colour = NA),
      strip.text = element_text(face = "bold", colour = "#1F2937"),
      plot.margin = margin(8, 10, 8, 8)
    )
}

save_figure <- function(plot, stem, directory, width, height) {
  ggsave(file.path(directory, paste0(stem, ".pdf")), plot, width = width, height = height, units = "in", device = cairo_pdf)
  if (requireNamespace("svglite", quietly = TRUE)) {
    ggsave(file.path(directory, paste0(stem, ".svg")), plot, width = width, height = height, units = "in", device = svglite::svglite)
  }
  ggsave(file.path(directory, paste0(stem, ".png")), plot, width = width, height = height, units = "in", dpi = 450, bg = "white")
}

read_result <- function(file, sheet) read_excel(file.path(input_dir, file), sheet = sheet)

# Figure 1: threshold-robust motif enrichment/depletion.
motif <- read_result("R3_threshold_all.xlsx", "Motif_thresholds") |>
  filter(analysis_level == "Phosphosite", category %in% c("SP", "TP", "SF")) |>
  mutate(
    threshold_label = factor(threshold, levels = c("log2FC_lt_0", "log2FC_lt_0p5", "log2FC_lt_0p6", "log2FC_lt_1"),
                             labels = c("< 0", "< -0.5", "< -0.6", "< -1.0")),
    dose = factor(dose, levels = c("Pal1", "Pal5")),
    category = factor(category, levels = c("SP", "TP", "SF"))
  )
write.csv(motif, file.path(source_dir, "Figure_1_motif_threshold_source.csv"), row.names = FALSE)
p1 <- ggplot(motif, aes(threshold_label, odds_ratio, colour = category, group = category)) +
  geom_hline(yintercept = 1, linetype = 2, colour = "#9CA3AF") +
  geom_line(linewidth = 0.7) +
  geom_point(aes(shape = p_adjust_across_thresholds < 0.05), size = 2.4, stroke = 0.7) +
  facet_wrap(~ dose, nrow = 1) +
  scale_y_log10(breaks = c(0.25, 0.5, 1, 2, 4, 8), labels = label_number(accuracy = 0.01)) +
  scale_colour_manual(values = motif_pal) +
  scale_shape_manual(values = c(`TRUE` = 16, `FALSE` = 1), labels = c(`TRUE` = "FDR < 0.05", `FALSE` = "FDR ≥ 0.05")) +
  labs(title = "Motif responses are robust across foreground definitions",
       subtitle = "SP/TP motifs are depleted while SF motifs are enriched among downregulated sites",
       x = "log2 fold-change threshold", y = "Odds ratio (log scale)", colour = "Motif", shape = NULL) +
  theme_paper()
save_figure(p1, "Figure_1_motif_threshold_robustness", main_dir, 7.2, 3.6)

# Figure 2: site-count-adjusted broad teacher-priority pathways.
priority <- read_result("R12_final.xlsx", "Priority_summary") |>
  mutate(
    dose = factor(dose, levels = c("Pal1", "Pal5")),
    pathway = str_wrap(description, 38),
    pathway = factor(pathway, levels = rev(unique(pathway))),
    sig = case_when(best_global_FDR < 0.05 ~ "FDR < 0.05", best_global_FDR < 0.20 ~ "FDR < 0.20", TRUE ~ "Not significant")
  )
write.csv(priority, file.path(source_dir, "Figure_4_adjusted_priority_pathways_source.csv"), row.names = FALSE)
p2 <- ggplot(priority, aes(dose, pathway, fill = log2(median_adjusted_OR))) +
  geom_tile(colour = "white", linewidth = 0.7) +
  geom_text(aes(label = sprintf("OR %.2f\nFDR %.3f", median_adjusted_OR, best_global_FDR)), size = 2.4, colour = "#111827") +
  scale_fill_gradient2(low = "#3B82B8", mid = "white", high = "#D64B4B", midpoint = 0,
                       name = expression(log[2](median~adjusted~OR))) +
  labs(title = "Broad pathway signals after phosphosite-count adjustment",
       subtitle = "Displayed FDR values are corrected across the full tested pathway family",
       x = NULL, y = NULL) +
  theme_paper(9) +
  theme(axis.text.y = element_text(size = 7.5))
save_figure(p2, "Figure_4_adjusted_priority_pathways", main_dir, 7.6, 6.4)

# Figure 3: Firth logistic regression for compact RZZ and SAC gene sets.
firth <- read_result("R12_final.xlsx", "Firth_RZZ_SAC") |>
  mutate(
    dose = factor(dose, levels = c("Pal1", "Pal5")),
    cutoff_label = factor(cutoff, levels = c("lt0", "lt_m0.5", "lt_m0.6", "lt_m1.0"), labels = c("< 0", "< -0.5", "< -0.6", "< -1.0")),
    target_label = recode(target, RZZ_fibrous_corona_core = "RZZ/fibrous corona", SAC_core = "Spindle checkpoint (SAC)"),
    significant = FDR < 0.05
  )
write.csv(firth, file.path(source_dir, "Figure_5_firth_RZZ_SAC_source.csv"), row.names = FALSE)
p3 <- ggplot(firth, aes(adjusted_OR, cutoff_label, colour = dose)) +
  geom_vline(xintercept = 1, linetype = 2, colour = "#9CA3AF") +
  geom_errorbarh(aes(xmin = OR_conf_low, xmax = OR_conf_high), height = 0.15, position = position_dodge(width = 0.45), linewidth = 0.55) +
  geom_point(aes(shape = significant), size = 2.5, position = position_dodge(width = 0.45), stroke = 0.8) +
  facet_wrap(~ target_label, nrow = 1) +
  scale_x_log10(breaks = c(0.1, 0.5, 1, 5, 25), labels = label_number()) +
  scale_colour_manual(values = pal) +
  scale_shape_manual(values = c(`TRUE` = 16, `FALSE` = 1), labels = c(`TRUE` = "FDR < 0.05", `FALSE` = "FDR ≥ 0.05")) +
  labs(title = "Compact RZZ and SAC sets show a Pal5-selective signal",
       subtitle = "Firth models adjust for the number of quantified phosphosites per protein",
       x = "Adjusted odds ratio (log scale)", y = "log2 fold-change threshold", colour = "Dose", shape = NULL) +
  theme_paper()
save_figure(p3, "Figure_5_firth_RZZ_SAC", main_dir, 7.5, 4.0)

# Figure 4: PLK1 dose response and PLK1-SF enrichment.
plk_pair <- read_result("R8_PLK1.xlsx", "PLK1_paired_sites") |>
  select(site_id, Pal1_log2FC, Pal5_log2FC) |>
  filter(is.finite(Pal1_log2FC), is.finite(Pal5_log2FC))
sf <- read_result("R9_SF_PLK1.xlsx", "PLK1_SF_site_enrichment") |>
  mutate(dose = factor(dose, levels = c("Pal1", "Pal5")))
write.csv(plk_pair, file.path(source_dir, "Figure_3A_PLK1_paired_sites_source.csv"), row.names = FALSE)
write.csv(sf, file.path(source_dir, "Figure_3B_PLK1_SF_enrichment_source.csv"), row.names = FALSE)
p4a <- ggplot(plk_pair, aes(Pal1_log2FC, Pal5_log2FC)) +
  geom_abline(slope = 1, intercept = 0, linetype = 2, colour = "#9CA3AF") +
  geom_point(shape = 21, fill = "#7A5195", colour = "white", size = 2.2, alpha = 0.85) +
  coord_equal() +
  labs(title = "A  Exact PLK1 reference sites", x = "Pal1 log2 fold change", y = "Pal5 log2 fold change") +
  theme_paper()
p4b <- ggplot(sf, aes(odds_ratio, dose, colour = dose)) +
  geom_vline(xintercept = 1, linetype = 2, colour = "#9CA3AF") +
  geom_errorbarh(aes(xmin = conf_low, xmax = conf_high), height = 0.18, linewidth = 0.6) +
  geom_point(size = 3) +
  geom_text(aes(label = sprintf("FDR %.3g", p_adjust)), nudge_y = 0.25, colour = "#374151", size = 3) +
  scale_x_log10(breaks = c(1, 2, 5, 10, 20)) +
  scale_colour_manual(values = pal, guide = "none") +
  labs(title = "B  SF motifs among PLK1 sites", x = "Odds ratio (log scale)", y = NULL) +
  theme_paper()
if (requireNamespace("patchwork", quietly = TRUE)) {
  p4 <- p4a + p4b + patchwork::plot_layout(widths = c(1.05, 0.95)) +
    patchwork::plot_annotation(title = "PLK1-linked sites connect to the SF motif signal")
  save_figure(p4, "Figure_3_PLK1_and_SF", main_dir, 7.5, 3.7)
} else {
  save_figure(p4a, "Figure_3A_PLK1_paired_sites", main_dir, 3.8, 3.6)
  save_figure(p4b, "Figure_3B_PLK1_SF_enrichment", main_dir, 3.8, 3.6)
}

# Figure 5: all detected RB1 phosphosites, highlighting curated CDK4/6 sites.
rb1 <- read_result("R7_CDK46.xlsx", "RB1_all_detected_sites") |>
  select(Position, site_label, is_known_CDK46_site, Pal1_log2FC, Pal5_log2FC, `Pal1/Con P value`, `Pal5/Con P value`) |>
  pivot_longer(c(Pal1_log2FC, Pal5_log2FC), names_to = "dose", values_to = "log2FC") |>
  mutate(dose = recode(dose, Pal1_log2FC = "Pal1", Pal5_log2FC = "Pal5"), dose = factor(dose, levels = c("Pal1", "Pal5")))
write.csv(rb1, file.path(source_dir, "Figure_2_RB1_sites_source.csv"), row.names = FALSE)
p5 <- ggplot(rb1, aes(Position, log2FC, colour = dose)) +
  geom_hline(yintercept = 0, linetype = 2, colour = "#9CA3AF") +
  geom_segment(aes(xend = Position, y = 0, yend = log2FC), linewidth = 0.35, alpha = 0.55,
               position = position_dodge(width = 8)) +
  geom_point(aes(shape = is_known_CDK46_site), size = 2.4, position = position_dodge(width = 8), stroke = 0.75) +
  geom_text(data = filter(rb1, site_label %in% c("T821", "T826"), dose == "Pal5"), aes(label = site_label),
            nudge_x = 18, vjust = 0.2, hjust = 0, size = 3, show.legend = FALSE) +
  scale_colour_manual(values = pal) +
  scale_shape_manual(values = c(`TRUE` = 17, `FALSE` = 1), labels = c(`TRUE` = "Curated CDK4/6 site", `FALSE` = "Other detected site")) +
  labs(title = "RB1 phosphosite response across the protein sequence",
       subtitle = "T821 and T826 are highlighted; individual sites do not establish a global CDK4/6 signature",
       x = "RB1 residue position", y = "log2 fold change", colour = "Dose", shape = NULL) +
  theme_paper()
save_figure(p5, "Figure_2_RB1_site_profile", main_dir, 7.5, 3.9)

# Supplementary Figure S1: site-count-adjusted targeted summary.
r10 <- read_result("R10_site_count.xlsx", "Integrated_summary") |>
  filter(target %in% c("Kinetochore_core", "SAC_core", "RZZ_fibrous_corona_core")) |>
  mutate(
    dose = factor(dose, levels = c("Pal1", "Pal5")),
    target_label = recode(target, Kinetochore_core = "Kinetochore", SAC_core = "SAC", RZZ_fibrous_corona_core = "RZZ/fibrous corona"),
    target_label = factor(target_label, levels = c("Kinetochore", "SAC", "RZZ/fibrous corona"))
  )
write.csv(r10, file.path(source_dir, "Figure_S1_site_count_adjustment_source.csv"), row.names = FALSE)
pS1 <- ggplot(r10, aes(dose, target_label, fill = log2(median_adjusted_OR))) +
  geom_tile(colour = "white", linewidth = 0.8) +
  geom_text(aes(label = sprintf("OR %.2f\nFDR %.3f", median_adjusted_OR, best_FDR)), size = 3) +
  scale_fill_gradient2(low = "#3B82B8", mid = "white", high = "#D64B4B", midpoint = 0,
                       name = expression(log[2](median~OR))) +
  labs(title = "Targeted pathway stability after site-count adjustment", x = NULL, y = NULL) +
  theme_paper()
save_figure(pS1, "Figure_S1_site_count_adjusted_targets", supp_dir, 5.8, 3.5)

# Supplementary Figure S2: kinase signatures.
kin <- read_result("R6_kinase.xlsx", "Integrated_summary") |>
  filter(kinase %in% c("PLK1", "CDK4", "CDK6")) |>
  mutate(dose = factor(dose, levels = c("Pal1", "Pal5")))
write.csv(kin, file.path(source_dir, "Figure_S2_kinase_summary_source.csv"), row.names = FALSE)
score_col <- intersect(c("continuous_median_shift", "median_shift", "continuous_shift"), names(kin))[1]
if (!is.na(score_col)) {
  pS2 <- ggplot(kin, aes(.data[[score_col]], kinase, colour = dose)) +
    geom_vline(xintercept = 0, linetype = 2, colour = "#9CA3AF") +
    geom_point(size = 2.8, position = position_dodge(width = 0.45)) +
    scale_colour_manual(values = pal) +
    labs(title = "Reference-site kinase response summary", x = "Median reference-site shift", y = NULL, colour = "Dose") +
    theme_paper()
  save_figure(pS2, "Figure_S2_kinase_signature", supp_dir, 5.8, 3.5)
}

message("Publication figures and source-data CSV files generated successfully.")
