# ============================================================================
# R5.0 — SP/TP/SF characterization + Pal1/Pal5 dose-response analysis
# ============================================================================
# 建议运行顺序：
#   R1.0 -> R2.0 -> R3.0 -> R4.0 -> 本脚本 R5.0
#
# 目标：
# A. SP/TP/SF-associated phosphosite / protein characterization
# B. Pal1 vs Pal5 dose-response / dose-consistency analysis
#
# 说明：
# - 本脚本不依赖 MoMo 结果，可以先运行。
# - 主分析基于 site_data 及原有 pal1_background / pal5_background。
# - 为保证跨剂量比较，优先使用 Pal1 与 Pal5 均可定量的共同位点。
# - “dose-strengthened”在本脚本中指 Pal5 log2FC 比 Pal1 更负；
#   这是 effect-size 层面的描述，不等同于正式剂量反应模型。
# ============================================================================

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(stringr)
  library(purrr)
  library(tibble)
  library(ggplot2)
  library(readr)
  library(openxlsx)
  library(forcats)
})

required_objects_r5 <- c("site_data", "pal1_background", "pal5_background")
missing_objects_r5 <- required_objects_r5[
  !vapply(required_objects_r5, exists, logical(1), inherits = TRUE)
]
if (length(missing_objects_r5) > 0) {
  stop("请先完整运行前面的 R1/R2/R3/R4。缺少对象：",
       paste(missing_objects_r5, collapse = ", "))
}

required_cols_r5 <- c(
  "Protein accession","Gene name","Position","Amino acid","site_id",
  "motif_sequence_15mer","motif_center_aa","motif_type",
  "proline_directed","sf_positive",
  "Pal1_log2FC","Pal5_log2FC",
  "Pal1/Con P value","Pal5/Con P value",
  "Pal1/Pal5 Ratio","Pal1/Pal5 P value"
)
missing_cols_r5 <- setdiff(required_cols_r5, colnames(site_data))
if (length(missing_cols_r5) > 0) {
  stop("site_data 缺少以下 R5.0 所需列：",
       paste(missing_cols_r5, collapse = ", "))
}

if (!exists("analysis_dir")) {
  analysis_dir <- file.path(getwd(), "phosphoproteomics_followup_analysis")
}
r5_dir <- file.path(analysis_dir, "R5_motif_characterization_and_dose_response")
r5_table_dir <- file.path(r5_dir, "tables")
r5_figure_dir <- file.path(r5_dir, "figures")
dir.create(r5_table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(r5_figure_dir, recursive = TRUE, showWarnings = FALSE)

# 1. motif classification
site_data <- site_data %>%
  mutate(
    plus1_aa = substr(motif_sequence_15mer, 9, 9),
    motif_type = case_when(
      motif_center_aa == "S" & plus1_aa == "P" ~ "SP",
      motif_center_aa == "T" & plus1_aa == "P" ~ "TP",
      motif_center_aa == "S" & plus1_aa == "F" ~ "SF",
      motif_center_aa == "S" ~ "Other_S",
      motif_center_aa == "T" ~ "Other_T",
      motif_center_aa == "Y" ~ "Y",
      TRUE ~ NA_character_
    ),
    proline_directed = motif_type %in% c("SP", "TP"),
    sf_positive = motif_type == "SF"
  )

# 2. shared quantified sites
pal1_ids <- unique(pal1_background$site_id)
pal5_ids <- unique(pal5_background$site_id)
shared_quantified_ids <- intersect(pal1_ids, pal5_ids)

shared_sites <- site_data %>%
  filter(
    site_id %in% shared_quantified_ids,
    motif_center_aa %in% c("S", "T"),
    !is.na(Pal1_log2FC),
    !is.na(Pal5_log2FC)
  ) %>%
  distinct(site_id, .keep_all = TRUE) %>%
  mutate(
    Pal1_down = `Pal1/Con P value` < 0.05 & Pal1_log2FC < 0,
    Pal5_down = `Pal5/Con P value` < 0.05 & Pal5_log2FC < 0,
    response_class = case_when(
      Pal1_down & Pal5_down ~ "Down_both",
      Pal1_down & !Pal5_down ~ "Pal1_only_down",
      !Pal1_down & Pal5_down ~ "Pal5_only_down",
      TRUE ~ "Neither_down"
    ),
    delta_Pal5_minus_Pal1 = Pal5_log2FC - Pal1_log2FC,
    dose_direction = case_when(
      delta_Pal5_minus_Pal1 < 0 ~ "More_negative_at_Pal5",
      delta_Pal5_minus_Pal1 > 0 ~ "Less_negative_or_more_positive_at_Pal5",
      TRUE ~ "No_change"
    ),
    same_direction = sign(Pal1_log2FC) == sign(Pal5_log2FC)
  )

# 3. motif site summary
motif_site_summary <- shared_sites %>%
  filter(motif_type %in% c("SP", "TP", "SF")) %>%
  group_by(motif_type) %>%
  summarise(
    n_sites = n_distinct(site_id),
    n_proteins = n_distinct(`Protein accession`),
    n_genes = n_distinct(`Gene name`),
    median_Pal1_log2FC = median(Pal1_log2FC, na.rm = TRUE),
    median_Pal5_log2FC = median(Pal5_log2FC, na.rm = TRUE),
    median_delta_Pal5_minus_Pal1 = median(delta_Pal5_minus_Pal1, na.rm = TRUE),
    Pal1_down_sites = sum(Pal1_down, na.rm = TRUE),
    Pal5_down_sites = sum(Pal5_down, na.rm = TRUE),
    down_both = sum(response_class == "Down_both", na.rm = TRUE),
    Pal1_only_down = sum(response_class == "Pal1_only_down", na.rm = TRUE),
    Pal5_only_down = sum(response_class == "Pal5_only_down", na.rm = TRUE),
    same_direction_fraction = mean(same_direction, na.rm = TRUE),
    stronger_at_Pal5_fraction = mean(delta_Pal5_minus_Pal1 < 0, na.rm = TRUE),
    .groups = "drop"
  )

# 4. protein-level motif characterization
protein_motif_summary <- shared_sites %>%
  filter(motif_type %in% c("SP", "TP", "SF")) %>%
  group_by(`Protein accession`, `Gene name`, motif_type) %>%
  summarise(
    n_motif_sites = n_distinct(site_id),
    min_Pal1_log2FC = min(Pal1_log2FC, na.rm = TRUE),
    median_Pal1_log2FC = median(Pal1_log2FC, na.rm = TRUE),
    min_Pal5_log2FC = min(Pal5_log2FC, na.rm = TRUE),
    median_Pal5_log2FC = median(Pal5_log2FC, na.rm = TRUE),
    min_delta = min(delta_Pal5_minus_Pal1, na.rm = TRUE),
    median_delta = median(delta_Pal5_minus_Pal1, na.rm = TRUE),
    any_Pal1_down = any(Pal1_down, na.rm = TRUE),
    any_Pal5_down = any(Pal5_down, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(both_doses_any_down = any_Pal1_down & any_Pal5_down)

protein_motif_membership <- shared_sites %>%
  filter(motif_type %in% c("SP", "TP", "SF")) %>%
  distinct(`Protein accession`, `Gene name`, motif_type) %>%
  mutate(value = TRUE) %>%
  pivot_wider(names_from = motif_type, values_from = value, values_fill = FALSE) %>%
  mutate(
    SP = ifelse(is.na(SP), FALSE, SP),
    TP = ifelse(is.na(TP), FALSE, TP),
    SF = ifelse(is.na(SF), FALSE, SF),
    motif_combination = case_when(
      SP & TP & SF ~ "SP+TP+SF",
      SP & TP & !SF ~ "SP+TP",
      SP & !TP & SF ~ "SP+SF",
      !SP & TP & SF ~ "TP+SF",
      SP & !TP & !SF ~ "SP_only",
      !SP & TP & !SF ~ "TP_only",
      !SP & !TP & SF ~ "SF_only",
      TRUE ~ "Other"
    )
  )

protein_motif_combination_counts <- protein_motif_membership %>%
  count(motif_combination, name = "n_proteins") %>%
  arrange(desc(n_proteins))

# 5. motif continuous comparisons
safe_wilcox <- function(x, y, paired = FALSE) {
  if (paired) {
    ok <- is.finite(x) & is.finite(y)
    x <- x[ok]; y <- y[ok]
    if (length(x) < 3) return(NA_real_)
  } else {
    x <- x[is.finite(x)]
    y <- y[is.finite(y)]
    if (length(x) < 3 || length(y) < 3) return(NA_real_)
  }
  tryCatch(
    wilcox.test(x, y, paired = paired, exact = FALSE)$p.value,
    error = function(e) NA_real_
  )
}

run_motif_distribution_test <- function(data, dose = c("Pal1", "Pal5")) {
  dose <- match.arg(dose)
  fc_col <- if (dose == "Pal1") "Pal1_log2FC" else "Pal5_log2FC"

  categories <- c("SP", "TP", "SF", "SP_TP")

  map_dfr(categories, function(cat) {
    if (cat == "SP") {
      sub <- data %>% filter(motif_center_aa == "S")
      target <- sub$motif_type == "SP"
    } else if (cat == "TP") {
      sub <- data %>% filter(motif_center_aa == "T")
      target <- sub$motif_type == "TP"
    } else if (cat == "SF") {
      sub <- data %>% filter(motif_center_aa == "S")
      target <- sub$motif_type == "SF"
    } else {
      sub <- data %>% filter(motif_center_aa %in% c("S", "T"))
      target <- sub$proline_directed
    }

    x <- sub[[fc_col]][target]
    y <- sub[[fc_col]][!target]

    tibble(
      dose = dose,
      category = cat,
      n_target = sum(is.finite(x)),
      n_other = sum(is.finite(y)),
      median_target = median(x, na.rm = TRUE),
      median_other = median(y, na.rm = TRUE),
      median_difference = median(x, na.rm = TRUE) - median(y, na.rm = TRUE),
      wilcox_p = safe_wilcox(x, y, paired = FALSE)
    )
  }) %>%
    mutate(p_adjust = p.adjust(wilcox_p, method = "BH"))
}

motif_distribution_tests <- bind_rows(
  run_motif_distribution_test(shared_sites, "Pal1"),
  run_motif_distribution_test(shared_sites, "Pal5")
)

# 6. global Pal1 vs Pal5
global_dose_summary <- tibble(
  n_shared_sites = nrow(shared_sites),
  spearman_rho = cor(shared_sites$Pal1_log2FC, shared_sites$Pal5_log2FC,
                     method = "spearman", use = "complete.obs"),
  pearson_r = cor(shared_sites$Pal1_log2FC, shared_sites$Pal5_log2FC,
                  method = "pearson", use = "complete.obs"),
  median_Pal1 = median(shared_sites$Pal1_log2FC, na.rm = TRUE),
  median_Pal5 = median(shared_sites$Pal5_log2FC, na.rm = TRUE),
  median_delta_Pal5_minus_Pal1 = median(shared_sites$delta_Pal5_minus_Pal1, na.rm = TRUE),
  same_direction_fraction = mean(shared_sites$same_direction, na.rm = TRUE),
  more_negative_at_Pal5_fraction = mean(shared_sites$delta_Pal5_minus_Pal1 < 0, na.rm = TRUE),
  paired_wilcox_p = wilcox.test(
    shared_sites$Pal5_log2FC, shared_sites$Pal1_log2FC,
    paired = TRUE, exact = FALSE
  )$p.value
)

response_class_counts <- shared_sites %>%
  count(response_class, name = "n_sites") %>%
  mutate(fraction = n_sites / sum(n_sites))

# 7. motif-specific paired dose comparison
motif_dose_tests <- shared_sites %>%
  filter(motif_type %in% c("SP", "TP", "SF")) %>%
  group_by(motif_type) %>%
  summarise(
    n_sites = n(),
    median_Pal1 = median(Pal1_log2FC, na.rm = TRUE),
    median_Pal5 = median(Pal5_log2FC, na.rm = TRUE),
    median_delta = median(delta_Pal5_minus_Pal1, na.rm = TRUE),
    more_negative_at_Pal5_fraction = mean(delta_Pal5_minus_Pal1 < 0, na.rm = TRUE),
    same_direction_fraction = mean(same_direction, na.rm = TRUE),
    paired_wilcox_p = wilcox.test(
      Pal5_log2FC, Pal1_log2FC, paired = TRUE, exact = FALSE
    )$p.value,
    spearman_rho = cor(
      Pal1_log2FC, Pal5_log2FC,
      method = "spearman", use = "complete.obs"
    ),
    .groups = "drop"
  ) %>%
  mutate(p_adjust = p.adjust(paired_wilcox_p, method = "BH"))

# 8. delta summaries
dose_delta_cutoffs <- c(0.25, 0.5, 1.0)
dose_shift_summary <- map_dfr(dose_delta_cutoffs, function(cut) {
  tibble(
    delta_cutoff = cut,
    strengthened_at_Pal5 = sum(shared_sites$delta_Pal5_minus_Pal1 <= -cut, na.rm = TRUE),
    weakened_at_Pal5 = sum(shared_sites$delta_Pal5_minus_Pal1 >= cut, na.rm = TRUE),
    stable_between_doses = sum(abs(shared_sites$delta_Pal5_minus_Pal1) < cut, na.rm = TRUE)
  )
})

dose_priority_sites <- shared_sites %>%
  mutate(
    abs_delta = abs(delta_Pal5_minus_Pal1),
    dose_priority_class = case_when(
      delta_Pal5_minus_Pal1 <= -1 ~ "Strongly_more_negative_at_Pal5",
      delta_Pal5_minus_Pal1 <= -0.5 ~ "Moderately_more_negative_at_Pal5",
      delta_Pal5_minus_Pal1 >= 1 ~ "Strongly_less_negative_at_Pal5",
      delta_Pal5_minus_Pal1 >= 0.5 ~ "Moderately_less_negative_at_Pal5",
      TRUE ~ "Similar_between_doses"
    )
  ) %>%
  arrange(desc(abs_delta))

# 9. Pal1/Pal5 ratio QC (auxiliary)
pal1_pal5_aux <- site_data %>%
  filter(
    site_id %in% shared_quantified_ids,
    !is.na(`Pal1/Pal5 Ratio`),
    `Pal1/Pal5 Ratio` > 0
  ) %>%
  distinct(site_id, .keep_all = TRUE) %>%
  mutate(
    Pal1_vs_Pal5_log2ratio = log2(`Pal1/Pal5 Ratio`),
    derived_Pal1_minus_Pal5 = Pal1_log2FC - Pal5_log2FC,
    ratio_consistency_difference = Pal1_vs_Pal5_log2ratio - derived_Pal1_minus_Pal5
  )

pal1_pal5_ratio_qc <- pal1_pal5_aux %>%
  summarise(
    n_sites = n(),
    spearman_ratio_vs_derived = cor(
      Pal1_vs_Pal5_log2ratio, derived_Pal1_minus_Pal5,
      method = "spearman", use = "complete.obs"
    ),
    median_abs_difference = median(abs(ratio_consistency_difference), na.rm = TRUE),
    max_abs_difference = max(abs(ratio_consistency_difference), na.rm = TRUE)
  )

# 10. targeted overlap if available
target_motif_overlap <- tibble()
if (exists("target_gene_sets")) {
  split_gene_symbols_r5 <- function(data) {
    data %>%
      mutate(gene_symbol_raw = as.character(`Gene name`)) %>%
      separate_rows(gene_symbol_raw, sep = "\\s*[;,/]\\s*") %>%
      mutate(
        gene_symbol = str_trim(gene_symbol_raw),
        gene_symbol = na_if(gene_symbol, "")
      ) %>%
      filter(!is.na(gene_symbol))
  }

  shared_long <- split_gene_symbols_r5(shared_sites)

  target_motif_overlap <- imap_dfr(target_gene_sets, function(target_genes, category_name) {
    map_dfr(c("SP", "TP", "SF"), function(motif_name) {
      sub <- shared_long %>% filter(motif_type == motif_name)
      target_site_ids <- sub %>%
        filter(gene_symbol %in% target_genes) %>%
        distinct(site_id) %>% pull(site_id)
      target_genes_observed <- sub %>%
        filter(gene_symbol %in% target_genes) %>%
        distinct(gene_symbol) %>% pull(gene_symbol)

      tibble(
        target_set = category_name,
        motif_type = motif_name,
        n_motif_sites = n_distinct(sub$site_id),
        n_target_motif_sites = length(target_site_ids),
        n_motif_genes = n_distinct(sub$gene_symbol),
        n_target_motif_genes = length(target_genes_observed),
        target_motif_site_fraction = ifelse(
          n_distinct(sub$site_id) > 0,
          length(target_site_ids) / n_distinct(sub$site_id),
          NA_real_
        )
      )
    })
  })
}

# 11. top sites
top_motif_sites_pal1 <- shared_sites %>%
  filter(motif_type %in% c("SP", "TP", "SF")) %>%
  group_by(motif_type) %>%
  arrange(Pal1_log2FC, .by_group = TRUE) %>%
  slice_head(n = 30) %>% ungroup()

top_motif_sites_pal5 <- shared_sites %>%
  filter(motif_type %in% c("SP", "TP", "SF")) %>%
  group_by(motif_type) %>%
  arrange(Pal5_log2FC, .by_group = TRUE) %>%
  slice_head(n = 30) %>% ungroup()

top_dose_shifted_motif_sites <- dose_priority_sites %>%
  filter(motif_type %in% c("SP", "TP", "SF")) %>%
  group_by(motif_type) %>%
  arrange(desc(abs_delta), .by_group = TRUE) %>%
  slice_head(n = 30) %>% ungroup()

# 12. plots
p_scatter <- ggplot(shared_sites, aes(x = Pal1_log2FC, y = Pal5_log2FC)) +
  geom_point(alpha = 0.25, size = 1) +
  geom_abline(slope = 1, intercept = 0, linetype = 2) +
  geom_hline(yintercept = 0, linetype = 3) +
  geom_vline(xintercept = 0, linetype = 3) +
  labs(
    title = "Pal1 versus Pal5 phosphosite response",
    subtitle = "Shared quantified S/T phosphosites",
    x = "Pal1 log2FC", y = "Pal5 log2FC"
  ) +
  theme_bw()

ggsave(file.path(r5_figure_dir, "01_Pal1_vs_Pal5_shared_site_scatter.png"),
       p_scatter, width = 7.5, height = 7, dpi = 300)

motif_scatter_df <- shared_sites %>% filter(motif_type %in% c("SP", "TP", "SF"))

p_motif_scatter <- ggplot(motif_scatter_df, aes(x = Pal1_log2FC, y = Pal5_log2FC)) +
  geom_point(alpha = 0.4, size = 1.2) +
  geom_abline(slope = 1, intercept = 0, linetype = 2) +
  facet_wrap(~ motif_type, scales = "free") +
  labs(
    title = "Dose consistency of SP/TP/SF phosphosites",
    x = "Pal1 log2FC", y = "Pal5 log2FC"
  ) +
  theme_bw()

ggsave(file.path(r5_figure_dir, "02_SP_TP_SF_Pal1_vs_Pal5_scatter.png"),
       p_motif_scatter, width = 11, height = 4.5, dpi = 300)

motif_long <- shared_sites %>%
  filter(motif_type %in% c("SP", "TP", "SF")) %>%
  select(site_id, motif_type, Pal1_log2FC, Pal5_log2FC) %>%
  pivot_longer(
    cols = c(Pal1_log2FC, Pal5_log2FC),
    names_to = "dose", values_to = "log2FC"
  ) %>%
  mutate(dose = recode(dose, Pal1_log2FC = "Pal1", Pal5_log2FC = "Pal5"))

p_motif_box <- ggplot(motif_long, aes(x = dose, y = log2FC)) +
  geom_boxplot(outlier.shape = NA) +
  geom_hline(yintercept = 0, linetype = 2) +
  facet_wrap(~ motif_type, scales = "free_y") +
  labs(
    title = "SP/TP/SF phosphosite log2FC distributions",
    x = NULL, y = "log2FC"
  ) +
  theme_bw()

ggsave(file.path(r5_figure_dir, "03_SP_TP_SF_log2FC_boxplots.png"),
       p_motif_box, width = 9, height = 5.5, dpi = 300)

p_delta <- ggplot(motif_scatter_df, aes(x = delta_Pal5_minus_Pal1)) +
  geom_histogram(bins = 60) +
  geom_vline(xintercept = 0, linetype = 2) +
  facet_wrap(~ motif_type, scales = "free_y") +
  labs(
    title = "Dose shift of SP/TP/SF phosphosites",
    subtitle = "Negative values indicate a more negative response at Pal5",
    x = "Pal5 log2FC - Pal1 log2FC",
    y = "Number of phosphosites"
  ) +
  theme_bw()

ggsave(file.path(r5_figure_dir, "04_SP_TP_SF_dose_delta_histograms.png"),
       p_delta, width = 10, height = 5, dpi = 300)

# 13. outputs
write.xlsx(
  list(
    Motif_site_summary = motif_site_summary,
    Protein_motif_summary = protein_motif_summary,
    Protein_motif_membership = protein_motif_membership,
    Protein_motif_combinations = protein_motif_combination_counts,
    Motif_distribution_tests = motif_distribution_tests,
    Global_dose_summary = global_dose_summary,
    Response_class_counts = response_class_counts,
    Motif_dose_tests = motif_dose_tests,
    Dose_shift_summary = dose_shift_summary,
    Pal1_Pal5_ratio_QC = pal1_pal5_ratio_qc,
    Target_motif_overlap = target_motif_overlap,
    Top_motif_sites_Pal1 = top_motif_sites_pal1,
    Top_motif_sites_Pal5 = top_motif_sites_pal5,
    Top_dose_shifted_motif_sites = top_dose_shifted_motif_sites,
    Shared_site_data = shared_sites
  ),
  file = file.path(r5_table_dir, "01_R5_motif_characterization_and_dose_response.xlsx"),
  overwrite = TRUE
)

write_csv(
  dose_priority_sites,
  file.path(r5_table_dir, "02_all_shared_sites_ranked_by_Pal5_minus_Pal1_delta.csv")
)

r5_summary <- bind_rows(
  tibble(
    section = "Global dose",
    metric = c(
      "Shared quantified sites",
      "Spearman Pal1 vs Pal5",
      "Median Pal1 log2FC",
      "Median Pal5 log2FC",
      "Median Pal5-Pal1 delta",
      "Same-direction fraction",
      "More-negative-at-Pal5 fraction",
      "Paired Wilcoxon P"
    ),
    value = as.character(c(
      global_dose_summary$n_shared_sites,
      global_dose_summary$spearman_rho,
      global_dose_summary$median_Pal1,
      global_dose_summary$median_Pal5,
      global_dose_summary$median_delta_Pal5_minus_Pal1,
      global_dose_summary$same_direction_fraction,
      global_dose_summary$more_negative_at_Pal5_fraction,
      global_dose_summary$paired_wilcox_p
    ))
  ),
  motif_dose_tests %>%
    transmute(
      section = paste0("Motif dose: ", motif_type),
      metric = "median_delta_Pal5_minus_Pal1",
      value = as.character(median_delta)
    )
)

write_csv(r5_summary, file.path(r5_table_dir, "03_R5_quick_summary.csv"))

message("\n============================================================")
message("R5.0 completed.")
message("Output directory: ", r5_dir)
message("核心输出：")
message("1) tables/01_R5_motif_characterization_and_dose_response.xlsx")
message("2) tables/02_all_shared_sites_ranked_by_Pal5_minus_Pal1_delta.csv")
message("3) tables/03_R5_quick_summary.csv")
message("优先查看：Motif_site_summary / Motif_dose_tests / Global_dose_summary /")
message("Response_class_counts / Target_motif_overlap / Top_dose_shifted_motif_sites")
message("============================================================\n")
