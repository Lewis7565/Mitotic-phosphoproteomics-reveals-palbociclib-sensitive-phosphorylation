# =============================================================================
# R8. PLK1-related sensitivity analysis
# Questions from supervisor:
#   1) Compare PLK1 substrate-site behavior between Pal1 and Pal5.
#   2) Re-run key SAC / kinetochore / RZZ / chromosome-segregation enrichment
#      after excluding known PLK1 substrate SITES and after excluding known
#      PLK1 substrate PROTEINS.
#
# Run after R1-R6. Required objects:
#   site_data, pal1_background, pal5_background, target_gene_sets, analysis_dir
#
# Exact PLK1 matching uses the same rule as R6:
#   UniProt accession + residue + position.
# =============================================================================

suppressPackageStartupMessages({
  library(tidyverse)
  library(openxlsx)
  library(clusterProfiler)
  library(ReactomePA)
  library(org.Hs.eg.db)
})

required_objects <- c("site_data","pal1_background","pal5_background",
                      "target_gene_sets","analysis_dir")
missing_objects <- required_objects[!vapply(required_objects, exists, logical(1), inherits=TRUE)]
if (length(missing_objects) > 0) {
  stop("Please run R1-R6 first. Missing objects: ", paste(missing_objects, collapse=", "))
}

r8_dir <- file.path(analysis_dir, "R8_PLK1_sensitivity")
table_dir <- file.path(r8_dir, "tables")
figure_dir <- file.path(r8_dir, "figures")
dir.create(table_dir, recursive=TRUE, showWarnings=FALSE)
dir.create(figure_dir, recursive=TRUE, showWarnings=FALSE)

# -----------------------------------------------------------------------------
# 1. Read the same kinase-substrate reference used in R6
# -----------------------------------------------------------------------------
ref_candidates <- c(
  file.path(analysis_dir,"R6_kinase_signature","input_reference","kinase_substrate_reference_R6.csv"),
  file.path(analysis_dir,"R6_kinase_signature_analysis","input_reference","kinase_substrate_reference_R6.csv"),
  file.path(analysis_dir,"input_reference","kinase_substrate_reference_R6.csv")
)
reference_path <- ref_candidates[file.exists(ref_candidates)][1]
if (is.na(reference_path)) {
  stop("Cannot find kinase_substrate_reference_R6.csv. Please edit reference_path manually.")
}

kinase_reference <- read_csv(reference_path, show_col_types=FALSE) %>%
  mutate(
    kinase = str_to_upper(str_trim(kinase)),
    kinase = if_else(kinase %in% c("MPS1","MPS-1"), "TTK", kinase),
    substrate_accession = str_trim(substrate_accession),
    substrate_gene = str_trim(substrate_gene),
    residue = str_to_upper(str_trim(residue)),
    position = as.integer(position)
  ) %>%
  filter(!is.na(substrate_accession), !is.na(position), residue %in% c("S","T","Y"))

plk1_reference <- kinase_reference %>%
  filter(kinase == "PLK1") %>%
  distinct(substrate_accession, substrate_gene, residue, position, .keep_all=TRUE)
if (nrow(plk1_reference) == 0) stop("No PLK1 sites found in the R6 reference.")

# -----------------------------------------------------------------------------
# 2. Exact PLK1 phosphosite matching
# -----------------------------------------------------------------------------
plk1_matches <- site_data %>%
  inner_join(
    plk1_reference,
    by=c("protein_accession_clean"="substrate_accession",
         "Position"="position",
         "Amino acid"="residue"),
    suffix=c("","_ref")
  ) %>%
  distinct(site_id, .keep_all=TRUE)

plk1_site_ids <- unique(plk1_matches$site_id)
plk1_accessions <- unique(plk1_reference$substrate_accession)

# -----------------------------------------------------------------------------
# 3. PLK1 signature: Pal1 versus Pal5
# -----------------------------------------------------------------------------
plk1_paired <- plk1_matches %>%
  filter(!is.na(Pal1_log2FC), !is.na(Pal5_log2FC)) %>%
  mutate(
    Pal5_minus_Pal1 = Pal5_log2FC - Pal1_log2FC,
    Pal5_more_negative = Pal5_log2FC < Pal1_log2FC
  )

plk1_dose_summary <- tibble(
  n_reference_sites = nrow(plk1_reference),
  n_detected_sites = nrow(plk1_matches),
  n_paired_sites = nrow(plk1_paired),
  median_Pal1 = median(plk1_paired$Pal1_log2FC, na.rm=TRUE),
  median_Pal5 = median(plk1_paired$Pal5_log2FC, na.rm=TRUE),
  median_delta_Pal5_minus_Pal1 = median(plk1_paired$Pal5_minus_Pal1, na.rm=TRUE),
  fraction_Pal5_more_negative = mean(plk1_paired$Pal5_more_negative, na.rm=TRUE),
  spearman_Pal1_Pal5 = suppressWarnings(cor(plk1_paired$Pal1_log2FC,
                                            plk1_paired$Pal5_log2FC,
                                            method="spearman",
                                            use="complete.obs")),
  paired_wilcox_two_sided_p = if (nrow(plk1_paired)>=3)
    wilcox.test(plk1_paired$Pal5_log2FC, plk1_paired$Pal1_log2FC,
                paired=TRUE, exact=FALSE)$p.value else NA_real_,
  paired_wilcox_Pal5_less_p = if (nrow(plk1_paired)>=3)
    wilcox.test(plk1_paired$Pal5_log2FC, plk1_paired$Pal1_log2FC,
                paired=TRUE, alternative="less", exact=FALSE)$p.value else NA_real_
)

plk1_paired_table <- plk1_paired %>%
  transmute(
    site_id,
    substrate_gene = coalesce(
      as.character(substrate_gene),
      as.character(`Gene name`)
    ),
    protein_accession = protein_accession_clean,
    residue = `Amino acid`,
    position = Position,
    motif_type,
    motif_sequence_15mer,
    localization_probability = `Localization probability`,
    Pal1_log2FC,
    Pal1_p_value = `Pal1/Con P value`,
    Pal5_log2FC,
    Pal5_p_value = `Pal5/Con P value`,
    Pal5_minus_Pal1,
    Pal5_more_negative
  ) %>%
  arrange(Pal5_minus_Pal1)

# paired plot
if (nrow(plk1_paired) > 0) {
  pp <- plk1_paired %>%
    select(site_id, Pal1_log2FC, Pal5_log2FC) %>%
    pivot_longer(c(Pal1_log2FC,Pal5_log2FC), names_to="dose", values_to="log2FC") %>%
    mutate(dose=recode(dose, Pal1_log2FC="Pal1", Pal5_log2FC="Pal5"),
           dose=factor(dose, levels=c("Pal1","Pal5"))) %>%
    ggplot(aes(dose, log2FC, group=site_id)) +
    geom_hline(yintercept=0, linetype=2) +
    geom_line(alpha=.3) + geom_point(alpha=.7, size=1.7) +
    stat_summary(aes(group=1), fun=median, geom="line", linewidth=1.2) +
    stat_summary(aes(group=1), fun=median, geom="point", size=3) +
    labs(title="Known PLK1 substrate phosphosites: Pal1 versus Pal5",
         x=NULL, y="Protein-normalized phosphosite log2FC") + theme_bw()
  ggsave(file.path(figure_dir,"01_PLK1_Pal1_vs_Pal5_paired.png"), pp,
         width=7,height=6,dpi=300)
}

# -----------------------------------------------------------------------------
# 4. Helpers for PLK1-exclusion sensitivity
# -----------------------------------------------------------------------------
cutoffs <- c("lt0"=0, "lt_m0.5"=-0.5, "lt_m0.6"=-0.6, "lt_m1.0"=-1.0)

split_gene_symbols_r8 <- function(data) {
  data %>% mutate(gene_symbol_raw=`Gene name`) %>%
    separate_rows(gene_symbol_raw, sep="[;,/| ]+") %>%
    mutate(gene_symbol=str_trim(gene_symbol_raw)) %>%
    filter(!is.na(gene_symbol), gene_symbol!="")
}

apply_exclusion <- function(data, mode) {
  if (mode == "Baseline") return(data)
  if (mode == "Exclude_PLK1_sites") return(data %>% filter(!site_id %in% plk1_site_ids))
  if (mode == "Exclude_PLK1_proteins") return(data %>% filter(!protein_accession_clean %in% plk1_accessions))
  stop("Unknown exclusion mode")
}

build_fg <- function(bg, fc_name, p_name, cutoff) {
  bg %>% filter(!is.na(.data[[fc_name]]), !is.na(.data[[p_name]]),
                .data[[p_name]] < 0.05, .data[[fc_name]] < cutoff)
}

fisher_one <- function(foreground_ids, background_ids, target_ids,
                       category, level, dose, cutoff, mode) {
  background_ids <- unique(background_ids)
  foreground_ids <- intersect(unique(foreground_ids), background_ids)
  target_ids <- intersect(unique(target_ids), background_ids)
  a <- length(intersect(foreground_ids,target_ids))
  b <- length(setdiff(foreground_ids,target_ids))
  c <- length(setdiff(target_ids,foreground_ids))
  d <- length(setdiff(background_ids, union(foreground_ids,target_ids)))
  ft <- fisher.test(matrix(c(a,b,c,d), nrow=2, byrow=TRUE))
  tibble(dose=dose, cutoff=cutoff, exclusion_mode=mode,
         analysis_level=level, category=category,
         foreground_n=length(foreground_ids), background_n=length(background_ids),
         target_in_foreground=a, target_in_background=length(target_ids),
         odds_ratio=unname(ft$estimate), conf_low=ft$conf.int[1],
         conf_high=ft$conf.int[2], p_value=ft$p.value)
}

run_targeted <- function(background_data, fc_name, p_name, dose) {
  out <- list(); k <- 1
  for (cutoff_name in names(cutoffs)) {
    for (mode in c("Baseline","Exclude_PLK1_sites","Exclude_PLK1_proteins")) {
      bg <- apply_exclusion(background_data, mode)
      fg <- build_fg(bg, fc_name, p_name, cutoffs[[cutoff_name]])
      bg_long <- split_gene_symbols_r8(bg)
      fg_long <- split_gene_symbols_r8(fg)
      bg_sites <- unique(bg$site_id); fg_sites <- unique(fg$site_id)
      bg_genes <- unique(bg_long$gene_symbol); fg_genes <- unique(fg_long$gene_symbol)

      for (cat_name in names(target_gene_sets)) {
        genes <- target_gene_sets[[cat_name]]
        target_sites <- bg_long %>% filter(gene_symbol %in% genes) %>%
          distinct(site_id) %>% pull(site_id)
        out[[k]] <- fisher_one(fg_sites,bg_sites,target_sites,cat_name,
                               "Phosphosite",dose,cutoff_name,mode); k <- k+1
        out[[k]] <- fisher_one(fg_genes,bg_genes,genes,cat_name,
                               "Protein/gene",dose,cutoff_name,mode); k <- k+1
      }
    }
  }
  bind_rows(out) %>%
    group_by(dose,cutoff,exclusion_mode,analysis_level) %>%
    mutate(p_adjust=p.adjust(p_value, method="BH")) %>% ungroup()
}

targeted_all <- bind_rows(
  run_targeted(pal1_background,"Pal1_log2FC","Pal1/Con P value","Pal1"),
  run_targeted(pal5_background,"Pal5_log2FC","Pal5/Con P value","Pal5")
)

targeted_stability <- targeted_all %>%
  group_by(dose,category,analysis_level,exclusion_mode) %>%
  summarise(
    n_thresholds=n(),
    thresholds_OR_gt1=sum(odds_ratio>1,na.rm=TRUE),
    thresholds_FDR_lt_005=sum(p_adjust<0.05,na.rm=TRUE),
    thresholds_FDR_lt_020=sum(p_adjust<0.20,na.rm=TRUE),
    median_OR=median(odds_ratio,na.rm=TRUE),
    best_FDR=min(p_adjust,na.rm=TRUE),
    .groups="drop"
  )

targeted_comparison <- targeted_all %>%
  select(dose,cutoff,analysis_level,category,exclusion_mode,
         odds_ratio,p_adjust,foreground_n,target_in_foreground) %>%
  pivot_wider(names_from=exclusion_mode,
              values_from=c(odds_ratio,p_adjust,foreground_n,target_in_foreground)) %>%
  mutate(
    OR_ratio_site_exclusion = odds_ratio_Exclude_PLK1_sites / odds_ratio_Baseline,
    OR_ratio_protein_exclusion = odds_ratio_Exclude_PLK1_proteins / odds_ratio_Baseline,
    remains_OR_gt1_site = odds_ratio_Exclude_PLK1_sites > 1,
    remains_OR_gt1_protein = odds_ratio_Exclude_PLK1_proteins > 1
  )

# -----------------------------------------------------------------------------
# 5. Optional GO / Reactome rerun after PLK1 exclusion
#    (full ORA, then retain mitosis-related terms for compact review)
# -----------------------------------------------------------------------------
map_entrez <- function(genes) {
  genes <- unique(genes[!is.na(genes) & genes!=""])
  if (length(genes)==0) return(character())
  suppressMessages(bitr(genes, fromType="SYMBOL", toType="ENTREZID",
                        OrgDb=org.Hs.eg.db)) %>% distinct(ENTREZID) %>% pull(ENTREZID)
}

safe_df <- function(x) {
  if (is.null(x)) return(tibble())
  tryCatch(as_tibble(as.data.frame(x)), error=function(e) tibble())
}

run_ora_one <- function(background_data, fc_name, p_name, dose, cutoff_name, mode) {
  bg <- apply_exclusion(background_data, mode)
  fg <- build_fg(bg, fc_name, p_name, cutoffs[[cutoff_name]])
  bg_genes <- split_gene_symbols_r8(bg) %>% distinct(gene_symbol) %>% pull(gene_symbol)
  fg_genes <- split_gene_symbols_r8(fg) %>% distinct(gene_symbol) %>% pull(gene_symbol)
  bg_e <- map_entrez(bg_genes); fg_e <- map_entrez(fg_genes)
  if (length(fg_e)<3 || length(bg_e)<10) return(tibble())

  bp <- tryCatch(enrichGO(gene=fg_e, universe=bg_e, OrgDb=org.Hs.eg.db,
                          keyType="ENTREZID", ont="BP", pvalueCutoff=1,
                          qvalueCutoff=1, pAdjustMethod="BH", readable=TRUE),
                 error=function(e) NULL)
  cc <- tryCatch(enrichGO(gene=fg_e, universe=bg_e, OrgDb=org.Hs.eg.db,
                          keyType="ENTREZID", ont="CC", pvalueCutoff=1,
                          qvalueCutoff=1, pAdjustMethod="BH", readable=TRUE),
                 error=function(e) NULL)
  re <- tryCatch(enrichPathway(gene=fg_e, universe=bg_e, organism="human",
                               pvalueCutoff=1, pAdjustMethod="BH", readable=TRUE),
                 error=function(e) NULL)
  bind_rows(safe_df(bp)%>%mutate(database="GO_BP"),
            safe_df(cc)%>%mutate(database="GO_CC"),
            safe_df(re)%>%mutate(database="Reactome")) %>%
    mutate(dose=dose, cutoff=cutoff_name, exclusion_mode=mode)
}

ora_list <- list(); j <- 1
for (dose in c("Pal1","Pal5")) {
  bg <- if (dose=="Pal1") pal1_background else pal5_background
  fc <- if (dose=="Pal1") "Pal1_log2FC" else "Pal5_log2FC"
  pv <- if (dose=="Pal1") "Pal1/Con P value" else "Pal5/Con P value"
  for (co in names(cutoffs)) {
    for (mode in c("Baseline","Exclude_PLK1_sites","Exclude_PLK1_proteins")) {
      ora_list[[j]] <- run_ora_one(bg,fc,pv,dose,co,mode); j <- j+1
    }
  }
}
ora_all <- bind_rows(ora_list)

mitotic_regex <- "mitotic|mitosis|kinetochore|centromer|spindle|chromatid|chromosome segregation|checkpoint|prometaphase|metaphase"
ora_mitotic <- ora_all %>%
  filter(str_detect(str_to_lower(Description), mitotic_regex)) %>%
  arrange(dose,cutoff,exclusion_mode,p.adjust)

ora_stability <- ora_mitotic %>%
  group_by(dose,database,ID,Description,exclusion_mode) %>%
  summarise(
    n_thresholds=n_distinct(cutoff),
    thresholds_FDR_lt_005=sum(p.adjust<0.05,na.rm=TRUE),
    thresholds_FDR_lt_020=sum(p.adjust<0.20,na.rm=TRUE),
    best_FDR=min(p.adjust,na.rm=TRUE),
    .groups="drop"
  )

# -----------------------------------------------------------------------------
# 6. Removal summary and plot
# -----------------------------------------------------------------------------
exclusion_summary <- tibble(
  item=c("PLK1 reference sites","Exact PLK1 sites detected",
         "Pal1 background before","Pal1 after site exclusion","Pal1 after protein exclusion",
         "Pal5 background before","Pal5 after site exclusion","Pal5 after protein exclusion"),
  value=c(nrow(plk1_reference),length(plk1_site_ids),
          nrow(pal1_background),nrow(apply_exclusion(pal1_background,"Exclude_PLK1_sites")),
          nrow(apply_exclusion(pal1_background,"Exclude_PLK1_proteins")),
          nrow(pal5_background),nrow(apply_exclusion(pal5_background,"Exclude_PLK1_sites")),
          nrow(apply_exclusion(pal5_background,"Exclude_PLK1_proteins")))
)

p_target <- targeted_all %>%
  filter(analysis_level=="Protein/gene") %>%
  ggplot(aes(odds_ratio, category, shape=exclusion_mode)) +
  geom_vline(xintercept=1, linetype=2) +
  geom_point(size=2, position=position_dodge(width=.45)) +
  scale_x_log10() + facet_grid(dose~cutoff, scales="free_y") +
  labs(title="Targeted mitotic enrichment after PLK1 exclusion",
       x="Odds ratio (log10 scale)", y=NULL) + theme_bw() +
  theme(legend.position="bottom")
ggsave(file.path(figure_dir,"02_targeted_enrichment_PLK1_exclusion.png"),
       p_target,width=12,height=8.5,dpi=300)

# -----------------------------------------------------------------------------
# 7. Export
# -----------------------------------------------------------------------------
output_xlsx <- file.path(table_dir,"01_R8_PLK1_sensitivity_analysis.xlsx")
write.xlsx(
  list(
    PLK1_reference=plk1_reference,
    PLK1_exact_matches=plk1_matches,
    PLK1_dose_summary=plk1_dose_summary,
    PLK1_paired_sites=plk1_paired_table,
    Exclusion_summary=exclusion_summary,
    Targeted_all=targeted_all,
    Targeted_stability=targeted_stability,
    Targeted_baseline_comparison=targeted_comparison,
    GO_Reactome_mitotic=ora_mitotic,
    GO_Reactome_stability=ora_stability
  ),
  file=output_xlsx,
  overwrite=TRUE
)

cat("\nR8 completed.\n")
print(plk1_dose_summary)
cat("\nMain output:\n", output_xlsx, "\n")
cat("\nInterpretation:\n")
cat("- If Pal5 median PLK1 delta is negative and the one-sided paired P is small, Pal5 shows a stronger PLK1-associated downward shift.\n")
cat("- If RZZ/SAC/kinetochore ORs remain >1 after PLK1-site exclusion, those signals are not driven solely by annotated PLK1 phosphosites.\n")
cat("- Protein-level exclusion is more conservative; weakening there can reflect removal of entire large mitotic proteins, not necessarily PLK1 causality.\n")
cat("- This sensitivity analysis does not prove direct PLK1 inhibition by palbociclib.\n")
