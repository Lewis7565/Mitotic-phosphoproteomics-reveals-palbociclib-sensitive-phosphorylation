options(stringsAsFactors = FALSE)

input_file <- file.path("tables", "01_site_count_adjusted_GO_Reactome_all.csv")
output_detail <- file.path("tables", "07_teacher_priority_pathways_all_thresholds.csv")
output_summary <- file.path("tables", "08_teacher_priority_pathway_stability.csv")

x <- read.csv(input_file, check.names = FALSE)

priority_terms <- c(
  "GO:0000775",       # chromosome, centromeric region
  "GO:0000776",       # kinetochore
  "GO:0090307",       # mitotic spindle assembly
  "GO:0007052",       # mitotic spindle organization
  "GO:0071173",       # spindle assembly checkpoint signaling
  "R-HSA-68877",      # Mitotic Prometaphase
  "R-HSA-69618",      # Mitotic Spindle Checkpoint
  "R-HSA-2468052",    # Establishment of Sister Chromatid Cohesion
  "R-HSA-2500257",    # Resolution of Sister Chromatid Cohesion
  "R-HSA-9648025"     # EML4 and NUDC in mitotic spindle formation
)

d <- x[x$pathway_id %in% priority_terms, ]
d <- d[order(d$description, d$dose, d$cutoff), ]
write.csv(d, output_detail, row.names = FALSE, na = "")

groups <- split(d, interaction(d$dose, d$database, d$pathway_id, drop = TRUE))
s <- do.call(rbind, lapply(groups, function(z) {
  data.frame(
    dose = z$dose[1],
    database = z$database[1],
    pathway_id = z$pathway_id[1],
    description = z$description[1],
    thresholds_tested = nrow(z),
    thresholds_OR_gt_1 = sum(z$adjusted_OR > 1, na.rm = TRUE),
    thresholds_nominal_P_lt_005 = sum(z$P < 0.05, na.rm = TRUE),
    thresholds_FDR_lt_020 = sum(z$FDR < 0.20, na.rm = TRUE),
    thresholds_FDR_lt_005 = sum(z$FDR < 0.05, na.rm = TRUE),
    median_adjusted_OR = median(z$adjusted_OR, na.rm = TRUE),
    best_nominal_P = min(z$P, na.rm = TRUE),
    best_global_FDR = min(z$FDR, na.rm = TRUE)
  )
}))
s <- s[order(s$description, s$dose), ]
write.csv(s, output_summary, row.names = FALSE, na = "")

# Manuscript-ready compact view of the teacher-priority pathways.
if (requireNamespace("ggplot2", quietly = TRUE) && requireNamespace("scales", quietly = TRUE)) {
  library(ggplot2)

  dir.create("figures", showWarnings = FALSE)
  dir.create("source_data", showWarnings = FALSE)
  write.csv(d, file.path("source_data", "figure_03_priority_heatmap_source_data.csv"), row.names = FALSE, na = "")

  term_labels <- c(
    "GO:0000775" = "Centromeric region",
    "GO:0000776" = "Kinetochore",
    "GO:0090307" = "Mitotic spindle assembly",
    "GO:0007052" = "Mitotic spindle organization",
    "GO:0071173" = "Spindle checkpoint signaling",
    "R-HSA-68877" = "Mitotic Prometaphase",
    "R-HSA-69618" = "Mitotic Spindle Checkpoint",
    "R-HSA-2468052" = "Establishment of Sister Chromatid Cohesion",
    "R-HSA-2500257" = "Resolution of Sister Chromatid Cohesion",
    "R-HSA-9648025" = "EML4/NUDC spindle formation"
  )
  cutoff_labels <- c(
    "lt0" = "log2FC < 0",
    "lt_m0.5" = "log2FC < -0.5",
    "lt_m0.6" = "log2FC < -0.6",
    "lt_m1.0" = "log2FC < -1.0"
  )
  d$term_label <- unname(term_labels[d$pathway_id])
  d$term_label <- factor(d$term_label, levels = rev(unname(term_labels)))
  d$cutoff_label <- factor(unname(cutoff_labels[d$cutoff]), levels = unname(cutoff_labels))
  d$neg_log10_FDR <- -log10(pmax(d$FDR, .Machine$double.xmin))
  d$OR_label <- sprintf("%.2f", d$adjusted_OR)

  p3 <- ggplot(d, aes(x = cutoff_label, y = term_label, fill = neg_log10_FDR)) +
    geom_tile(color = "white", linewidth = 0.5) +
    geom_text(aes(label = OR_label), size = 3.0) +
    facet_wrap(~dose, ncol = 2) +
    scale_fill_viridis_c(
      option = "C",
      name = expression(-log[10]("global BH FDR")),
      limits = c(0, max(1.31, max(d$neg_log10_FDR, na.rm = TRUE)))
    ) +
    labs(
      x = "Foreground definition",
      y = NULL,
      title = "Site-count-adjusted teacher-priority pathways",
      subtitle = "Cell labels are adjusted OR; no displayed term reached global FDR < 0.05"
    ) +
    theme_bw(base_size = 11) +
    theme(
      strip.text = element_text(face = "bold"),
      axis.text.x = element_text(angle = 30, hjust = 1),
      panel.grid = element_blank(),
      legend.position = "bottom",
      plot.margin = margin(10, 18, 10, 10)
    )

  for (ext in c("svg", "pdf", "png")) {
    ggsave(
      file.path("figures", paste0("03_teacher_priority_pathway_heatmap.", ext)),
      p3, width = 12, height = 7.5, dpi = 320
    )
  }

  # Regenerate the compact Firth forest plot with safer axis padding.
  f <- read.csv(file.path("tables", "03_RZZ_SAC_Firth_logistic.csv"), check.names = FALSE)
  f$cutoff_label <- factor(unname(cutoff_labels[f$cutoff]), levels = unname(cutoff_labels))
  f$target_label <- ifelse(f$target == "RZZ_fibrous_corona_core", "RZZ / fibrous corona", "SAC")
  p2 <- ggplot(f, aes(x = adjusted_OR, y = cutoff_label, color = target_label)) +
    geom_vline(xintercept = 1, linetype = 2, color = "grey55") +
    geom_errorbar(
      aes(xmin = OR_conf_low, xmax = OR_conf_high), orientation = "y",
      width = 0.12, position = position_dodge(width = 0.4), linewidth = 0.5
    ) +
    geom_point(position = position_dodge(width = 0.4), size = 2.7) +
    scale_x_log10(
      limits = c(0.003, 100), breaks = c(0.01, 0.1, 1, 10, 100),
      labels = scales::label_number(), expand = expansion(mult = c(0.03, 0.08))
    ) +
    facet_wrap(~dose) +
    scale_color_manual(values = c("RZZ / fibrous corona" = "#7B3294", "SAC" = "#008837")) +
    labs(
      x = "Firth site-count-adjusted odds ratio (log scale)",
      y = "Foreground definition", color = NULL,
      title = "Firth logistic sensitivity analysis for RZZ and SAC"
    ) +
    theme_bw(base_size = 11) +
    theme(
      strip.text = element_text(face = "bold"), panel.grid.minor = element_blank(),
      legend.position = "bottom", plot.margin = margin(10, 22, 10, 10)
    )
  for (ext in c("svg", "pdf", "png")) {
    ggsave(file.path("figures", paste0("02_RZZ_SAC_Firth_forest.", ext)), p2,
           width = 10, height = 5.8, dpi = 320)
  }
}

cat("Priority detail rows:", nrow(d), "\n")
cat("Priority summary rows:", nrow(s), "\n")
