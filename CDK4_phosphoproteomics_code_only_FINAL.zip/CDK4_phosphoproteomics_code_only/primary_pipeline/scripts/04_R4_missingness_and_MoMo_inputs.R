# ============================================================================
# R4.0 — Missing-phosphosite motif bias + MoMo threshold input preparation
# ============================================================================
# 建议运行顺序：
#   R1.0（原始数据/FASTA/15-mer/背景与原始前景）
#   -> R2.0（GO/Reactome/GSEA/targeted follow-up）
#   -> R3.0（foreground-threshold sensitivity + cutoff-independent analysis）
#   -> 本脚本 R4.0
#
# 本脚本对应导师 foreground-robustness 阶段剩余的两个重点：
# 1) Missing phosphosite / detection-pattern motif bias
# 2) MoMo across foreground thresholds 的标准化输入文件与 QC
#
# 注意：
# - Missingness 主分析使用原始 Intensity Con/Pal1/Pal5 三重复列。
# - “detected”主定义：3 个重复中至少 1 个 intensity > 0。
# - 同时额外做 stricter sensitivity：至少 2/3 重复检测到。
# - MoMo 本脚本负责生成输入与 QC；真正的 MoMo motif discovery 仍在
#   MEME Suite / MoMo 中运行，避免擅自假定你本机 MoMo 命令参数。
# ============================================================================

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(stringr)
  library(purrr)
  library(tibble)
  library(ggplot2)
  library(readr)
  library(openxlsx)
  library(forcats)
})

# ----------------------------------------------------------------------------
# 0. 输入检查
# ----------------------------------------------------------------------------
required_objects_r4 <- c(
  "site_data",
  "pal1_background",
  "pal5_background"
)

missing_objects_r4 <- required_objects_r4[
  !vapply(required_objects_r4, exists, logical(1), inherits = TRUE)
]

if (length(missing_objects_r4) > 0) {
  stop(
    "请先完整运行前面的 R1/R2/R3。缺少对象：",
    paste(missing_objects_r4, collapse = ", ")
  )
}

required_cols_r4 <- c(
  "site_id",
  "motif_sequence_15mer",
  "motif_center_aa",
  "motif_type",
  "proline_directed",
  "sf_positive",
  "Pal1_log2FC",
  "Pal5_log2FC",
  "Pal1/Con P value",
  "Pal5/Con P value",
  "Intensity Con_1",
  "Intensity Con_2",
  "Intensity Con_3",
  "Intensity Pal1_1",
  "Intensity Pal1_2",
  "Intensity Pal1_3",
  "Intensity Pal5_1",
  "Intensity Pal5_2",
  "Intensity Pal5_3"
)

missing_cols_r4 <- setdiff(required_cols_r4, colnames(site_data))

if (length(missing_cols_r4) > 0) {
  stop(
    "site_data 缺少以下 R4.0 所需列：",
    paste(missing_cols_r4, collapse = ", ")
  )
}

# 如果 analysis_dir / sensitivity_dir 没在当前环境，安全补建。
if (!exists("analysis_dir")) {
  analysis_dir <- file.path(getwd(), "phosphoproteomics_followup_analysis")
}

r4_dir <- file.path(analysis_dir, "R4_missingness_and_MoMo")
r4_table_dir <- file.path(r4_dir, "tables")
r4_figure_dir <- file.path(r4_dir, "figures")
r4_momo_dir <- file.path(r4_dir, "MoMo_inputs")

dir.create(r4_table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(r4_figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(r4_momo_dir, recursive = TRUE, showWarnings = FALSE)

thresholds <- c(0, -0.5, -0.6, -1.0)
foreground_p_cutoff <- 0.05

threshold_label <- function(x) {
  paste0(
    "log2FC_lt_",
    ifelse(
      x == 0,
      "0",
      str_replace(as.character(abs(x)), "\\.", "p")
    )
  )
}

# ----------------------------------------------------------------------------
# 1. 确保 motif 分类一致
# ----------------------------------------------------------------------------
site_data <- site_data %>%
  mutate(
    plus1_aa = substr(motif_sequence_15mer, 9, 9),
    motif_type = case_when(
      motif_center_aa == "S" & plus1_aa == "P" ~ "SP",
      motif_center_aa == "T" & plus1_aa == "P" ~ "TP",
      motif_center_aa == "S" & plus1_aa == "F" ~ "SF",
      motif_center_aa == "S" ~ "Other_S",
      motif_center_aa == "T" ~ "Other_T",
      motif_center_aa == "Y" ~ "Y",
      TRUE ~ NA_character_
    ),
    proline_directed = motif_type %in% c("SP", "TP"),
    sf_positive = motif_type == "SF"
  )

# ----------------------------------------------------------------------------
# 2. Missingness：condition-level detection
# ----------------------------------------------------------------------------
control_intensity_cols <- c(
  "Intensity Con_1",
  "Intensity Con_2",
  "Intensity Con_3"
)

pal1_intensity_cols <- c(
  "Intensity Pal1_1",
  "Intensity Pal1_2",
  "Intensity Pal1_3"
)

pal5_intensity_cols <- c(
  "Intensity Pal5_1",
  "Intensity Pal5_2",
  "Intensity Pal5_3"
)

count_detected_replicates <- function(df, cols) {
  mat <- as.data.frame(df[, cols, drop = FALSE])

  mat[] <- lapply(
    mat,
    function(x) suppressWarnings(as.numeric(x))
  )

  rowSums(!is.na(mat) & mat > 0)
}

build_presence_table <- function(data, min_reps = 1) {
  out <- data %>%
    filter(
      !is.na(site_id),
      !is.na(motif_sequence_15mer),
      motif_center_aa %in% c("S", "T")
    ) %>%
    distinct(site_id, .keep_all = TRUE)

  n_con <- count_detected_replicates(out, control_intensity_cols)
  n_pal1 <- count_detected_replicates(out, pal1_intensity_cols)
  n_pal5 <- count_detected_replicates(out, pal5_intensity_cols)

  out %>%
    mutate(
      n_detected_control = n_con,
      n_detected_pal1 = n_pal1,
      n_detected_pal5 = n_pal5,

      detected_control = n_detected_control >= min_reps,
      detected_pal1 = n_detected_pal1 >= min_reps,
      detected_pal5 = n_detected_pal5 >= min_reps,

      detection_pattern = paste0(
        if_else(detected_control, "C", "-"),
        if_else(detected_pal1, "1", "-"),
        if_else(detected_pal5, "5", "-")
      ),

      missingness_group = case_when(
        detected_control & detected_pal1 & detected_pal5 ~ "Detected_all",
        detected_control & !detected_pal1 & !detected_pal5 ~ "Control_only",
        !detected_control & detected_pal1 & !detected_pal5 ~ "Pal1_only",
        !detected_control & !detected_pal1 & detected_pal5 ~ "Pal5_only",
        detected_control & !detected_pal1 & detected_pal5 ~ "Pal1_missing",
        detected_control & detected_pal1 & !detected_pal5 ~ "Pal5_missing",
        !detected_control & detected_pal1 & detected_pal5 ~ "Control_missing",
        TRUE ~ "None_detected"
      )
    )
}

presence_any <- build_presence_table(site_data, min_reps = 1)
presence_2of3 <- build_presence_table(site_data, min_reps = 2)

# ----------------------------------------------------------------------------
# 3. Missingness：描述统计
# ----------------------------------------------------------------------------
summarise_detection_patterns <- function(df, definition_label) {
  df %>%
    count(
      missingness_group,
      detection_pattern,
      name = "n_sites"
    ) %>%
    mutate(
      definition = definition_label,
      fraction_all_sites = n_sites / sum(n_sites)
    ) %>%
    arrange(desc(n_sites))
}

presence_summary <- bind_rows(
  summarise_detection_patterns(
    presence_any,
    "Detected if >=1/3 replicates have intensity > 0"
  ),
  summarise_detection_patterns(
    presence_2of3,
    "Detected if >=2/3 replicates have intensity > 0"
  )
)

# 每种 missingness group 的 SP/TP/SF 构成。
summarise_motif_composition <- function(df, definition_label) {
  df %>%
    mutate(
      motif_display = case_when(
        motif_type == "SP" ~ "SP",
        motif_type == "TP" ~ "TP",
        motif_type == "SF" ~ "SF",
        motif_center_aa == "S" ~ "Other_S",
        motif_center_aa == "T" ~ "Other_T",
        TRUE ~ "Other"
      )
    ) %>%
    count(
      missingness_group,
      motif_display,
      name = "n"
    ) %>%
    group_by(missingness_group) %>%
    mutate(
      fraction_within_group = n / sum(n)
    ) %>%
    ungroup() %>%
    mutate(definition = definition_label)
}

motif_composition <- bind_rows(
  summarise_motif_composition(
    presence_any,
    "Detected if >=1/3 replicates have intensity > 0"
  ),
  summarise_motif_composition(
    presence_2of3,
    "Detected if >=2/3 replicates have intensity > 0"
  )
)

# ----------------------------------------------------------------------------
# 4. Missingness motif Fisher：每类 vs Detected_all
# ----------------------------------------------------------------------------
run_missingness_motif_fisher <- function(
    df,
    group_name,
    reference_name = "Detected_all",
    definition_label
) {

  test_one <- function(motif_name) {

    if (motif_name == "SP") {
      sub <- df %>%
        filter(motif_center_aa == "S")
      target <- sub$motif_type == "SP"
      comparison <- "SP vs other S"

    } else if (motif_name == "TP") {
      sub <- df %>%
        filter(motif_center_aa == "T")
      target <- sub$motif_type == "TP"
      comparison <- "TP vs other T"

    } else if (motif_name == "SF") {
      sub <- df %>%
        filter(motif_center_aa == "S")
      target <- sub$motif_type == "SF"
      comparison <- "SF vs other S"

    } else if (motif_name == "SP_TP") {
      sub <- df %>%
        filter(motif_center_aa %in% c("S", "T"))
      target <- sub$proline_directed
      comparison <- "SP+TP vs other S/T"

    } else {
      stop("未知 motif：", motif_name)
    }

    grp <- sub$missingness_group == group_name
    ref <- sub$missingness_group == reference_name

    a <- sum(grp & target, na.rm = TRUE)
    b <- sum(grp & !target, na.rm = TRUE)
    c <- sum(ref & target, na.rm = TRUE)
    d <- sum(ref & !target, na.rm = TRUE)

    if ((a + b) == 0 || (c + d) == 0) {
      return(
        tibble(
          definition = definition_label,
          missingness_group = group_name,
          reference_group = reference_name,
          category = motif_name,
          comparison = comparison,
          group_target = a,
          group_other = b,
          reference_target = c,
          reference_other = d,
          odds_ratio = NA_real_,
          conf_low = NA_real_,
          conf_high = NA_real_,
          p_value = NA_real_
        )
      )
    }

    ft <- fisher.test(
      matrix(
        c(a, b, c, d),
        nrow = 2,
        byrow = TRUE
      )
    )

    tibble(
      definition = definition_label,
      missingness_group = group_name,
      reference_group = reference_name,
      category = motif_name,
      comparison = comparison,
      group_target = a,
      group_other = b,
      reference_target = c,
      reference_other = d,
      group_fraction = a / (a + b),
      reference_fraction = c / (c + d),
      odds_ratio = unname(ft$estimate),
      conf_low = ft$conf.int[1],
      conf_high = ft$conf.int[2],
      p_value = ft$p.value
    )
  }

  map_dfr(
    c("SP", "TP", "SF", "SP_TP"),
    test_one
  )
}

groups_to_test <- c(
  "Control_only",
  "Pal1_only",
  "Pal5_only",
  "Pal1_missing",
  "Pal5_missing",
  "Control_missing"
)

missingness_fisher_any <- map_dfr(
  groups_to_test,
  ~ run_missingness_motif_fisher(
    presence_any,
    group_name = .x,
    reference_name = "Detected_all",
    definition_label = ">=1/3 replicates"
  )
) %>%
  group_by(category) %>%
  mutate(p_adjust = p.adjust(p_value, method = "BH")) %>%
  ungroup()

missingness_fisher_2of3 <- map_dfr(
  groups_to_test,
  ~ run_missingness_motif_fisher(
    presence_2of3,
    group_name = .x,
    reference_name = "Detected_all",
    definition_label = ">=2/3 replicates"
  )
) %>%
  group_by(category) %>%
  mutate(p_adjust = p.adjust(p_value, method = "BH")) %>%
  ungroup()

missingness_fisher_all <- bind_rows(
  missingness_fisher_any,
  missingness_fisher_2of3
)

# ----------------------------------------------------------------------------
# 5. 更直接回答导师问题：
#    Control-vs-treatment pair 中，“control detected / treatment missing”是否 motif-biased？
# ----------------------------------------------------------------------------
build_pairwise_detection_table <- function(df, treatment = c("Pal1", "Pal5")) {

  treatment <- match.arg(treatment)

  detected_treat <- if (treatment == "Pal1") {
    df$detected_pal1
  } else {
    df$detected_pal5
  }

  df %>%
    mutate(
      pairwise_group = case_when(
        detected_control & detected_treat ~ "Detected_both",
        detected_control & !detected_treat ~ "Control_detected_treatment_missing",
        !detected_control & detected_treat ~ "Treatment_only",
        TRUE ~ "Neither"
      ),
      treatment = treatment
    )
}

run_pairwise_missingness_fisher <- function(
    df,
    treatment,
    definition_label
) {

  pair_df <- build_pairwise_detection_table(df, treatment)

  target_group <- "Control_detected_treatment_missing"
  ref_group <- "Detected_both"

  test_one <- function(motif_name) {

    if (motif_name == "SP") {
      sub <- pair_df %>% filter(motif_center_aa == "S")
      target <- sub$motif_type == "SP"
      comparison <- "SP vs other S"
    } else if (motif_name == "TP") {
      sub <- pair_df %>% filter(motif_center_aa == "T")
      target <- sub$motif_type == "TP"
      comparison <- "TP vs other T"
    } else if (motif_name == "SF") {
      sub <- pair_df %>% filter(motif_center_aa == "S")
      target <- sub$motif_type == "SF"
      comparison <- "SF vs other S"
    } else {
      sub <- pair_df %>% filter(motif_center_aa %in% c("S", "T"))
      target <- sub$proline_directed
      comparison <- "SP+TP vs other S/T"
    }

    grp <- sub$pairwise_group == target_group
    ref <- sub$pairwise_group == ref_group

    a <- sum(grp & target, na.rm = TRUE)
    b <- sum(grp & !target, na.rm = TRUE)
    c <- sum(ref & target, na.rm = TRUE)
    d <- sum(ref & !target, na.rm = TRUE)

    if ((a + b) == 0 || (c + d) == 0) {
      return(
        tibble(
          treatment = treatment,
          definition = definition_label,
          category = motif_name,
          comparison = comparison,
          missing_group = target_group,
          reference_group = ref_group,
          odds_ratio = NA_real_,
          p_value = NA_real_
        )
      )
    }

    ft <- fisher.test(
      matrix(
        c(a, b, c, d),
        nrow = 2,
        byrow = TRUE
      )
    )

    tibble(
      treatment = treatment,
      definition = definition_label,
      category = motif_name,
      comparison = comparison,
      missing_group = target_group,
      reference_group = ref_group,
      missing_target = a,
      missing_other = b,
      reference_target = c,
      reference_other = d,
      missing_fraction = a / (a + b),
      reference_fraction = c / (c + d),
      odds_ratio = unname(ft$estimate),
      conf_low = ft$conf.int[1],
      conf_high = ft$conf.int[2],
      p_value = ft$p.value
    )
  }

  map_dfr(
    c("SP", "TP", "SF", "SP_TP"),
    test_one
  )
}

pairwise_missingness_results <- bind_rows(
  run_pairwise_missingness_fisher(
    presence_any,
    "Pal1",
    ">=1/3 replicates"
  ),
  run_pairwise_missingness_fisher(
    presence_any,
    "Pal5",
    ">=1/3 replicates"
  ),
  run_pairwise_missingness_fisher(
    presence_2of3,
    "Pal1",
    ">=2/3 replicates"
  ),
  run_pairwise_missingness_fisher(
    presence_2of3,
    "Pal5",
    ">=2/3 replicates"
  )
) %>%
  group_by(definition, treatment) %>%
  mutate(p_adjust = p.adjust(p_value, method = "BH")) %>%
  ungroup()

# ----------------------------------------------------------------------------
# 6. Missingness 图
# ----------------------------------------------------------------------------
presence_plot_df <- presence_summary %>%
  filter(
    definition == "Detected if >=1/3 replicates have intensity > 0"
  ) %>%
  mutate(
    missingness_group = fct_reorder(
      missingness_group,
      n_sites
    )
  )

p_presence <- ggplot(
  presence_plot_df,
  aes(
    x = n_sites,
    y = missingness_group
  )
) +
  geom_col() +
  labs(
    title = "Phosphosite detection patterns",
    subtitle = "Primary definition: detected in at least 1 of 3 replicates",
    x = "Number of phosphosites",
    y = NULL
  ) +
  theme_bw()

ggsave(
  file.path(
    r4_figure_dir,
    "01_missingness_detection_pattern_counts.png"
  ),
  p_presence,
  width = 9,
  height = 6,
  dpi = 300
)

motif_plot_df <- motif_composition %>%
  filter(
    definition == "Detected if >=1/3 replicates have intensity > 0",
    motif_display %in% c(
      "SP",
      "TP",
      "SF",
      "Other_S",
      "Other_T"
    )
  )

p_motif_missing <- ggplot(
  motif_plot_df,
  aes(
    x = missingness_group,
    y = fraction_within_group,
    fill = motif_display
  )
) +
  geom_col(position = "fill") +
  coord_flip() +
  labs(
    title = "Motif composition across phosphosite detection groups",
    x = NULL,
    y = "Fraction within detection group",
    fill = "Motif"
  ) +
  theme_bw()

ggsave(
  file.path(
    r4_figure_dir,
    "02_missingness_motif_composition.png"
  ),
  p_motif_missing,
  width = 10,
  height = 7,
  dpi = 300
)

# ----------------------------------------------------------------------------
# 7. Missingness Excel 输出
# ----------------------------------------------------------------------------
write.xlsx(
  list(
    Detection_patterns = presence_summary,
    Motif_composition = motif_composition,
    Fisher_vs_detected_all = missingness_fisher_all,
    Pairwise_control_vs_treatment = pairwise_missingness_results,
    Site_presence_primary = presence_any %>%
      select(
        `Protein accession`,
        `Gene name`,
        Position,
        `Amino acid`,
        site_id,
        motif_sequence_15mer,
        motif_type,
        n_detected_control,
        n_detected_pal1,
        n_detected_pal5,
        detected_control,
        detected_pal1,
        detected_pal5,
        detection_pattern,
        missingness_group,
        Pal1_log2FC,
        Pal5_log2FC
      ),
    Site_presence_2of3 = presence_2of3 %>%
      select(
        `Protein accession`,
        `Gene name`,
        Position,
        `Amino acid`,
        site_id,
        motif_sequence_15mer,
        motif_type,
        n_detected_control,
        n_detected_pal1,
        n_detected_pal5,
        detected_control,
        detected_pal1,
        detected_pal5,
        detection_pattern,
        missingness_group,
        Pal1_log2FC,
        Pal5_log2FC
      )
  ),
  file = file.path(
    r4_table_dir,
    "01_missing_phosphosite_motif_bias.xlsx"
  ),
  overwrite = TRUE
)

# ----------------------------------------------------------------------------
# 8. MoMo：阈值前景构建
# ----------------------------------------------------------------------------
build_foreground_r4 <- function(
    background_data,
    dose,
    log2fc_cutoff,
    p_cutoff = 0.05
) {

  if (dose == "Pal1") {
    background_data %>%
      filter(
        `Pal1/Con P value` < p_cutoff,
        Pal1_log2FC < log2fc_cutoff
      )
  } else if (dose == "Pal5") {
    background_data %>%
      filter(
        `Pal5/Con P value` < p_cutoff,
        Pal5_log2FC < log2fc_cutoff
      )
  } else {
    stop("dose 必须为 Pal1 或 Pal5。")
  }
}

# ----------------------------------------------------------------------------
# 9. MoMo sequence QC
# ----------------------------------------------------------------------------
check_momo_sequences <- function(
    data,
    expected_center,
    dose,
    cutoff,
    dataset_type
) {

  data %>%
    summarise(
      dose = dose,
      log2fc_cutoff = cutoff,
      threshold = ifelse(
        is.na(cutoff),
        "background",
        threshold_label(cutoff)
      ),
      dataset_type = dataset_type,
      expected_center = expected_center,
      total_sites = n_distinct(site_id),
      total_rows = n(),
      missing_sequences =
        sum(is.na(motif_sequence_15mer)),
      incorrect_length =
        sum(
          !is.na(motif_sequence_15mer) &
            str_length(motif_sequence_15mer) != 15
        ),
      incorrect_center =
        sum(
          !is.na(motif_sequence_15mer) &
            str_length(motif_sequence_15mer) == 15 &
            substr(
              motif_sequence_15mer,
              8,
              8
            ) != expected_center
        ),
      sequences_with_X =
        sum(
          !is.na(motif_sequence_15mer) &
            str_detect(
              motif_sequence_15mer,
              fixed("X")
            )
        ),
      invalid_characters =
        sum(
          !is.na(motif_sequence_15mer) &
            !str_detect(
              motif_sequence_15mer,
              "^[ACDEFGHIKLMNPQRSTVWYX]+$"
            )
        ),
      duplicate_15mer =
        sum(
          duplicated(
            motif_sequence_15mer[
              !is.na(motif_sequence_15mer)
            ]
          )
        )
    )
}

# ----------------------------------------------------------------------------
# 10. MoMo 文件输出函数
# ----------------------------------------------------------------------------
clean_momo_data <- function(
    data,
    expected_center,
    remove_X = FALSE,
    deduplicate_sequence = FALSE
) {

  out <- data %>%
    filter(
      !is.na(site_id),
      !is.na(motif_sequence_15mer),
      str_length(motif_sequence_15mer) == 15,
      substr(
        motif_sequence_15mer,
        8,
        8
      ) == expected_center,
      str_detect(
        motif_sequence_15mer,
        "^[ACDEFGHIKLMNPQRSTVWYX]+$"
      )
    ) %>%
    distinct(site_id, .keep_all = TRUE)

  if (remove_X) {
    out <- out %>%
      filter(
        !str_detect(
          motif_sequence_15mer,
          fixed("X")
        )
      )
  }

  if (deduplicate_sequence) {
    out <- out %>%
      distinct(
        motif_sequence_15mer,
        .keep_all = TRUE
      )
  }

  out
}

write_momo_txt <- function(
    data,
    path
) {
  writeLines(
    data$motif_sequence_15mer,
    con = path
  )
}

write_momo_fasta <- function(
    data,
    path,
    sequence_prefix
) {

  if (nrow(data) == 0) {
    writeLines(character(), path)
    return(invisible(NULL))
  }

  fasta_lines <- unlist(
    map2(
      seq_len(nrow(data)),
      data$motif_sequence_15mer,
      ~ c(
        paste0(
          ">",
          sequence_prefix,
          "_",
          .x
        ),
        .y
      )
    ),
    use.names = FALSE
  )

  writeLines(
    fasta_lines,
    con = path
  )
}

write_momo_metadata <- function(
    data,
    path
) {

  data %>%
    transmute(
      site_id = site_id,
      protein_accession = `Protein accession`,
      gene_name = `Gene name`,
      position = Position,
      amino_acid = `Amino acid`,
      motif_sequence_15mer = motif_sequence_15mer,
      motif_type = motif_type,
      Pal1_log2FC = Pal1_log2FC,
      Pal5_log2FC = Pal5_log2FC,
      Pal1_p = `Pal1/Con P value`,
      Pal5_p = `Pal5/Con P value`
    ) %>%
    write_csv(path)
}

# ----------------------------------------------------------------------------
# 11. MoMo：为 Pal1/Pal5 × 4 thresholds × S/T 导出
# ----------------------------------------------------------------------------
momo_qc_list <- list()
momo_manifest_list <- list()

for (dose in c("Pal1", "Pal5")) {

  background_data <- if (dose == "Pal1") {
    pal1_background
  } else {
    pal5_background
  }

  # 每个 dose 的 background S/T，只需保存一次。
  for (center in c("S", "T")) {

    bg_center <- background_data %>%
      filter(
        motif_center_aa == center
      )

    momo_qc_list[[
      paste(
        dose,
        "background",
        center,
        sep = "_"
      )
    ]] <- check_momo_sequences(
      bg_center,
      expected_center = center,
      dose = dose,
      cutoff = NA_real_,
      dataset_type = "background"
    )

    for (variant in c(
      "all_valid",
      "no_X",
      "no_X_unique15mer"
    )) {

      remove_x <- variant != "all_valid"
      dedup <- variant == "no_X_unique15mer"

      bg_clean <- clean_momo_data(
        bg_center,
        expected_center = center,
        remove_X = remove_x,
        deduplicate_sequence = dedup
      )

      prefix <- paste(
        dose,
        "background",
        center,
        variant,
        sep = "_"
      )

      txt_path <- file.path(
        r4_momo_dir,
        paste0(prefix, "_15mer.txt")
      )

      fasta_path <- file.path(
        r4_momo_dir,
        paste0(prefix, "_15mer.fasta")
      )

      metadata_path <- file.path(
        r4_momo_dir,
        paste0(prefix, "_metadata.csv")
      )

      write_momo_txt(
        bg_clean,
        txt_path
      )

      write_momo_fasta(
        bg_clean,
        fasta_path,
        prefix
      )

      write_momo_metadata(
        bg_clean,
        metadata_path
      )

      momo_manifest_list[[
        paste(
          prefix,
          sep = "_"
        )
      ]] <- tibble(
        dose = dose,
        threshold = "background",
        log2fc_cutoff = NA_real_,
        dataset_type = "background",
        center = center,
        variant = variant,
        n_sequences = nrow(bg_clean),
        txt_file = txt_path,
        fasta_file = fasta_path,
        metadata_file = metadata_path
      )
    }
  }

  # Foreground：4 个 cutoff。
  for (cutoff in thresholds) {

    fg <- build_foreground_r4(
      background_data = background_data,
      dose = dose,
      log2fc_cutoff = cutoff,
      p_cutoff = foreground_p_cutoff
    )

    for (center in c("S", "T")) {

      fg_center <- fg %>%
        filter(
          motif_center_aa == center
        )

      momo_qc_list[[
        paste(
          dose,
          threshold_label(cutoff),
          center,
          sep = "_"
        )
      ]] <- check_momo_sequences(
        fg_center,
        expected_center = center,
        dose = dose,
        cutoff = cutoff,
        dataset_type = "foreground"
      )

      for (variant in c(
        "all_valid",
        "no_X",
        "no_X_unique15mer"
      )) {

        remove_x <- variant != "all_valid"
        dedup <- variant == "no_X_unique15mer"

        fg_clean <- clean_momo_data(
          fg_center,
          expected_center = center,
          remove_X = remove_x,
          deduplicate_sequence = dedup
        )

        prefix <- paste(
          dose,
          threshold_label(cutoff),
          "foreground",
          center,
          variant,
          sep = "_"
        )

        txt_path <- file.path(
          r4_momo_dir,
          paste0(prefix, "_15mer.txt")
        )

        fasta_path <- file.path(
          r4_momo_dir,
          paste0(prefix, "_15mer.fasta")
        )

        metadata_path <- file.path(
          r4_momo_dir,
          paste0(prefix, "_metadata.csv")
        )

        write_momo_txt(
          fg_clean,
          txt_path
        )

        write_momo_fasta(
          fg_clean,
          fasta_path,
          prefix
        )

        write_momo_metadata(
          fg_clean,
          metadata_path
        )

        momo_manifest_list[[
          paste(
            prefix,
            sep = "_"
          )
        ]] <- tibble(
          dose = dose,
          threshold = threshold_label(cutoff),
          log2fc_cutoff = cutoff,
          dataset_type = "foreground",
          center = center,
          variant = variant,
          n_sequences = nrow(fg_clean),
          txt_file = txt_path,
          fasta_file = fasta_path,
          metadata_file = metadata_path
        )
      }
    }
  }
}

momo_qc <- bind_rows(momo_qc_list)
momo_manifest <- bind_rows(momo_manifest_list)

write.xlsx(
  list(
    MoMo_QC = momo_qc,
    MoMo_manifest = momo_manifest
  ),
  file = file.path(
    r4_table_dir,
    "02_MoMo_threshold_input_QC_and_manifest.xlsx"
  ),
  overwrite = TRUE
)

# ----------------------------------------------------------------------------
# 12. MoMo 推荐运行矩阵
# ----------------------------------------------------------------------------
# 主分析建议：
# - S 和 T 分开运行（与原来做法一致）
# - 每个 dose 使用自己对应的 experimental background
# - foreground 分别为 log2FC < 0 / -0.5 / -0.6 / -1.0
# - 主输入优先使用 no_X 版本，减少蛋白端点 padding "X" 对 motif discovery 的影响
# - all_valid 保留作为与旧分析最接近的版本
# - no_X_unique15mer 作为去重复敏感性检查，不替代主分析

momo_run_plan <- expand_grid(
  dose = c("Pal1", "Pal5"),
  log2fc_cutoff = thresholds,
  center = c("S", "T")
) %>%
  mutate(
    threshold = map_chr(
      log2fc_cutoff,
      threshold_label
    ),
    foreground_prefix = paste(
      dose,
      threshold,
      "foreground",
      center,
      "no_X",
      sep = "_"
    ),
    background_prefix = paste(
      dose,
      "background",
      center,
      "no_X",
      sep = "_"
    ),
    biological_question = case_when(
      center == "S" ~
        "Which S-centered motifs are reproducibly enriched/depleted as the downregulated foreground becomes more stringent?",
      center == "T" ~
        "Which T-centered motifs are reproducibly enriched/depleted as the downregulated foreground becomes more stringent?"
    )
  )

write_csv(
  momo_run_plan,
  file.path(
    r4_table_dir,
    "03_MoMo_run_plan.csv"
  )
)

# ----------------------------------------------------------------------------
# 13. 提供 MoMo 结果回填模板
# ----------------------------------------------------------------------------
# 真正跑完 MoMo 后，把每个结果中的 motif 信息整理到这张模板中。
# 后续 R5 可以自动统计 motif 是否跨 4 个 cutoff 重复出现。
momo_result_template <- momo_run_plan %>%
  transmute(
    dose = dose,
    log2fc_cutoff = log2fc_cutoff,
    threshold = threshold,
    center = center,
    motif_id = NA_character_,
    motif_pattern = NA_character_,
    motif_regex = NA_character_,
    score = NA_real_,
    p_value = NA_real_,
    adjusted_p = NA_real_,
    foreground_matches = NA_integer_,
    background_matches = NA_integer_,
    notes = NA_character_
  )

write_csv(
  momo_result_template,
  file.path(
    r4_table_dir,
    "04_MoMo_result_entry_template.csv"
  )
)

# ----------------------------------------------------------------------------
# 14. 最终摘要
# ----------------------------------------------------------------------------
message("\n============================================================")
message("R4.0 completed.")
message("Output directory: ", r4_dir)
message("")
message("主要结果：")
message("1) tables/01_missing_phosphosite_motif_bias.xlsx")
message("   - missingness pattern counts")
message("   - SP/TP/SF motif composition")
message("   - Fisher tests vs Detected_all")
message("   - direct Control-detected / treatment-missing tests")
message("")
message("2) tables/02_MoMo_threshold_input_QC_and_manifest.xlsx")
message("   - 每个 MoMo 输入的 QC 和文件路径")
message("")
message("3) tables/03_MoMo_run_plan.csv")
message("   - Pal1/Pal5 × 4 thresholds × S/T 的 MoMo 运行计划")
message("")
message("4) tables/04_MoMo_result_entry_template.csv")
message("   - MoMo 跑完以后用于汇总 reproducibility")
message("")
message("5) MoMo_inputs/")
message("   - foreground/background txt + fasta + metadata")
message("   - all_valid / no_X / no_X_unique15mer 三种版本")
message("")
message("建议主分析使用 no_X 版本；all_valid 用于与旧 MoMo 输入保持可比。")
message("============================================================\n")
