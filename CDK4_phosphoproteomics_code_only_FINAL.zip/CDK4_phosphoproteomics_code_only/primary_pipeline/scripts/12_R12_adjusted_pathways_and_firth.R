# =============================================================================
# R12. Final site-count-adjusted pathway analysis and Firth sensitivity checks
# =============================================================================
# Inputs:
#   input/R10_site_count_bias_control.xlsx
#   input/original_global_ORA_results.xlsx
#   input/target_gene_set_definitions.csv
#
# Primary models:
#   any significant-down site ~ pathway membership + log1p(site count)
#
# Pathway analysis uses the exact GO/Reactome IDs retained in the original ORA
# workbook. BH correction is applied separately within dose, threshold, and
# database, matching the original GO BP / GO CC / GO MF / Reactome families.
#
# Firth sensitivity analysis uses logistf with profile-likelihood confidence
# intervals and P values for the RZZ/fibrous-corona and SAC core sets.
# =============================================================================

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(purrr)
  library(stringr)
  library(tibble)
  library(readr)
  library(openxlsx)
  library(ggplot2)
  library(AnnotationDbi)
  library(org.Hs.eg.db)
  library(GO.db)
  library(reactome.db)
  library(logistf)
})

set.seed(20260823)

`%||%` <- function(x, y) {
  if (is.null(x) || length(x) == 0) y else x
}

input_dir <- "input"
table_dir <- "tables"
figure_dir <- "figures"
source_dir <- "source_data"

dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(source_dir, recursive = TRUE, showWarnings = FALSE)

r10_file <- file.path(input_dir, "R10_site_count_bias_control.xlsx")
ora_file <- file.path(input_dir, "original_global_ORA_results.xlsx")
target_file <- file.path(input_dir, "target_gene_set_definitions.csv")

stopifnot(file.exists(r10_file), file.exists(ora_file), file.exists(target_file))

protein_level_all <- openxlsx::read.xlsx(
  r10_file,
  sheet = "Protein_level_all"
) %>%
  as_tibble() %>%
  mutate(
    across(starts_with("any_down_"), as.logical),
    across(starts_with("target__"), as.logical)
  )

response_map <- c(
  "lt0" = "any_down_lt0",
  "lt_m0.5" = "any_down_lt_m0.5",
  "lt_m0.6" = "any_down_lt_m0.6",
  "lt_m1.0" = "any_down_lt_m1.0"
)

ora_sheet_map <- tibble(
  sheet = openxlsx::getSheetNames(ora_file)
) %>%
  mutate(
    dose = if_else(str_starts(sheet, "Pal1"), "Pal1", "Pal5"),
    database = case_when(
      str_detect(sheet, "GO_BP") ~ "GO_BP",
      str_detect(sheet, "GO_CC") ~ "GO_CC",
      str_detect(sheet, "GO_MF") ~ "GO_MF",
      str_detect(sheet, "Reactome") ~ "Reactome",
      TRUE ~ NA_character_
    )
  ) %>%
  filter(!is.na(database))

original_tested_terms <- pmap_dfr(
  ora_sheet_map,
  function(sheet, dose, database) {
    openxlsx::read.xlsx(ora_file, sheet = sheet) %>%
      as_tibble() %>%
      transmute(
        dose = dose,
        database = database,
        pathway_id = as.character(ID),
        description = as.character(Description),
        original_gene_ratio = as.character(GeneRatio),
        original_background_ratio = as.character(BgRatio),
        original_p = as.numeric(pvalue),
        original_FDR = as.numeric(p.adjust)
      ) %>%
      distinct(dose, database, pathway_id, .keep_all = TRUE)
  }
)

# ----------------------------------------------------------------------------
# Build exact gene memberships from the same installed annotation databases.
# GOALL is used so inherited GO annotations match clusterProfiler behavior.
# ----------------------------------------------------------------------------

all_symbols <- sort(unique(protein_level_all$gene_symbol))

go_membership <- suppressMessages(
  AnnotationDbi::select(
    org.Hs.eg.db,
    keys = all_symbols,
    keytype = "SYMBOL",
    columns = c("SYMBOL", "GOALL", "ONTOLOGYALL")
  )
) %>%
  as_tibble() %>%
  filter(!is.na(GOALL), !is.na(ONTOLOGYALL)) %>%
  transmute(
    database = paste0("GO_", ONTOLOGYALL),
    pathway_id = GOALL,
    gene_symbol = SYMBOL
  ) %>%
  distinct()

symbol_entrez <- suppressMessages(
  AnnotationDbi::select(
    org.Hs.eg.db,
    keys = all_symbols,
    keytype = "SYMBOL",
    columns = c("SYMBOL", "ENTREZID")
  )
) %>%
  as_tibble() %>%
  filter(!is.na(ENTREZID)) %>%
  distinct(SYMBOL, ENTREZID)

reactome_map <- as.list(reactome.db::reactomeEXTID2PATHID)

reactome_membership <- symbol_entrez %>%
  mutate(
    pathway_id = map(
      ENTREZID,
      ~ reactome_map[[as.character(.x)]] %||% character()
    )
  ) %>%
  unnest(pathway_id) %>%
  filter(str_starts(pathway_id, "R-HSA-")) %>%
  transmute(
    database = "Reactome",
    pathway_id = as.character(pathway_id),
    gene_symbol = SYMBOL
  ) %>%
  distinct()

pathway_membership <- bind_rows(go_membership, reactome_membership) %>%
  semi_join(
    original_tested_terms %>% distinct(database, pathway_id),
    by = c("database", "pathway_id")
  )

readr::write_csv(
  original_tested_terms,
  file.path(source_dir, "original_tested_pathways.csv")
)

readr::write_csv(
  pathway_membership,
  file.path(source_dir, "exact_pathway_gene_membership_long.csv")
)

membership_list <- pathway_membership %>%
  group_by(database, pathway_id) %>%
  summarise(genes = list(sort(unique(gene_symbol))), .groups = "drop") %>%
  mutate(key = paste(database, pathway_id, sep = "||")) %>%
  dplyr::select(key, genes) %>%
  deframe()

# ----------------------------------------------------------------------------
# Standard site-count-adjusted logistic regression for every original pathway.
# ----------------------------------------------------------------------------

fit_pathway_model <- function(dat, genes, response_col) {
  response <- as.integer(dat[[response_col]])
  is_pathway <- dat$gene_symbol %in% genes
  log_site_count <- as.numeric(dat$log_site_count)
  ok <- complete.cases(response, is_pathway, log_site_count)
  response <- response[ok]
  is_pathway <- is_pathway[ok]
  log_site_count <- log_site_count[ok]

  n_total <- length(response)
  n_pathway <- sum(is_pathway)
  n_nonpathway <- sum(!is_pathway)
  n_positive <- sum(response)
  events_in <- sum(response[is_pathway])

  if (
    n_pathway < 3 || n_nonpathway < 10 ||
    length(unique(response)) < 2
  ) {
    return(tibble(
      n_total = n_total, n_pathway = n_pathway,
      n_response_positive = n_positive,
      events_in_pathway = events_in,
      beta = NA_real_, SE = NA_real_, adjusted_OR = NA_real_,
      OR_conf_low = NA_real_, OR_conf_high = NA_real_, P = NA_real_,
      site_count_beta = NA_real_, site_count_P = NA_real_,
      converged = FALSE
    ))
  }

  x <- cbind(
    `(Intercept)` = 1,
    is_pathway = as.integer(is_pathway),
    log_site_count = log_site_count
  )

  fit <- tryCatch(
    suppressWarnings(
      glm.fit(
        x = x,
        y = response,
        family = binomial(),
        control = glm.control(epsilon = 1e-8, maxit = 30)
      )
    ),
    error = function(e) NULL
  )

  if (is.null(fit)) {
    return(tibble(
      n_total = n_total, n_pathway = n_pathway,
      n_response_positive = n_positive,
      events_in_pathway = events_in,
      beta = NA_real_, SE = NA_real_, adjusted_OR = NA_real_,
      OR_conf_low = NA_real_, OR_conf_high = NA_real_, P = NA_real_,
      site_count_beta = NA_real_, site_count_P = NA_real_,
      converged = FALSE
    ))
  }

  beta <- unname(fit$coefficients["is_pathway"])
  if (!is.finite(beta)) {
    return(tibble())
  }

  w <- pmax(fit$weights, 1e-12)
  info <- crossprod(x, x * w)
  vc <- tryCatch(solve(info), error = function(e) NULL)
  if (is.null(vc) || !is.finite(vc[2, 2]) || vc[2, 2] <= 0) {
    return(tibble())
  }
  se <- sqrt(vc[2, 2])
  z <- beta / se
  count_beta <- unname(fit$coefficients["log_site_count"])
  count_se <- sqrt(vc[3, 3])

  tibble(
    n_total = n_total,
    n_pathway = n_pathway,
    n_response_positive = n_positive,
    events_in_pathway = events_in,
    beta = beta,
    SE = se,
    adjusted_OR = exp(beta),
    OR_conf_low = exp(beta - 1.96 * se),
    OR_conf_high = exp(beta + 1.96 * se),
    P = 2 * pnorm(abs(z), lower.tail = FALSE),
    site_count_beta = count_beta,
    site_count_P = 2 * pnorm(abs(count_beta / count_se), lower.tail = FALSE),
    converged = isTRUE(fit$converged)
  )
}

run_pathway_task <- function(i) {
  meta <- original_tested_terms[i, , drop = FALSE]
  dat <- protein_level_all[protein_level_all$dose == meta$dose, , drop = FALSE]
  key <- paste(meta$database, meta$pathway_id, sep = "||")
  genes <- membership_list[[key]] %||% character()

  out <- lapply(names(response_map), function(cutoff) {
    fit <- fit_pathway_model(dat, genes, response_map[[cutoff]])
    if (nrow(fit) == 0) return(NULL)
    cbind(
      data.frame(
        dose = meta$dose,
        cutoff = cutoff,
        database = meta$database,
        pathway_id = meta$pathway_id,
        description = meta$description,
        original_p = meta$original_p,
        original_FDR = meta$original_FDR,
        stringsAsFactors = FALSE
      ),
      as.data.frame(fit)
    )
  })
  dplyr::bind_rows(out)
}

n_workers <- max(1L, min(6L, parallel::detectCores(logical = FALSE) - 1L))
message("Running pathway models with ", n_workers, " workers...")

if (.Platform$OS.type == "windows" && n_workers > 1L) {
  cl <- parallel::makeCluster(n_workers)
  parallel::clusterEvalQ(cl, {
    suppressPackageStartupMessages(library(tibble))
    suppressPackageStartupMessages(library(dplyr))
    NULL
  })
  parallel::clusterExport(
    cl,
    c(
      "original_tested_terms", "protein_level_all", "membership_list",
      "response_map", "fit_pathway_model", "run_pathway_task", "%||%"
    ),
    envir = environment()
  )
  pathway_list <- parallel::parLapply(
    cl,
    seq_len(nrow(original_tested_terms)),
    run_pathway_task
  )
  parallel::stopCluster(cl)
} else {
  pathway_list <- lapply(seq_len(nrow(original_tested_terms)), run_pathway_task)
}

pathway_results <- bind_rows(pathway_list) %>%
  group_by(dose, cutoff, database) %>%
  mutate(FDR = p.adjust(P, method = "BH")) %>%
  ungroup() %>%
  arrange(dose, cutoff, database, FDR, P)

readr::write_csv(
  pathway_results,
  file.path(table_dir, "01_site_count_adjusted_GO_Reactome_all.csv")
)

pathway_stability <- pathway_results %>%
  group_by(dose, database, pathway_id, description) %>%
  summarise(
    thresholds_tested = sum(!is.na(P)),
    thresholds_OR_gt1 = sum(adjusted_OR > 1, na.rm = TRUE),
    thresholds_FDR_lt_005 = sum(FDR < 0.05, na.rm = TRUE),
    thresholds_FDR_lt_020 = sum(FDR < 0.20, na.rm = TRUE),
    median_adjusted_OR = median(adjusted_OR, na.rm = TRUE),
    best_FDR = min(FDR, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(
    best_FDR = if_else(is.infinite(best_FDR), NA_real_, best_FDR)
  ) %>%
  arrange(dose, best_FDR)

readr::write_csv(
  pathway_stability,
  file.path(table_dir, "02_site_count_adjusted_pathway_stability.csv")
)

# ----------------------------------------------------------------------------
# Firth logistic sensitivity: RZZ/fibrous corona and SAC.
# ----------------------------------------------------------------------------

firth_target_map <- c(
  "RZZ_fibrous_corona_core" = "target__RZZ_fibrous_corona_core",
  "SAC_core" = "target__SAC_core"
)

fit_firth_one <- function(dat, target_col, response_col) {
  model_data <- dat %>%
    transmute(
      response = as.integer(.data[[response_col]]),
      is_target = as.logical(.data[[target_col]]),
      log_site_count = as.numeric(log_site_count)
    ) %>%
    filter(complete.cases(.)) %>%
    as.data.frame()

  fit <- tryCatch(
    suppressWarnings(
      logistf::logistf(
        response ~ is_target + log_site_count,
        data = model_data,
        firth = TRUE,
        pl = TRUE
      )
    ),
    error = function(e) NULL
  )

  if (is.null(fit)) {
    return(tibble(
      n_total = nrow(model_data),
      n_target = sum(model_data$is_target),
      n_response_positive = sum(model_data$response),
      events_in_target = sum(model_data$response[model_data$is_target]),
      beta = NA_real_, adjusted_OR = NA_real_,
      OR_conf_low = NA_real_, OR_conf_high = NA_real_, P = NA_real_,
      converged = FALSE
    ))
  }

  target_name <- grep("^is_target", names(fit$coefficients), value = TRUE)[1]

  tibble(
    n_total = nrow(model_data),
    n_target = sum(model_data$is_target),
    n_response_positive = sum(model_data$response),
    events_in_target = sum(model_data$response[model_data$is_target]),
    beta = unname(fit$coefficients[target_name]),
    adjusted_OR = exp(unname(fit$coefficients[target_name])),
    OR_conf_low = exp(unname(fit$ci.lower[target_name])),
    OR_conf_high = exp(unname(fit$ci.upper[target_name])),
    P = unname(fit$prob[target_name]),
    converged = max(abs(fit$conv), na.rm = TRUE) < 1e-4
  )
}

firth_results <- bind_rows(
  lapply(c("Pal1", "Pal5"), function(dose) {
    dat <- protein_level_all %>% filter(.data$dose == .env$dose)
    imap_dfr(firth_target_map, function(target_col, target) {
      map_dfr(names(response_map), function(cutoff) {
        fit_firth_one(dat, target_col, response_map[[cutoff]]) %>%
          mutate(dose = dose, cutoff = cutoff, target = target, .before = 1)
      })
    })
  })
) %>%
  group_by(dose, cutoff) %>%
  mutate(FDR = p.adjust(P, method = "BH")) %>%
  ungroup() %>%
  arrange(dose, target, factor(cutoff, levels = names(response_map)))

readr::write_csv(
  firth_results,
  file.path(table_dir, "03_RZZ_SAC_Firth_logistic.csv")
)

standard_logistic <- openxlsx::read.xlsx(
  r10_file,
  sheet = "Logistic_threshold_all"
) %>%
  as_tibble() %>%
  filter(target %in% names(firth_target_map))

firth_comparison <- firth_results %>%
  left_join(
    standard_logistic %>%
      dplyr::select(
        dose, cutoff, target,
        standard_OR = target_adjusted_OR,
        standard_CI_low = target_OR_conf_low,
        standard_CI_high = target_OR_conf_high,
        standard_P = target_p,
        standard_FDR = target_FDR
      ),
    by = c("dose", "cutoff", "target")
  )

readr::write_csv(
  firth_comparison,
  file.path(table_dir, "04_Firth_vs_standard_logistic.csv")
)

# ----------------------------------------------------------------------------
# Plot-ready subsets and manuscript-quality vector figures.
# ----------------------------------------------------------------------------

interest_pattern <- regex(
  paste(
    c(
      "kinetochore", "centromer", "prometaphase", "spindle checkpoint",
      "mitotic checkpoint", "sister chromatid cohesion", "spindle formation"
    ),
    collapse = "|"
  ),
  ignore_case = TRUE
)

pathway_plot_data <- pathway_results %>%
  filter(
    str_detect(description, interest_pattern),
    is.finite(adjusted_OR), adjusted_OR > 0,
    is.finite(OR_conf_low), OR_conf_low > 0,
    is.finite(OR_conf_high), OR_conf_high > 0
  ) %>%
  group_by(dose, cutoff, database) %>%
  slice_min(order_by = FDR, n = 8, with_ties = FALSE) %>%
  ungroup() %>%
  mutate(
    cutoff = factor(cutoff, levels = names(response_map)),
    label = str_trunc(description, 65)
  )

readr::write_csv(
  pathway_plot_data,
  file.path(source_dir, "figure_01_pathway_source_data.csv")
)

p1 <- ggplot(
  pathway_plot_data,
  aes(x = adjusted_OR, y = reorder(label, adjusted_OR), color = FDR)
) +
  geom_vline(xintercept = 1, linetype = 2, color = "grey55") +
  geom_errorbarh(
    aes(xmin = OR_conf_low, xmax = OR_conf_high),
    height = 0.15,
    linewidth = 0.35
  ) +
  geom_point(size = 2.2) +
  scale_x_log10() +
  scale_color_viridis_c(option = "C", direction = -1, trans = "log10") +
  facet_grid(dose + database ~ cutoff, scales = "free_y", space = "free_y") +
  labs(
    x = "Site-count-adjusted odds ratio (log scale)",
    y = NULL,
    color = "BH FDR",
    title = "Site-count-adjusted GO/Reactome signals",
    subtitle = "Terms of prior biological interest; models were run on all original ORA terms"
  ) +
  theme_bw(base_size = 9) +
  theme(
    strip.text = element_text(face = "bold"),
    axis.text.y = element_text(size = 6.5),
    panel.grid.minor = element_blank(),
    legend.position = "bottom"
  )

for (ext in c("svg", "pdf", "png")) {
  ggsave(
    file.path(figure_dir, paste0("01_site_count_adjusted_pathways.", ext)),
    p1,
    width = 15,
    height = 13,
    dpi = 320,
    limitsize = FALSE
  )
}

firth_plot_data <- firth_results %>%
  mutate(
    cutoff = factor(cutoff, levels = names(response_map)),
    target = recode(
      target,
      RZZ_fibrous_corona_core = "RZZ / fibrous corona",
      SAC_core = "SAC"
    )
  )

readr::write_csv(
  firth_plot_data,
  file.path(source_dir, "figure_02_Firth_source_data.csv")
)

p2 <- ggplot(
  firth_plot_data,
  aes(x = adjusted_OR, y = cutoff, color = target)
) +
  geom_vline(xintercept = 1, linetype = 2, color = "grey55") +
  geom_errorbarh(
    aes(xmin = OR_conf_low, xmax = OR_conf_high),
    height = 0.12,
    position = position_dodge(width = 0.4),
    linewidth = 0.5
  ) +
  geom_point(position = position_dodge(width = 0.4), size = 2.5) +
  scale_x_log10() +
  facet_wrap(~ dose) +
  scale_color_manual(values = c("RZZ / fibrous corona" = "#7B3294", "SAC" = "#008837")) +
  labs(
    x = "Firth site-count-adjusted odds ratio (log scale)",
    y = "Foreground effect-size threshold",
    color = NULL,
    title = "Firth logistic sensitivity analysis for RZZ and SAC"
  ) +
  theme_bw(base_size = 11) +
  theme(
    strip.text = element_text(face = "bold"),
    panel.grid.minor = element_blank(),
    legend.position = "bottom"
  )

for (ext in c("svg", "pdf", "png")) {
  ggsave(
    file.path(figure_dir, paste0("02_RZZ_SAC_Firth_forest.", ext)),
    p2,
    width = 9,
    height = 5.5,
    dpi = 320
  )
}

# ----------------------------------------------------------------------------
# Target definitions, source notes, package versions, and compact summary.
# ----------------------------------------------------------------------------

target_definitions <- readr::read_csv(target_file, show_col_types = FALSE) %>%
  mutate(
    definition = case_when(
      category == "Kinetochore_core" ~ "Manual core kinetochore gene set used in R2-R10",
      category == "SAC_core" ~ "Manual core spindle-assembly-checkpoint gene set used in R2-R10",
      category == "RZZ_fibrous_corona_core" ~ "Manual RZZ/fibrous-corona functional core set used in R2-R10",
      category == "Chromosomal_passenger_complex" ~ "Four canonical chromosomal-passenger-complex genes",
      category == "Chromosome_segregation_GO" ~ "Genes selected from GO BP terms matching chromosome segregation or sister chromatid segregation",
      TRUE ~ "Project-defined target set"
    ),
    construction_source = case_when(
      category == "Chromosome_segregation_GO" ~ paste0(
        "org.Hs.eg.db ", as.character(packageVersion("org.Hs.eg.db")),
        "; GO.db ", as.character(packageVersion("GO.db"))
      ),
      TRUE ~ "Manual project list in R2.1_followup_analysis_finalversion.R; manuscript citation review required"
    )
  )

readr::write_csv(
  target_definitions,
  file.path(table_dir, "05_target_gene_set_definitions_and_sources.csv")
)

run_summary <- tibble(
  item = c(
    "R version", "Analysis date", "Random seed", "logistf",
    "org.Hs.eg.db", "GO.db", "reactome.db",
    "Number of pathway models", "Number of Firth models"
  ),
  value = c(
    R.version.string,
    as.character(Sys.Date()),
    "20260823",
    as.character(packageVersion("logistf")),
    as.character(packageVersion("org.Hs.eg.db")),
    as.character(packageVersion("GO.db")),
    as.character(packageVersion("reactome.db")),
    as.character(nrow(pathway_results)),
    as.character(nrow(firth_results))
  )
)

readr::write_csv(run_summary, file.path(table_dir, "06_run_summary.csv"))

capture.output(
  sessionInfo(),
  file = file.path(table_dir, "sessionInfo_R12.txt")
)

message("R12 complete.")
message("Pathway models: ", nrow(pathway_results))
message("Firth models: ", nrow(firth_results))
