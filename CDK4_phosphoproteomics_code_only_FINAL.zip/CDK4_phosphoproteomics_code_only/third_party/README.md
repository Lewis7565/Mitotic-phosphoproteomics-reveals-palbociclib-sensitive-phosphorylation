# Third-party software note

The original local delivery included a copy of `html-monolith.c` from MEME Suite in a folder named `meme_source_patch`.
That source file is not study-authored custom code and is therefore not redistributed in this public-release candidate.

The supplied workflow invokes MEME Suite MoMo as an external dependency. The runner accepts a standard `momo` executable on `PATH` or a user-specified executable via `MOMO_BIN`.

If the exact historical MoMo run depended on a locally modified MEME source file, archive the *diff/patch* against the relevant MEME Suite release (rather than a copied upstream source file) and document the upstream version/license before public release.
