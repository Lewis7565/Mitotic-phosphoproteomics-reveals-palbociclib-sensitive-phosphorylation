# Complete protein-cluster-aware phosphosite pathway reproduction

Analysis date: 2026-08-28  
Formal run: 20,000 permutations per dose/analysis  
Status: complete, including the literal full eligible GO screen

## Scope completed

- Pal1 and Pal5 protein-cluster-aware binary phosphosite screens.
- Pal1 and Pal5 protein-cluster-aware threshold-free continuous screens.
- Full GO-BP, GO-CC and GO-MF reconstruction from all GOALL annotations represented in the frozen protein/gene mapping.
- Full Reactome screens using the exact frozen R12 pathway-to-gene definitions.
- Complete result tables, term eligibility decisions, frozen site universes, mappings, scripts, seeds and software versions.

The earlier R12 term universe contained 4,461 GO-BP, 637 GO-CC and 760 GO-MF terms. The completed reconstruction contains 11,032 GO-BP, 1,547 GO-CC and 2,758 GO-MF annotated terms before dose-specific eligibility filtering. Depending on dose and analysis, 6,545-6,732 BP, 948-979 CC and 1,257-1,311 MF terms satisfy the minimum of 3 mapped protein clusters and 3 eligible sites.

## Analysis definitions

Protein accession (`protein_accession_clean`) is the sampling unit. A pathway contains every accession mapped to at least one member gene. Each permutation samples, without replacement, the same number of protein accessions as the tested pathway; all eligible phosphosites belonging to a sampled accession remain together.

For the binary analysis, an eligible site has finite P and log2FC values. A down site is P < 0.05 and log2FC < -0.6. The statistic is the fraction of eligible pathway phosphosites classified as down. The one-sided empirical P value is `(1 + number(null >= observed)) / (20,000 + 1)`.

For the continuous analysis, all quantified S/T phosphosites with finite log2FC are retained, irrespective of P value or fold change. The statistic is the mean phosphosite log2FC. The one-sided empirical P value is `(1 + number(null <= observed)) / (20,000 + 1)`.

Terms with at least 3 mapped protein clusters and 3 eligible sites were tested. BH correction was performed separately within each dose x analysis x database screen. Seeds are fixed and recorded in `tables/13_run_parameters_and_seeds.csv`.

## Membership definitions

- GO: reconstructed without preselection from `GOALL` and `ONTOLOGYALL` in org.Hs.eg.db 3.20.0 for every gene symbol in the frozen accession/gene mapping. GO names use GO.db 3.20.0. The exact reconstructed table is frozen in both `tables` and `frozen_inputs`.
- Reactome: the exact pathway-to-gene table exported by R12 using reactome.db 1.89.0. It was not replaced with a newer Reactome release.
- `tables/04b...reference.csv` preserves the narrower R12/original-ORA GO term membership for audit and comparison only; it is not used as the GO screen limit in this completed analysis.

## Independent-confirmation findings

The four supervisor-provided Pal5 binary Reactome reference results remain reproduced essentially exactly:

| Reactome pathway | Frozen-pipeline empirical P | Preliminary P quoted by supervisor |
|---|---:|---:|
| Resolution of Sister Chromatid Cohesion | 0.0440 | about 0.045 |
| EML4 and NUDC in mitotic spindle formation | 0.0684 | about 0.066 |
| Mitotic Prometaphase | 0.0672 | about 0.067 |
| Mitotic Spindle Checkpoint | 0.1051 | about 0.11 |

The completed GO screen reproduces the broader directional pattern, with mixed term-level nominal significance:

- Pal5 binary: spindle microtubule is nominally supported (P = 0.0397). Mitotic spindle (P = 0.0785), regulation of spindle-microtubule attachment (P = 0.0846), and sister chromatid segregation (P = 0.1265) are weaker.
- Pal5 continuous: regulation of spindle-microtubule attachment shifts negatively (P = 0.0279). The positive-regulation term also shifts negatively (P = 0.0725; directional-effect rank 347 of 6,711 GO-BP terms, approximately the top 5.2%).
- Pal1 continuous: the broader chromosome-segregation pattern is reproduced. Mitotic sister chromatid segregation (P = 0.0177), regulation of sister chromatid segregation (P = 0.0210), sister chromatid segregation (P = 0.0246), and regulation of mitotic sister chromatid segregation (P = 0.0284) all shift negatively.

The named mitotic/chromosome terms do not survive full-screen BH correction. The defensible interpretation is therefore that the overall pattern is reproduced, especially for the Reactome numerical benchmarks and Pal1 chromosome-segregation direction, while individual GO term significance depends on the precise frozen universe and mapping. These are nominal, directionally informative results rather than definitive evidence of pathway specificity.

## Package guide

- `Cluster_aware_reproduction_FULL_GO_summary.xlsx`: reader-oriented summary, GO-scope comparison, benchmark paths, screen counts, parameters and top-ranked terms.
- `tables/01...04b`: frozen site universe, accession/gene mapping, full reconstructed GO membership, exact R12 Reactome membership and the R12 GO reference membership.
- `tables/05...07`: complete binary, continuous and combined source-result tables.
- `tables/08...09`: all eligibility decisions and cluster-count-specific null summaries.
- `tables/10...13`: supervisor benchmark extraction, universe/screen summaries and seeds/parameters.
- `tables/14...17`: mapping audit, cluster sufficient statistics, top-25 convenience extract and GO-scope comparison.
- `frozen_inputs`: exact replay inputs, including the frozen RDS and reconstructed GO membership.
- `reproducibility/01_run_cluster_analysis.R`: complete analysis/replay script.
- `reproducibility/run_analysis.ps1`: one-command replay wrapper that reads the package-local frozen inputs and writes to `replay_output`.
- `reproducibility/02_validate_results.R` and `VALIDATION.txt`: automated integrity checks and their result.
- `reproducibility/sessionInfo.txt`: R and package versions.
- `FILE_MANIFEST_SHA256.csv`: sizes and SHA-256 hashes for package files.

The replay requires R and the packages loaded at the top of the script. The Rcpp permutation engine also requires a working C/C++ toolchain; on Windows this is normally the Rtools release matching R. Run `reproducibility/run_analysis.ps1`; use `-Permutations 199` for a quick smoke test or the default 20,000 for the formal replay.


