param(
    [string]$Rscript = "Rscript",
    [int]$Permutations = 20000,
    [int]$BaseSeed = 2026082800
)

$packagePath = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
try {
    $fso = New-Object -ComObject Scripting.FileSystemObject
    $packagePath = $fso.GetFolder($packagePath).ShortPath
} catch {
    # Short-path conversion is only needed on legacy Windows locales.
}
$env:CLUSTER_PACKAGE_ROOT = $packagePath
$env:CLUSTER_N_PERM = [string]$Permutations
$env:CLUSTER_BASE_SEED = [string]$BaseSeed

& $Rscript (Join-Path $PSScriptRoot "01_run_cluster_analysis.R")
if ($LASTEXITCODE -ne 0) {
    throw "Cluster-aware analysis failed with exit code $LASTEXITCODE"
}
