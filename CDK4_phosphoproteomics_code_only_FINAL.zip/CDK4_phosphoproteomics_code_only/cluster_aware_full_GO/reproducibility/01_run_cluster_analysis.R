suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(stringr)
  library(purrr)
  library(tibble)
  library(Rcpp)
  library(readr)
  library(AnnotationDbi)
  library(org.Hs.eg.db)
  library(GO.db)
})

package_root <- Sys.getenv("CLUSTER_PACKAGE_ROOT")
project_root <- Sys.getenv("PROJECT_ROOT_SHORT")
frozen_go_membership_file <- ""
if (nzchar(package_root)) {
  cache_file <- file.path(package_root, "frozen_inputs", "R2_0_preprocessed_objects.rds")
  membership_file <- file.path(package_root, "frozen_inputs", "exact_pathway_gene_membership_long.csv")
  pathway_file <- file.path(package_root, "frozen_inputs", "original_tested_pathways.csv")
  frozen_go_membership_file <- file.path(package_root, "frozen_inputs", "GO_membership_full_reconstructed_GOALL.csv")
  output_dir <- file.path(package_root, "replay_output")
} else {
  if (!nzchar(project_root)) {
    project_root <- normalizePath(".", winslash = "/", mustWork = TRUE)
  }
  delivery_root <- file.path(project_root, "manuscript_delivery_2026-08-23")
  cache_file <- file.path(delivery_root, "cache", "R2_0_preprocessed_objects.rds")
  membership_file <- file.path(delivery_root, "source_data", "exact_pathway_gene_membership_long.csv")
  pathway_file <- file.path(delivery_root, "source_data", "original_tested_pathways.csv")
  output_dir <- file.path(project_root, "outputs", "cluster_aware_reproduction_full_GO_2026-08-28")
}
table_dir <- file.path(output_dir, "tables")
repro_dir <- file.path(output_dir, "reproducibility")
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(repro_dir, recursive = TRUE, showWarnings = FALSE)

n_perm <- as.integer(Sys.getenv("CLUSTER_N_PERM", unset = "20000"))
base_seed <- as.integer(Sys.getenv("CLUSTER_BASE_SEED", unset = "2026082800"))
min_clusters <- 3L
min_sites <- 3L
binary_p_cutoff <- 0.05
binary_log2fc_cutoff <- -0.6

if (!file.exists(cache_file)) stop("Frozen R2 cache not found: ", cache_file)
if (!file.exists(membership_file)) stop("Frozen R12 membership not found: ", membership_file)
if (!file.exists(pathway_file)) stop("Frozen R12 pathway metadata not found: ", pathway_file)
if (is.na(n_perm) || n_perm < 99L) stop("CLUSTER_N_PERM must be at least 99")

message("Reading frozen R2 objects...")
frozen <- readRDS(cache_file)
site_data <- frozen$site_data

required_site_cols <- c(
  "site_id", "protein_accession_clean", "Gene name", "Position", "Amino acid",
  "Modified sequence", "Localization probability", "motif_sequence_15mer",
  "motif_center_aa", "Pal1/Con Ratio", "Pal1/Con P value", "Pal1_log2FC",
  "Pal5/Con Ratio", "Pal5/Con P value", "Pal5_log2FC"
)
missing_site_cols <- setdiff(required_site_cols, names(site_data))
if (length(missing_site_cols)) stop("Missing frozen site columns: ", paste(missing_site_cols, collapse = ", "))

r12_membership <- read.csv(
  membership_file,
  stringsAsFactors = FALSE,
  check.names = FALSE,
  fileEncoding = "UTF-8"
) %>%
  transmute(
    database = as.character(database),
    pathway_id = as.character(pathway_id),
    gene_symbol = as.character(gene_symbol)
  ) %>%
  filter(database %in% c("GO_BP", "GO_CC", "GO_MF", "Reactome")) %>%
  distinct()

pathway_connection <- file(pathway_file, open = "rb")
r12_pathway_meta_raw <- readr::read_csv(
  pathway_connection,
  show_col_types = FALSE,
  progress = FALSE
) %>%
  transmute(
    database = as.character(database),
    pathway_id = as.character(pathway_id),
    pathway_name = as.character(description)
  ) %>%
  filter(database %in% c("GO_BP", "GO_CC", "GO_MF", "Reactome")) %>%
  distinct()

name_conflicts <- r12_pathway_meta_raw %>%
  count(database, pathway_id, name = "n_names") %>%
  filter(n_names != 1L)
if (nrow(name_conflicts)) stop("Conflicting frozen pathway names detected")

r12_pathway_meta <- r12_pathway_meta_raw %>% distinct(database, pathway_id, .keep_all = TRUE)
close(pathway_connection)

split_gene_mapping <- function(df) {
  df %>%
    transmute(
      protein_accession = str_trim(as.character(protein_accession_clean)),
      gene_symbol = as.character(`Gene name`)
    ) %>%
    separate_rows(gene_symbol, sep = "[;,/| ]+") %>%
    mutate(gene_symbol = str_trim(gene_symbol)) %>%
    filter(
      !is.na(protein_accession), protein_accession != "",
      !is.na(gene_symbol), gene_symbol != "", gene_symbol != "--"
    ) %>%
    distinct()
}

make_dose_universe <- function(dose) {
  ratio_col <- paste0(dose, "/Con Ratio")
  p_col <- paste0(dose, "/Con P value")
  log2fc_col <- paste0(dose, "_log2FC")

  site_data %>%
    transmute(
      dose = dose,
      site_id = as.character(site_id),
      protein_accession = str_trim(as.character(protein_accession_clean)),
      gene_symbol_raw = as.character(`Gene name`),
      position = as.integer(Position),
      amino_acid = as.character(`Amino acid`),
      modified_sequence = as.character(`Modified sequence`),
      localization_probability = as.numeric(`Localization probability`),
      motif_sequence_15mer = as.character(motif_sequence_15mer),
      motif_center_aa = as.character(motif_center_aa),
      ratio = as.numeric(.data[[ratio_col]]),
      p_value = as.numeric(.data[[p_col]]),
      log2FC = as.numeric(.data[[log2fc_col]])
    ) %>%
    filter(
      !is.na(site_id), site_id != "",
      !is.na(protein_accession), protein_accession != "",
      !is.na(motif_sequence_15mer),
      motif_center_aa %in% c("S", "T"),
      !is.na(ratio), ratio > 0,
      !is.na(log2FC), is.finite(log2FC)
    ) %>%
    distinct(site_id, .keep_all = TRUE) %>%
    mutate(
      continuous_eligible = TRUE,
      binary_eligible = !is.na(p_value) & is.finite(p_value),
      down_binary = binary_eligible & p_value < binary_p_cutoff & log2FC < binary_log2fc_cutoff
    ) %>%
    arrange(protein_accession, site_id)
}

pal1_universe <- make_dose_universe("Pal1")
pal5_universe <- make_dose_universe("Pal5")
site_universe <- bind_rows(pal1_universe, pal5_universe)

protein_gene_mapping <- split_gene_mapping(site_data) %>%
  arrange(protein_accession, gene_symbol)

accession_gene_conflicts <- protein_gene_mapping %>%
  count(protein_accession, name = "n_gene_symbols") %>%
  filter(n_gene_symbols > 1L)

# Reconstruct the complete GOALL membership from the frozen protein/gene mapping.
# In package replay mode, read the exported frozen GOALL membership directly so
# that later annotation-package changes cannot alter pathway definitions.
if (nzchar(frozen_go_membership_file) && file.exists(frozen_go_membership_file)) {
  frozen_go_connection <- file(frozen_go_membership_file, open = "rb")
  frozen_go <- readr::read_csv(frozen_go_connection, show_col_types = FALSE, progress = FALSE)
  close(frozen_go_connection)
  go_membership <- frozen_go %>%
    transmute(database, pathway_id, gene_symbol) %>%
    distinct()
  go_meta <- frozen_go %>%
    transmute(database, pathway_id, pathway_name) %>%
    distinct(database, pathway_id, .keep_all = TRUE)
} else {
  all_symbols <- sort(unique(protein_gene_mapping$gene_symbol))
  go_membership <- suppressMessages(
    AnnotationDbi::select(
      org.Hs.eg.db,
      keys = all_symbols,
      keytype = "SYMBOL",
      columns = c("SYMBOL", "GOALL", "ONTOLOGYALL")
    )
  ) %>%
    as_tibble() %>%
    filter(!is.na(GOALL), ONTOLOGYALL %in% c("BP", "CC", "MF")) %>%
    transmute(
      database = paste0("GO_", ONTOLOGYALL),
      pathway_id = as.character(GOALL),
      gene_symbol = as.character(SYMBOL)
    ) %>%
    distinct()

  go_term_lookup <- suppressMessages(
    AnnotationDbi::select(
      GO.db,
      keys = sort(unique(go_membership$pathway_id)),
      keytype = "GOID",
      columns = c("TERM", "ONTOLOGY")
    )
  ) %>%
    as_tibble() %>%
    dplyr::select(GOID, TERM) %>%
    distinct(GOID, .keep_all = TRUE)

  go_meta <- go_membership %>%
    distinct(database, pathway_id) %>%
    left_join(go_term_lookup, by = c("pathway_id" = "GOID")) %>%
    transmute(
      database,
      pathway_id,
      pathway_name = if_else(is.na(TERM) | TERM == "", paste0("GO term name unavailable: ", pathway_id), as.character(TERM))
    ) %>%
    distinct(database, pathway_id, .keep_all = TRUE)
}

reactome_membership <- r12_membership %>%
  filter(database == "Reactome")

reactome_meta <- r12_pathway_meta %>%
  filter(database == "Reactome")

membership <- bind_rows(go_membership, reactome_membership) %>% distinct()
pathway_meta <- bind_rows(go_meta, reactome_meta) %>%
  semi_join(membership %>% distinct(database, pathway_id), by = c("database", "pathway_id")) %>%
  distinct(database, pathway_id, .keep_all = TRUE)

pathway_accessions <- membership %>%
  inner_join(protein_gene_mapping, by = "gene_symbol", relationship = "many-to-many") %>%
  distinct(database, pathway_id, protein_accession)

Rcpp::cppFunction('
NumericMatrix cluster_null_matrix(
    NumericVector numerator,
    NumericVector denominator,
    IntegerVector sizes,
    int n_perm
) {
  RNGScope scope;
  int n = numerator.size();
  int k_count = sizes.size();
  NumericMatrix out(n_perm, k_count);
  IntegerVector pool(n);
  for (int i = 0; i < n; ++i) pool[i] = i;

  for (int b = 0; b < n_perm; ++b) {
    for (int i = n - 1; i > 0; --i) {
      int j = (int) floor(R::runif(0.0, (double) (i + 1)));
      int tmp = pool[i];
      pool[i] = pool[j];
      pool[j] = tmp;
    }

    double num_sum = 0.0;
    double den_sum = 0.0;
    int size_index = 0;
    for (int pos = 0; pos < n && size_index < k_count; ++pos) {
      int idx = pool[pos];
      num_sum += numerator[idx];
      den_sum += denominator[idx];
      int current_size = pos + 1;
      while (size_index < k_count && sizes[size_index] == current_size) {
        out(b, size_index) = den_sum > 0.0 ? num_sum / den_sum : NA_REAL;
        size_index++;
      }
    }
  }
  return out;
}
')

build_cluster_metrics <- function(universe, analysis) {
  if (analysis == "binary") {
    universe %>%
      filter(binary_eligible) %>%
      group_by(protein_accession) %>%
      summarise(
        numerator = sum(down_binary),
        denominator = n(),
        .groups = "drop"
      )
  } else if (analysis == "continuous") {
    universe %>%
      group_by(protein_accession) %>%
      summarise(
        numerator = sum(log2FC),
        denominator = n(),
        .groups = "drop"
      )
  } else {
    stop("Unknown analysis: ", analysis)
  }
}

seed_for <- function(dose, analysis) {
  offset <- case_when(
    dose == "Pal1" & analysis == "binary" ~ 11L,
    dose == "Pal5" & analysis == "binary" ~ 12L,
    dose == "Pal1" & analysis == "continuous" ~ 21L,
    dose == "Pal5" & analysis == "continuous" ~ 22L,
    TRUE ~ 99L
  )
  base_seed + offset
}

run_one_screen <- function(universe, dose, analysis) {
  message("Preparing ", dose, " ", analysis, " screen...")
  metrics <- build_cluster_metrics(universe, analysis) %>%
    arrange(protein_accession)

  path_stats <- pathway_accessions %>%
    inner_join(metrics, by = "protein_accession") %>%
    group_by(database, pathway_id) %>%
    summarise(
      n_clusters = n_distinct(protein_accession),
      n_sites = sum(denominator),
      observed_numerator = sum(numerator),
      observed_stat = observed_numerator / n_sites,
      .groups = "drop"
    )

  eligibility <- pathway_meta %>%
    left_join(path_stats, by = c("database", "pathway_id")) %>%
    mutate(
      n_clusters = coalesce(n_clusters, 0L),
      n_sites = coalesce(n_sites, 0L),
      eligible = n_clusters >= min_clusters & n_sites >= min_sites & n_clusters < nrow(metrics),
      exclusion_reason = case_when(
        n_clusters == 0L ~ "no_mapped_clusters",
        n_clusters < min_clusters ~ "fewer_than_3_clusters",
        n_sites < min_sites ~ "fewer_than_3_sites",
        n_clusters >= nrow(metrics) ~ "pathway_equals_universe",
        TRUE ~ "eligible"
      ),
      dose = dose,
      analysis = analysis
    )

  eligible <- eligibility %>% filter(eligible)
  sizes <- sort(unique(as.integer(eligible$n_clusters)))
  analysis_seed <- seed_for(dose, analysis)
  set.seed(analysis_seed)
  message(
    "Running ", n_perm, " permutations for ", dose, " ", analysis,
    " across ", length(sizes), " unique cluster counts and ", nrow(metrics), " clusters..."
  )
  null_matrix <- cluster_null_matrix(
    as.numeric(metrics$numerator),
    as.numeric(metrics$denominator),
    as.integer(sizes),
    n_perm
  )

  result_parts <- vector("list", length(sizes))
  null_parts <- vector("list", length(sizes))
  for (j in seq_along(sizes)) {
    m <- sizes[[j]]
    null <- null_matrix[, j]
    group <- eligible %>% filter(n_clusters == m)
    obs <- group$observed_stat
    p_emp <- if (analysis == "binary") {
      vapply(obs, function(x) (1 + sum(null >= x)) / (n_perm + 1), numeric(1))
    } else {
      vapply(obs, function(x) (1 + sum(null <= x)) / (n_perm + 1), numeric(1))
    }

    result_parts[[j]] <- group %>%
      mutate(
        null_mean = mean(null),
        null_median = median(null),
        null_sd = sd(null),
        null_q025 = unname(quantile(null, 0.025)),
        null_q975 = unname(quantile(null, 0.975)),
        effect_delta = observed_stat - null_mean,
        fold_vs_null = if_else(analysis == "binary" & null_mean > 0, observed_stat / null_mean, NA_real_),
        z_like = if_else(null_sd > 0, effect_delta / null_sd, NA_real_),
        empirical_p = p_emp,
        expected_direction = if_else(analysis == "binary", "higher_down_fraction", "negative_mean_shift"),
        direction_supported = if_else(analysis == "binary", effect_delta > 0, effect_delta < 0),
        n_perm = n_perm,
        random_seed = analysis_seed,
        n_universe_clusters = nrow(metrics),
        n_universe_sites = sum(metrics$denominator)
      )

    null_parts[[j]] <- tibble(
      dose = dose,
      analysis = analysis,
      n_clusters_sampled = m,
      n_perm = n_perm,
      random_seed = analysis_seed,
      null_mean = mean(null),
      null_median = median(null),
      null_sd = sd(null),
      null_q025 = unname(quantile(null, 0.025)),
      null_q975 = unname(quantile(null, 0.975))
    )
  }

  results <- bind_rows(result_parts) %>%
    group_by(dose, analysis, database) %>%
    mutate(
      BH_FDR = p.adjust(empirical_p, method = "BH"),
      rank_by_empirical_p = min_rank(empirical_p),
      rank_by_directional_effect = if_else(
        analysis == "binary",
        min_rank(dplyr::desc(effect_delta)),
        min_rank(effect_delta)
      )
    ) %>%
    ungroup() %>%
    arrange(dose, analysis, database, empirical_p, dplyr::desc(abs(z_like)), pathway_id) %>%
    dplyr::select(
      dose, analysis, database, pathway_id, pathway_name,
      n_clusters, n_sites, observed_numerator, observed_stat,
      null_mean, null_median, null_sd, null_q025, null_q975,
      effect_delta, fold_vs_null, z_like, empirical_p, BH_FDR,
      rank_by_empirical_p, rank_by_directional_effect,
      expected_direction, direction_supported,
      n_perm, random_seed, n_universe_clusters, n_universe_sites
    )

  list(
    results = results,
    eligibility = eligibility,
    null_summary = bind_rows(null_parts),
    cluster_metrics = metrics %>% mutate(dose = dose, analysis = analysis)
  )
}

screens <- list(
  Pal1_binary = run_one_screen(pal1_universe, "Pal1", "binary"),
  Pal5_binary = run_one_screen(pal5_universe, "Pal5", "binary"),
  Pal1_continuous = run_one_screen(pal1_universe, "Pal1", "continuous"),
  Pal5_continuous = run_one_screen(pal5_universe, "Pal5", "continuous")
)

all_results <- map_dfr(screens, "results")
all_eligibility <- map_dfr(screens, "eligibility")
all_null_summary <- map_dfr(screens, "null_summary")
all_cluster_metrics <- map_dfr(screens, "cluster_metrics")

binary_results <- all_results %>% filter(analysis == "binary")
continuous_results <- all_results %>% filter(analysis == "continuous")

benchmark_patterns <- tribble(
  ~benchmark_group, ~database, ~pattern,
  "Supervisor_GO", "GO", "spindle microtubule",
  "Supervisor_GO", "GO", "regulation of spindle microtubule-kinetochore attachment",
  "Supervisor_GO", "GO", "positive regulation of spindle microtubule-kinetochore attachment",
  "Supervisor_GO", "GO", "mitotic spindle",
  "Supervisor_GO", "GO", "sister chromatid segregation",
  "Supervisor_Reactome", "Reactome", "Resolution of Sister Chromatid Cohesion",
  "Supervisor_Reactome", "Reactome", "EML4 and NUDC in mitotic spindle formation",
  "Supervisor_Reactome", "Reactome", "Mitotic Prometaphase",
  "Supervisor_Reactome", "Reactome", "Mitotic Spindle Checkpoint"
)

benchmark_results <- map_dfr(seq_len(nrow(benchmark_patterns)), function(i) {
  b <- benchmark_patterns[i, ]
  candidates <- all_results %>%
    filter(
      if (b$database == "GO") str_starts(database, "GO_") else database == "Reactome",
      str_detect(str_to_lower(pathway_name), fixed(str_to_lower(b$pattern)))
    ) %>%
    mutate(
      benchmark_group = b$benchmark_group,
      requested_pattern = b$pattern
    )
  candidates
}) %>%
  dplyr::select(benchmark_group, requested_pattern, everything())

symbol_entrez <- suppressMessages(
  AnnotationDbi::select(
    org.Hs.eg.db,
    keys = sort(unique(membership$gene_symbol)),
    keytype = "SYMBOL",
    columns = c("SYMBOL", "ENTREZID")
  )
) %>%
  filter(!is.na(ENTREZID)) %>%
  distinct(SYMBOL, ENTREZID)

membership_export <- membership %>%
  left_join(pathway_meta, by = c("database", "pathway_id")) %>%
  left_join(symbol_entrez, by = c("gene_symbol" = "SYMBOL")) %>%
  transmute(
    database, pathway_id, pathway_name,
    entrez_id = as.character(ENTREZID),
    gene_symbol
  ) %>%
  arrange(database, pathway_id, gene_symbol, entrez_id)

go_membership_export <- membership_export %>% filter(str_starts(database, "GO_"))
reactome_membership_export <- membership_export %>% filter(database == "Reactome")

universe_summary <- site_universe %>%
  group_by(dose) %>%
  summarise(
    continuous_sites = n(),
    continuous_clusters = n_distinct(protein_accession),
    binary_sites = sum(binary_eligible),
    binary_clusters = n_distinct(protein_accession[binary_eligible]),
    qualifying_down_sites = sum(down_binary),
    .groups = "drop"
  )

screen_summary <- all_results %>%
  group_by(dose, analysis, database) %>%
  summarise(
    eligible_pathways = n(),
    nominal_P_lt_0.05 = sum(empirical_p < 0.05),
    BH_FDR_lt_0.05 = sum(BH_FDR < 0.05),
    direction_supported = sum(direction_supported),
    .groups = "drop"
  )

run_parameters <- tibble(
  parameter = c(
    "analysis_date", "n_permutations", "base_seed",
    "Pal1_binary_seed", "Pal5_binary_seed", "Pal1_continuous_seed", "Pal5_continuous_seed",
    "cluster_unit", "sampling", "binary_definition", "continuous_definition",
    "minimum_pathway_clusters", "minimum_pathway_sites",
    "multiple_testing", "GO_membership_definition", "Reactome_membership_definition",
    "org.Hs.eg.db_version", "GO.db_version",
    "frozen_R2_cache", "frozen_R12_membership_source", "pathway_names"
  ),
  value = c(
    "2026-08-28", as.character(n_perm), as.character(base_seed),
    as.character(seed_for("Pal1", "binary")), as.character(seed_for("Pal5", "binary")),
    as.character(seed_for("Pal1", "continuous")), as.character(seed_for("Pal5", "continuous")),
    "UniProt protein_accession_clean", "uniform without replacement; all sites in sampled accessions retained",
    "P < 0.05 and log2FC < -0.6; denominator restricted to sites with finite P and log2FC",
    "mean of all finite quantified phosphosite log2FC values; no P-value or fold-change threshold",
    as.character(min_clusters), as.character(min_sites),
    "BH correction separately within dose x analysis x database",
    "All GOALL annotations reconstructed from every gene symbol in the frozen protein/gene mapping; no preselection by the original ORA term list",
    "Exact Reactome pathway-to-gene mapping exported by the frozen R12 pipeline",
    as.character(packageVersion("org.Hs.eg.db")),
    as.character(packageVersion("GO.db")),
    "manuscript_delivery_2026-08-23/cache/R2_0_preprocessed_objects.rds",
    "manuscript_delivery_2026-08-23/source_data/exact_pathway_gene_membership_long.csv",
    "manuscript_delivery_2026-08-23/source_data/original_tested_pathways.csv"
  )
)

write_table <- function(x, filename) {
  write.csv(
    as.data.frame(x),
    file.path(table_dir, filename),
    row.names = FALSE,
    na = "",
    fileEncoding = "UTF-8"
  )
}

write_table(site_universe, "01_frozen_phosphosite_universe_Pal1_Pal5.csv")
write_table(protein_gene_mapping, "02_protein_accession_gene_mapping.csv")
write_table(go_membership_export, "03_GO_membership_full_reconstructed_GOALL.csv")
write_table(reactome_membership_export, "04_Reactome_membership_exact_R12_universe.csv")
write_table(r12_membership %>% filter(str_starts(database, "GO_")), "04b_GO_membership_R12_original_tested_terms_reference.csv")
write_table(binary_results, "05_full_binary_cluster_permutation_results.csv")
write_table(continuous_results, "06_full_continuous_cluster_permutation_results.csv")
write_table(all_results, "07_all_cluster_permutation_results.csv")
write_table(all_eligibility, "08_pathway_eligibility_all.csv")
write_table(all_null_summary, "09_null_distribution_summaries_by_cluster_count.csv")
write_table(benchmark_results, "10_supervisor_benchmark_pathways.csv")
write_table(universe_summary, "11_universe_summary.csv")
write_table(screen_summary, "12_screen_summary.csv")
write_table(run_parameters, "13_run_parameters_and_seeds.csv")
write_table(accession_gene_conflicts, "14_accessions_with_multiple_gene_symbols.csv")
write_table(all_cluster_metrics, "15_cluster_level_sufficient_statistics.csv")

saveRDS(
  list(
    results = all_results,
    eligibility = all_eligibility,
    null_summary = all_null_summary,
    universe_summary = universe_summary,
    screen_summary = screen_summary,
    parameters = run_parameters
  ),
  file.path(repro_dir, "cluster_aware_analysis_objects.rds")
)

capture.output(sessionInfo(), file = file.path(repro_dir, "sessionInfo.txt"))

cat("OUTPUT_DIR=", output_dir, "\n", sep = "")
cat("N_PERM=", n_perm, "\n", sep = "")
print(universe_summary)
print(screen_summary, n = Inf)
cat("RESULT_ROWS=", nrow(all_results), "\n", sep = "")
cat("BENCHMARK_ROWS=", nrow(benchmark_results), "\n", sep = "")
