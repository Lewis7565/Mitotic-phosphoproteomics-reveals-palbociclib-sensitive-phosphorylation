suppressPackageStartupMessages({
  library(dplyr)
  library(readr)
})

project_root <- Sys.getenv("PROJECT_ROOT_SHORT")
package_root <- Sys.getenv("CLUSTER_PACKAGE_ROOT")
if (nzchar(package_root)) {
  root <- package_root
} else if (nzchar(project_root)) {
  root <- file.path(project_root, "outputs", "cluster_aware_reproduction_full_GO_2026-08-28")
} else {
  all_args <- commandArgs(trailingOnly = FALSE)
  script_path <- sub("^--file=", "", all_args[grepl("^--file=", all_args)][1])
  root <- file.path(dirname(script_path), "..")
}
table_dir <- file.path(root, "tables")

read_csv_binary <- function(path) {
  connection <- file(path, open = "rb")
  on.exit(close(connection), add = TRUE)
  read_csv(connection, show_col_types = FALSE)
}

results <- read_csv_binary(file.path(table_dir, "07_all_cluster_permutation_results.csv"))
eligibility <- read_csv_binary(file.path(table_dir, "08_pathway_eligibility_all.csv"))
universe <- read_csv_binary(file.path(table_dir, "01_frozen_phosphosite_universe_Pal1_Pal5.csv"))
go_full <- read_csv_binary(file.path(table_dir, "03_GO_membership_full_reconstructed_GOALL.csv"))
reactome <- read_csv_binary(file.path(table_dir, "04_Reactome_membership_exact_R12_universe.csv"))
go_r12 <- read_csv_binary(file.path(table_dir, "04b_GO_membership_R12_original_tested_terms_reference.csv"))

stopifnot(nrow(results) == 40137L)
stopifnot(all(results$n_perm == 20000L))
stopifnot(setequal(unique(results$random_seed), c(2026082811, 2026082812, 2026082821, 2026082822)))
stopifnot(setequal(unique(results$dose), c("Pal1", "Pal5")))
stopifnot(setequal(unique(results$analysis), c("binary", "continuous")))
stopifnot(setequal(unique(results$database), c("GO_BP", "GO_CC", "GO_MF", "Reactome")))
stopifnot(all(results$empirical_p >= (1 / 20001 - 1e-12) & results$empirical_p <= 1))
stopifnot(!anyDuplicated(results[c("dose", "analysis", "database", "pathway_id")]))
stopifnot(!anyDuplicated(universe[c("dose", "site_id")]))

eligible_keys <- eligibility %>%
  filter(eligible) %>%
  distinct(dose, analysis, database, pathway_id)
result_keys <- results %>% distinct(dose, analysis, database, pathway_id)
stopifnot(nrow(anti_join(eligible_keys, result_keys, by = names(eligible_keys))) == 0L)
stopifnot(nrow(anti_join(result_keys, eligible_keys, by = names(result_keys))) == 0L)

full_term_counts <- go_full %>%
  distinct(database, pathway_id) %>%
  count(database) %>%
  tibble::deframe()
stopifnot(full_term_counts[["GO_BP"]] == 11032L)
stopifnot(full_term_counts[["GO_CC"]] == 1547L)
stopifnot(full_term_counts[["GO_MF"]] == 2758L)
stopifnot(nrow(go_full) == 636075L)
stopifnot(nrow(reactome) == 40206L)
stopifnot(nrow(go_r12) == 264823L)
stopifnot(n_distinct(reactome$pathway_id) == 1146L)

r12_pairs <- go_r12 %>% distinct(database, pathway_id, gene_symbol)
full_pairs <- go_full %>% distinct(database, pathway_id, gene_symbol)
stopifnot(nrow(anti_join(r12_pairs, full_pairs, by = c("database", "pathway_id", "gene_symbol"))) == 0L)
stopifnot(n_distinct(full_pairs$pathway_id) > n_distinct(r12_pairs$pathway_id))

reactome_expected <- tibble::tribble(
  ~pathway_id, ~expected_approx,
  "R-HSA-2500257", 0.045,
  "R-HSA-9648025", 0.066,
  "R-HSA-68877", 0.067,
  "R-HSA-69618", 0.11
)
reactome_observed <- results %>%
  filter(dose == "Pal5", analysis == "binary", database == "Reactome") %>%
  inner_join(reactome_expected, by = "pathway_id")
stopifnot(nrow(reactome_observed) == 4L)
stopifnot(all(abs(reactome_observed$empirical_p - reactome_observed$expected_approx) < 0.01))

cat("PASS: all complete-GO integrity checks completed.\n")
cat("Result rows:", nrow(results), "\n")
cat("Frozen universe rows:", nrow(universe), "\n")
cat("Full GO membership rows:", nrow(go_full), "\n")
cat("Exact Reactome membership rows:", nrow(reactome), "\n")
cat("Full GO term counts:", paste(names(full_term_counts), full_term_counts, collapse = "; "), "\n")
