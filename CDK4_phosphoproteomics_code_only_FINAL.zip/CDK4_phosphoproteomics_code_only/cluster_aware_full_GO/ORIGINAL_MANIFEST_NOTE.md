# Note on the original cluster-aware package manifest

The original delivery manifest was checked against the uploaded `cluster_aware_reproduction_full_GO_2026-08-28` package during repository assembly.

- 29 of 30 manifest entries matched the uploaded files exactly by size and SHA-256.
- The only mismatch was `README.md`: the uploaded README is 6,298 bytes, whereas the original manifest records a 6,539-byte README with a different hash.
- All analysis scripts, frozen inputs, tables, validation record, session information, summary workbook and analysis objects listed in the original manifest matched.

This is consistent with the README having been edited after the original manifest was generated. The assembled repository therefore preserves the uploaded README and retains the original manifest for provenance. The repository-level `MANIFEST_SHA256.csv` records hashes for the actual files distributed here.
