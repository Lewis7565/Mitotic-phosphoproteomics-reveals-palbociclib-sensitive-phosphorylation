# CDK4/6 mitotic phosphoproteomics — reproducibility package

This repository packages the custom computational analyses used to reanalyse the mitotic phosphoproteomics dataset in the CDK4/6 chromosome-segregation study.

## Repository structure

- `primary_pipeline/` — the main R2.0-R12 analysis workflow supplied in the 23 August 2026 final delivery. It contains portable analysis scripts, frozen/reference inputs, and frozen result workbooks used by the manuscript figure builders.
- `cluster_aware_full_GO/` — the independent 28 August 2026 protein-cluster-aware reproduction using complete GO-BP/GO-CC/GO-MF and frozen Reactome definitions, with 20,000 permutations per formal screen.
- `docs/` — release notes, environment summary, and a short pre-publication checklist.
- `third_party/` — notes for external software. Upstream third-party source code is not redistributed here.

## Quick start: primary pipeline

Run commands from `primary_pipeline/`.

```bash
Rscript scripts/00_run_pipeline.R
Rscript scripts/12_R12_adjusted_pathways_and_firth.R
Rscript scripts/14_manuscript_figures.R
```

The R2.0-R10 runner fixes the random seed and uses the frozen kinase-substrate reference by default. Detailed stage-by-stage information is in `primary_pipeline/scripts/README.md`.

The exact historical R2.0–R10 R session record is included at `primary_pipeline/environment/sessionInfo_R2_R10.txt`.

### MoMo motif discovery

After the R4 script generates the foreground/background sequence files, run under Linux/WSL with MEME Suite MoMo available:

```bash
bash scripts/04b_run_momo_motifx_wsl.sh
python scripts/04c_summarize_momo_outputs.py
```

`MOMO_BIN` can be used to point to a specific MoMo executable.

## Quick start: cluster-aware full-GO analysis

See `cluster_aware_full_GO/README.md`. The formal analysis uses 20,000 permutations and fixed recorded seeds. The package contains frozen inputs, the analysis/replay script, an automated validation script, complete output tables, and the R session record.

On Windows, the supplied PowerShell wrapper can be used from the cluster-aware package root:

```powershell
reproducibility\run_analysis.ps1
```

A low-permutation smoke test may be used for installation checking; the archived formal results were produced with 20,000 permutations per screen.

## Integrity and provenance

`MANIFEST_SHA256.csv` records SHA-256 hashes for all files in this assembled repository. The cluster-aware subpackage also retains its original package manifest as `cluster_aware_full_GO/ORIGINAL_FILE_MANIFEST_SHA256.csv`.

The assembled repository removes macOS metadata and accidental duplicate files whose names contained `copy`; canonical files are retained unchanged. The original cluster-package manifest has one pre-existing mismatch for `README.md` only; all 29 other listed files matched. See `cluster_aware_full_GO/ORIGINAL_MANIFEST_NOTE.md`.

## Code Availability manuscript text

> Custom code used for phosphoproteomic reanalysis is available in the accompanying reproducibility package and will be deposited in a public repository upon publication.

Replace this placeholder with the final repository URL/DOI when the public record is created.

## License

A license has not yet been assigned. See `LICENSE_PENDING.md` before public release.
