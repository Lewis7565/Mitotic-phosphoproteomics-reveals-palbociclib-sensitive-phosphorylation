# Primary pipeline environment

The original R2.0–R10 run was performed under the exact software environment recorded in:

`primary_pipeline/environment/sessionInfo_R2_R10.txt`

Key details from that historical session record:

- R 4.4.2 (2024-10-31 ucrt)
- Windows 11 x64
- `clusterProfiler` 4.14.6
- `ReactomePA` 1.50.0
- `GO.db` 3.20.0
- `org.Hs.eg.db` 3.20.0
- `AnnotationDbi` 1.68.0
- `Biostrings` 2.74.1
- `openxlsx` 4.2.8.1
- `readxl` 1.5.0
- `ggplot2` 4.0.3
- `dplyr` 1.2.1
- `tidyverse` 2.0.0

The full attached/loaded package list, locale and platform information are preserved verbatim in the session-information file.

The primary pipeline README specifies the remaining external requirements. In particular, the MoMo step requires WSL/Linux plus MEME Suite MoMo 5.5.7 (or a compatible release), and the Python summarizer uses Python 3 with the scientific-Python dependencies imported by the script.

The central runner also writes `results/sessionInfo_R2_R10.txt` when the pipeline is rerun. The copy included here is the historical session record from the original analysis and should therefore be retained unchanged.
