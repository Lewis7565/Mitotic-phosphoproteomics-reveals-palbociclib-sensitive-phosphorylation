# Repository release checklist

## Already included
- Primary R2.0-R12 phosphoproteomics analysis scripts and frozen inputs.
- MoMo runner and Python summarizer.
- Publication-figure generation scripts.
- Protein-cluster-aware full-GO/Reactome reproduction package.
- Frozen cluster-analysis inputs, complete result tables, seeds, validation record and software session information.
- Root and package-level SHA-256 manifests.

## Before public release
1. Choose a license for study-authored code.
2. Replace the manuscript Code Availability placeholder with the final repository URL/DOI once assigned.
3. Confirm whether the raw/proteomics dataset will also be deposited in PRIDE/ProteomeXchange and add the accession to the manuscript Data Availability statement.
4. Historical `sessionInfo_R2_R10.txt` from the original primary R2.0-R10 run is now included at `primary_pipeline/environment/sessionInfo_R2_R10.txt`.
5. If the historical MoMo analysis required a locally patched MEME Suite binary, add a small patch/diff plus upstream version/license information rather than redistributing an upstream source file.
